import { Language } from '../types';

export interface SubPageModalData {
  id: string;
  titleEn: string;
  titleFa: string;
  categoryEn: string;
  categoryFa: string;
  heroImage: string;
  summaryEn: string;
  summaryFa: string;
  contentEn: string[];
  contentFa: string[];
  keyHighlightsEn: string[];
  keyHighlightsFa: string[];
  ctaTextEn: string;
  ctaTextFa: string;
}

export interface FeatureCard {
  id: 'mission' | 'history' | 'academics' | 'inspections' | 'campus' | 'governance';
  titleEn: string;
  titleFa: string;
  summaryEn: string;
  summaryFa: string;
  buttonTextEn: string;
  buttonTextFa: string;
  image: string;
}

export interface StatCard {
  number: string;
  labelEn: string;
  labelFa: string;
  icon: 'college' | 'globe' | 'briefcase' | 'apple' | 'backpack' | 'bus' | 'settings' | 'grad';
}

export interface SchoolCard {
  id: 'infant' | 'junior' | 'sixth-form';
  titleEn: string;
  titleFa: string;
  ageRange: string;
  image: string;
  descriptionEn: string;
  descriptionFa: string;
  buttonTextEn: string;
  buttonTextFa: string;
}

export const featureCardsData: FeatureCard[] = [
  {
    id: 'mission',
    titleEn: 'MISSION, VISION & CORE VALUES',
    titleFa: 'ماموریت، چشم‌انداز و ارزش‌های خرد',
    summaryEn: 'These values guide our daily conduct at Kherad — in classrooms, with families, and across leadership decisions.',
    summaryFa: 'این ارزش‌ها راهنمای رفتار روزانه ما در خرد هستند — در کلاس درس، در تعامل با خانواده‌ها و در تصمیم‌های مدیریتی.',
    buttonTextEn: 'EXPLORE OUR 8 CORE VALUES',
    buttonTextFa: 'مشاهده ارزش‌های هشت‌گانه خرد',
    image: '/assets/photos/mission-vision.jpg'
  },
  {
    id: 'history',
    titleEn: 'HISTORY OF THE SCHOOL',
    titleFa: 'تاریخچه منظومه خرد',
    summaryEn: 'With 25 years of pioneering educational leadership since 2000, Kherad is a benchmark for excellence in Tehran.',
    summaryFa: 'با ۲۵ سال تجربه نوآورانه از سال ۱۳۷۹ به همت بانو حائری‌زاده، خرد نماد تحول در آموزش دختران کشور است.',
    buttonTextEn: "ABOUT KHERAD'S HERITAGE",
    buttonTextFa: 'درباره تاریخچه ۲۵ ساله خرد',
    image: '/assets/photos/history.jpg'
  },
  {
    id: 'academics',
    titleEn: 'ACADEMIC RESULTS & OLYMPIADS',
    titleFa: 'نتایج تحصیلی درخشان و کنکور',
    summaryEn: 'Outstanding achievements in the national university entrance examinations, Kharazmi festivals, and international Olympiads.',
    summaryFa: 'رتبه‌های تک‌رقمی و دورقمی کنکور سراسری، مدال‌های طلای المپیادهای ملی و جوایز جشنواره جوان خوارزمی.',
    buttonTextEn: 'VIEW RESULTS & METRICS',
    buttonTextFa: 'مشاهده کارنامه و نتایج آزمون‌ها',
    image: '/assets/photos/academic-results.jpg'
  },
  {
    id: 'inspections',
    titleEn: 'CAMPUS & SUSTAINABILITY',
    titleFa: 'مجتمع آموزشی خرد و توسعه پایدار',
    summaryEn: 'A state-of-the-art 12,000 sqm learning space embracing environmental responsibility, green school principles, and modern labs.',
    summaryFa: 'فضای پیشرفته ۱۲ هزار متری مجتمع آموزشی خرد با تعهد کامل به مدرسه سبز، تفکیک پسماند و محیط زیست پایدار.',
    buttonTextEn: 'VIEW CAMPUS & SUSTAINABILITY',
    buttonTextFa: 'مشاهده مجتمع خرد و مدرسه سبز',
    image: '/assets/photos/inspections-awards.jpg'
  },
  {
    id: 'campus',
    titleEn: 'INTERACTIVE CAMPUS MAP',
    titleFa: 'نقشه تعاملی مجتمع آموزشی خرد',
    summaryEn: "Kherad’s facilities have transformed over the years with modern laboratories and the latest technologies to support every student.",
    summaryFa: 'امکانات مجتمع آموزشی خرد با احداث فضاهای نوین آموزشی و تجهیز به مدرن‌ترین فناوری‌ها پیوسته در حال رشد و تحول بوده است.',
    buttonTextEn: 'VIEW THE CAMPUS',
    buttonTextFa: 'مشاهده مجتمع آموزشی خرد و امکانات',
    image: '/assets/photos/campus-map.jpg'
  },
  {
    id: 'governance',
    titleEn: 'GOVERNANCE',
    titleFa: 'ارکان مدیریت و هیئت امنا',
    summaryEn: 'Meet our board of governors and the appointed committees in relation to different areas of responsibility.',
    summaryFa: 'آشنایی با هیئت امنای مدرسه تانگلین و کمیته‌های تخصصی ناظر بر توسعه، آموزش و امور مالی.',
    buttonTextEn: 'SEE GOVERNANCE',
    buttonTextFa: 'مشاهده ساختار حاکمیتی',
    image: '/assets/photos/governance.jpg'
  }
];

export const statisticsData: StatCard[] = [
  {
    number: '100',
    labelEn: 'Years of Establishment',
    labelFa: 'سال سابقه تاسیس و خدمت',
    icon: 'college'
  },
  {
    number: '55',
    labelEn: 'Student Nationalities',
    labelFa: 'ملیت‌های گوناگون دانش‌آموزان',
    icon: 'globe'
  },
  {
    number: '674',
    labelEn: 'No. of Employees',
    labelFa: 'تعداد کل کادر و کارکنان',
    icon: 'briefcase'
  },
  {
    number: '270',
    labelEn: 'Teaching Staff',
    labelFa: 'اساتید و معلمان متخصص',
    icon: 'apple'
  },
  {
    number: '722',
    labelEn: 'Infant Children (Nursery to Year 2)',
    labelFa: 'دانش‌آموز دوره خردسال (مهد تا پایه ۲)',
    icon: 'backpack'
  },
  {
    number: '773',
    labelEn: 'Junior Children (Year 3 to 6)',
    labelFa: 'دانش‌آموز دوره دبستان (پایه ۳ تا ۶)',
    icon: 'bus'
  },
  {
    number: '1334',
    labelEn: 'Senior Students (Year 7 to 13)',
    labelFa: 'دانش‌آموز دوره متوسطه و کالج (پایه ۷ تا ۱۳)',
    icon: 'settings'
  },
  {
    number: '22K +',
    labelEn: 'Alumni Across the Globe',
    labelFa: 'فارغ‌التحصیل در سراسر جهان',
    icon: 'grad'
  }
];

export const schoolCardsData: SchoolCard[] = [
  {
    id: 'infant',
    titleEn: 'Discover our\nInfant School',
    titleFa: 'مدرسه خردسالان تانگلین\n(Infant School)',
    ageRange: 'Age 3–7',
    image: '/assets/photos/infant-school.jpg',
    descriptionEn: 'Nurturing curiosity, confidence and a lifelong love of learning through the English Early Years Foundation Stage & Key Stage 1.',
    descriptionFa: 'پرورش کنجکاوی، اعتمادبه‌نفس و اشتیاق یادگیری بر پایه استانداردهای نظام آموزشی بریتانیا.',
    buttonTextEn: 'Learn More',
    buttonTextFa: 'اطلاعات بیشتر'
  },
  {
    id: 'junior',
    titleEn: 'Discover our\nJunior School',
    titleFa: 'مدرسه دبستان تانگلین\n(Junior School)',
    ageRange: 'Age 7–11',
    image: '/assets/photos/junior-school.jpg',
    descriptionEn: 'Inspiring young learners in Key Stage 2 with rich curricular breadth, bespoke Junior Arts Centre, sports, and collaborative problem-solving.',
    descriptionFa: 'الهام‌بخشی به دانش‌آموزان در دوره دوم با امکانات مرکز هنر کودک، ورزش‌های تیمی و یادگیری پژوهش‌محور.',
    buttonTextEn: 'Learn More',
    buttonTextFa: 'اطلاعات بیشتر'
  },
  {
    id: 'sixth-form',
    titleEn: 'Discover our\nSixth Form',
    titleFa: 'کالج و سال ششم تانگلین\n(Sixth Form)',
    ageRange: 'Age 16–18',
    image: '/assets/photos/sixth-form.jpg',
    descriptionEn: 'Singapore’s only school offering both A Levels and the IB Diploma, paving the way to the world’s leading universities.',
    descriptionFa: 'تنها مرکز آموزشی در سنگاپور با ارائه همزمان دوره‌های A-Level و دیپلم IB، هموارکننده ورود به دانشگاه‌های طراز اول جهان.',
    buttonTextEn: 'Learn More',
    buttonTextFa: 'اطلاعات بیشتر'
  }
];

export const subPagesDetails: Record<string, SubPageModalData> = {
  mission: {
    id: 'mission',
    titleEn: 'Mission, Vision & Kherad 8 Core Values',
    titleFa: 'ماموریت، چشم‌انداز و ارزش‌های هشت‌گانه خرد',
    categoryEn: 'About Kherad',
    categoryFa: 'درباره خرد',
    heroImage: '/assets/photos/mission-vision.jpg',
    summaryEn: 'These values guide our daily conduct at Kherad — in the classroom, in partnerships with families, and across management decisions.',
    summaryFa: 'این ارزش‌ها راهنمای رفتار روزانه ما در خرد هستند — در کلاس درس، در تعامل با خانواده‌ها و در تصمیم‌های مدیریتی.',
    contentEn: [
      'Kherad Educational Complex was established in 2000 with a steadfast commitment to delivering holistic, research-driven, and forward-looking education for girls in Tehran.',
      'Our 8 core values form the behavioral backbone across our entire community: 1. Self-Awareness & Growth Through Feedback; 2. Inquiry & Clear Thinking; 3. Purposeful Effort for Genuine Impact; 4. Responsibility to Society & Nature; 5. Collaboration & Teamwork; 6. Honesty & Transparency in All Relationships; 7. Holistic Development & Wellbeing; 8. Kindness & Respect for Every Individual.',
      'Through inquiry-led learning, environmental stewardship in our green campus, and genuine partnership with parents, we empower every learner to thrive as an impactful, compassionate leader.'
    ],
    contentFa: [
      'مؤسسه و مجتمع آموزشی منظومه خرد در سال ۱۳۷۹ به همت بانو خیریه بیگم حائری‌زاده با رویکرد آموزش پژوهش‌محور، مهارت‌های زندگی و سازمان یادگیرنده بنیان نهاده شد.',
      'ارزش‌های هشت‌گانه خرد راهنمای رفتار روزانه ما هستند: ۱. شناخت خود و رشد از دل بازخورد؛ ۲. پرسش‌گری و تفکر روشن؛ ۳. تلاش هدفمند برای نتیجه‌ی واقعی؛ ۴. مسئولیت در قبال جامعه و طبیعت؛ ۵. همکاری و کار تیمی؛ ۶. صداقت و شفافیت در همه‌ی روابط؛ ۷. رشد همه‌جانبه؛ ۸. مهربانی و احترام.',
      'در خرد، درس تنها بخشی از زندگی دانش‌آموز است؛ ما به سلامت روان، هنر، ورزش، اخلاق شهروندی و محیط زیست اهمیت می‌دهیم و با مشارکت نزدیک خانواده‌ها، بستری امن برای شکوفایی فرزندان فراهم می‌کنیم.'
    ],
    keyHighlightsEn: [
      '8 Defined Core Values with practical behavioral criteria for students, parents, and staff',
      'Velenjak Green Campus: environmental sustainability and active recycling as an educational principle',
      'Inquiry-based learning fostering critical reasoning over rote memorization',
      'Holistic wellbeing, artistic expression, and extensive psychological counseling support'
    ],
    keyHighlightsFa: [
      'ارزش‌های هشت‌گانه مدون خرد با مصادیق مشخص رفتاری برای دانش‌آموز، والدین و مدیریت',
      'مدرسه سبز مجتمع آموزشی خرد: توجه ویژه به مسئولیت زیست‌محیطی، تفکیک پسماند و سواد دیجیتال آگاهانه',
      'رویکرد آموزش پژوهش‌محور و تقویت تفکر نقادانه به جای محفوظات مکانیکی',
      'رشد همه‌جانبه با حضور فعال در هنر، ورزش، جشنواره‌های علمی و سلامت روان'
    ],
    ctaTextEn: 'View Kherad Core Values Blueprint',
    ctaTextFa: 'مشاهده سند ارزش‌های بنیادین خرد'
  },
  history: {
    id: 'history',
    titleEn: 'History of Kherad Educational Complex (2000–Present)',
    titleFa: 'تاریخچه مجتمع آموزشی خرد (۱۳۷۹–اکنون)',
    categoryEn: 'Heritage',
    categoryFa: 'پیشینه و اصالت',
    heroImage: '/assets/photos/history.jpg',
    summaryEn: 'Established in 2000 by Kheyrieh Beigom Haerizadeh, Kherad is a pioneering educational complex for girls, dedicated to inquiry-based learning and holistic development.',
    summaryFa: 'تأسیس در سال ۱۳۷۹ به همت خیریه بیگم حائری‌زاده؛ مجتمع آموزشی خرد پیشرو در آموزش پژوهش‌محور، مهارت‌های فردی و رشد همه‌جانبه دختران است.',
    contentEn: [
      'In 2000, Kheyrieh Beigom Haerizadeh founded Kherad with the vision of creating a dynamic learning organization aligned with modern world-class pedagogical frameworks.',
      'Driven by a profound belief in female empowerment, Kherad expanded from early years to primary, middle school, high school, and a dedicated vocational school.',
      'As a non-profit educational institution, all resources are channeled into student development, faculty training, cutting-edge laboratories, and sustainability initiatives.',
      'Located in Velenjak across 12,000 m² of purpose-built learning spaces, Kherad provides an environment that fosters critical thinking, artistic creativity, and teamwork.'
    ],
    contentFa: [
      'در سال ۱۳۷۹، خیریه بیگم حائری‌زاده با انگیزه ایجاد محیطی یادگیرنده، پویا و همگام با الگوهای نوین آموزشی جهان، مجتمع آموزشی خرد را پایه‌گذاری کرد.',
      'این مجموعه با باور عمیق به توانمندی دختران، از دوره‌های پیش‌دبستانی و ابتدایی کار خود را آغاز نمود و سپس به دوره‌های متوسطه اول، متوسطه دوم و هنرستان گسترش یافت.',
      'ساختار عام‌المنفعه خرد تضمین می‌کند که همه ظرفیت‌ها و درآمدهای آموزشی صرف تجهیز آزمایشگاه‌ها، ارتقای کادر علمی، پروژه‌های پایداری و ایجاد فرصت‌های برابر گردد.',
      'استقرار در مجتمع آموزشی خرد در ولنجک با ۱۲٬۰۰۰ متر مربع زیربنا در ۷ طبقه، بستری بی‌بدیل برای یادگیری تیمی، پژوهش‌های تجربی و خلاقیت هنری به ارمغان آورده است.'
    ],
    keyHighlightsEn: [
      '2000: Founded by Kheyrieh Beigom Haerizadeh',
      'Inquiry-based learning across 5 progressive girls educational stages',
      '12,000 m² purpose-built facilities in Velenjak, Tehran',
      '25+ years of excellence in university admissions, Olympiads, and community impact'
    ],
    keyHighlightsFa: [
      '۱۳۷۹: تأسیس مجتمع به همت خیریه بیگم حائری‌زاده',
      'رویکرد یادگیرنده و پژوهش‌محور در ۵ مقطع تحصیلی دخترانه',
      'استقرار در مجتمع آموزشی خرد (ولنجک) با ۱۲ هزار متر مربع زیربنا',
      'بیش از ۲۵ سال پیشتازی در کنکور، المپیادها و جشنواره‌های ملی و بین‌المللی'
    ],
    ctaTextEn: 'Explore Kherad Archives',
    ctaTextFa: 'مشاهده روایت تحول و پیشینه خرد'
  },
  academics: {
    id: 'academics',
    titleEn: 'Academic Results & Dual Pathway',
    titleFa: 'نتایج امتحانات و دوگانه A-Level و IB Diploma',
    categoryEn: 'Academics',
    categoryFa: 'برنامه تحصیلی',
    heroImage: '/assets/photos/academic-results.jpg',
    summaryEn: 'Tanglin is the only school in Singapore to offer both A Level and the IB Diploma in Sixth Form, with exam results consistently surpassing national and global averages.',
    summaryFa: 'تنها مدرسه در سنگاپور با ارائه همزمان هر دو دوره A-Level و دیپلم بین‌المللی IB؛ با نتایجی که پیوسته بالاتر از میانگین جهانی و سنگاپور قرار دارد.',
    contentEn: [
      'At Tanglin Sixth Form, students are empowered to choose the educational pathway that best matches their strengths, learning preferences, and future university aspirations.',
      'IB Diploma results: Our students attained an average score of 38.8 points (out of 45), well above the world average of 30.2 points. 100% of our candidates passed, with 30% scoring 42 points or higher.',
      'A Level results: 58% of all grades achieved were A* or A, and 85% were A* to B. Over 96% of graduates secured entry into their first- or second-choice universities around the globe.'
    ],
    contentFa: [
      'در دوره سال ششم تانگلین، دانش‌آموزان این آزادی عمل را دارند که مسیری متناسب با توانایی‌ها و اهداف دانشگاهی آینده خود برگزینند.',
      'کارنامه دوره بین‌المللی IB: میانگین امتیاز دانش‌آموزان تانگلین ۳۸.۸ از ۴۵ نمره بوده است (در قیاس با میانگین جهانی ۳۰.۲). ۱۰۰٪ قبولی و کسب نمرات بالای ۴۲ توسط ۳۰٪ دانش‌آموزان.',
      'کارنامه دوره A-Level: ۵۸٪ از نمرات کل آزمون‌ها A* یا A بوده و ۸۵٪ بین A* تا B ثبت شده است. بیش از ۹۶٪ فارغ‌التحصیلان وارد اولویت اول یا دوم دانشگاهی خود شده‌اند.'
    ],
    keyHighlightsEn: [
      'Dual Pathway: Choice between IB Diploma & British A Levels',
      'University destinations: Oxford, Cambridge, Imperial, UCL, Harvard, Stanford, Columbia, NUS, Melbourne',
      'Dedicated Higher Education and University Counselling team from Year 10 onwards'
    ],
    keyHighlightsFa: [
      'مسیر دوگانه: انتخاب آزاد میان دوره دیپلم IB یا آزمون‌های A-Level بریتانیا',
      'مقصدهای دانشگاهی: آکسفورد، کمبریج، امپریال کالج، هاروارد، استنفورد، کلمبیا و دانشگاه ملی سنگاپور',
      'تیم مشاوران تخصصی ارشد پذیرش دانشگاهی از پایه دهم تا سال پایانی'
    ],
    ctaTextEn: 'Download Examination Results Report',
    ctaTextFa: 'دریافت گزارش تفصیلی نتایج امتحانات'
  },
  inspections: {
    id: 'inspections',
    titleEn: 'Inspections, Accreditations & Awards',
    titleFa: 'بازرسی‌های رسمی، اعتبارنامه‌ها و جوایز بین‌المللی',
    categoryEn: 'Quality Assurance',
    categoryFa: 'تضمین کیفیت و اعتبار',
    heroImage: '/assets/photos/inspections-awards.jpg',
    summaryEn: "All three Tanglin schools are independently inspected by British Schools Overseas (BSO) and consistently awarded the highest accolade of 'Outstanding'.",
    summaryFa: 'تمامی مقاطع مدرسه تانگلین به صورت مستقل توسط نهاد رسمی بازرسی مدارس بریتانیایی خارج از کشور (BSO) ارزیابی شده و بالاترین رتبه ممکن یعنی «برجسته (Outstanding)» را دریافت کرده‌اند.',
    contentEn: [
      'British Schools Overseas (BSO) standards are approved by the UK Department for Education and monitored by Ofsted inspectors. Tanglin is proud that Infant, Junior, and Senior schools are each judged "Outstanding in every standard."',
      'The inspection covers pupil achievement, quality of teaching, spiritual/moral/cultural development, welfare and health & safety, premises and accommodation, and leadership & management.',
      'In the recent Singapore Education Awards 2025, Tanglin achieved triple gold medals: International School of the Year, Most Future-Ready Students, and Best British Curriculum.'
    ],
    contentFa: [
      'استانداردهای مدارس بریتانیایی خارج از کشور (BSO) توسط وزارت آموزش بریتانیا تایید و توسط ارزیابان آفستد (Ofsted) نظارت می‌شود. تانگلین در هر سه مقطع خردسال، دبستان و دبیرستان به درجه «ممتاز در تمامی شاخص‌ها» دست یافته است.',
      'بازرسی‌ها شامل پیشرفت تحصیلی دانش‌آموز، کیفیت تدریس، رشد شخصیتی و فرهنگی، ایمنی و بهداشت، تجهیزات و مدیریت اجرایی است.',
      'در جوایز آموزشی سنگاپور ۲۰۲۵، تانگلین موفق به کسب سه مدال طلا شد: بهترین مدرسه بین‌المللی سال، آماده‌ترین دانش‌آموزان برای آینده و برترین برنامه درسی بریتانیایی.'
    ],
    keyHighlightsEn: [
      'Ofsted-monitored BSO "Outstanding" in all 8 evaluation standards',
      'Accredited member of COBIS, HMC, IAPS, and FOBISIA',
      'IB World School with authorised IB Diploma Programme since 2008'
    ],
    keyHighlightsFa: [
      'کسب رتبه ممتاز در تمام ۸ استاندارد بازرسی زیر نظر آفستد بریتانیا',
      'عضویت دارای اعتبار در نهادهای COBIS، HMC، IAPS و فدراسیون FOBISIA',
      'مدرسه رسمی شبکه جهانی IB با مجوز برگزاری دیپلم بین‌المللی از سال ۲۰۰۸'
    ],
    ctaTextEn: 'Read Full BSO Inspection Report',
    ctaTextFa: 'مشاهده متن کامل گزارش بازرسی BSO'
  },
  campus: {
    id: 'campus',
    titleEn: 'Campus Facilities & The Centenary Building',
    titleFa: 'امکانات مدرن پردیس و ساختمان صدمین سالگرد',
    categoryEn: 'Campus Life',
    categoryFa: 'فضای آموزشی و پردیس',
    heroImage: '/assets/photos/campus-map.jpg',
    summaryEn: 'Tanglin’s 5.5-hectare campus in One-North Singapore boasts state-of-the-art learning environments, Olympic-sized swimming pool, 15m climbing wall, and cutting-edge arts suites.',
    summaryFa: 'پردیس ۵.۵ هکتاری تانگلین در وان-نورث سنگاپور با ساختمان ۱۱ طبقه صدمین سالگرد، استخر المپیک ۵۰ متری، دیواره صخره‌نوردی ۱۵ متری و استودیوهای پیشرفته هنر و رباتیک تجهیز شده است.',
    contentEn: [
      'The Centenary Building: An 11-storey landmark facility featuring an Olympic-grade 50m aquatic training pool, a 15-metre competition climbing wall, gymnastic training centre, music technology suites, and the Institute@Tanglin.',
      'Libraries: Four bespoke age-specific libraries with over 100,000 physical volumes and access to thousands of digital scholarly journals.',
      'Performing Arts: Nixon Building theatre with 400-seat capacity, professional lighting rigs, recording studios, black box drama spaces, and soundproof music practice suites.'
    ],
    contentFa: [
      'ساختمان صدمین سالگرد: سازه‌ای ۱۱ طبقه و شاهکار با استخر آموزشی ۵۰ متری المپیک، دیواره صخره‌نوردی مسابقه‌ای ۱۵ متری، سالن ژیمناستیک حرفه‌ای و پژوهشکده اینستیتو تانگلین.',
      'کتابخانه‌ها: چهار کتابخانه اختصاصی برای هر رده سنی با بیش از ۱۰۰ هزار جلد کتاب و دسترسی به پایگاه‌های مقالات معتبر جهان.',
      'هنرهای نمایشی: تالار تئاتر ساختمان نیکسون با ظرفیت ۴۰۰ نفر، سیستم‌های نورپردازی حرفه‌ای، استودیوهای ضبط صدا و اتاق‌های آکوستیک تمرین موسیقی.'
    ],
    keyHighlightsEn: [
      '50m covered Olympic-standard swimming pool',
      '15-metre IFSC certified competition climbing wall',
      'Cutting-edge STEM & Robotics laboratories with 3D fabrication',
      'Junior Arts Centre and 400-seat Theatre Auditorium'
    ],
    keyHighlightsFa: [
      'استخر سرپوشیده ۵۰ متری مطابق با استانداردهای المپیک',
      'دیواره صخره‌نوردی ۱۵ متری با تاییدیه فدراسیون جهانی سنگ‌نوردی',
      'آزمایشگاه‌های پیشرفته رباتیک، هوش مصنوعی و پرینت سه‌بعدی',
      'مرکز هنر اختصاصی کودکان و تالار آمفی‌تئاتر ۴۰۰ نفره'
    ],
    ctaTextEn: 'Book a Personal Campus Tour',
    ctaTextFa: 'رزرو بازدید اختصاصی از پردیس'
  },
  governance: {
    id: 'governance',
    titleEn: 'Governance & Board of Governors',
    titleFa: 'ساختار حاکمیت سازمانی و هیئت امنا',
    categoryEn: 'Leadership',
    categoryFa: 'هدایت و راهبری',
    heroImage: '/assets/photos/governance.jpg',
    summaryEn: 'Tanglin Trust School operates as an independent registered charity and not-for-profit educational foundation governed by an experienced Board of Governors.',
    summaryFa: 'مدرسه تانگلین به عنوان یک موسسه خیریه ثبت‌شده و بنیاد آموزشی غیرانتفاعی توسط هیئت امنایی باسابقه و برجسته هدایت می‌شود.',
    contentEn: [
      'Tanglin Trust Ltd is registered under the Singapore Charities Act (UEN: 196100114C). There are no private shareholders or commercial owners.',
      'Every cent of revenue generated through school fees and donations is 100% reinvested into educational programs, faculty compensation, campus enhancements, and student wellbeing.',
      'The Board of Governors is led by Mr. Dominic Nixon, working alongside sub-committees for Education, Finance & Audit, Building & Development, and Governance & Nominations.'
    ],
    contentFa: [
      'بنیاد امانی تانگلین با شماره ثبت ۱۹۶۱۰۰۱۱۴C در سنگاپور ثبت شده و فاقد هرگونه سهام‌دار خصوصی یا ذی‌نفع تجاری است.',
      'تمامی درآمدهای حاصل از شهریه و کمک‌های مردمی ۱۰۰٪ صرف توسعه برنامه‌های درسی، حفظ اساتید برتر بین‌المللی و بازسازی زیرساخت‌های پردیس می‌شود.',
      'ریاست هیئت امنا بر عهده آقای دومینیک نیکسون است که به همراه کمیته‌های تخصصی آموزش، مالی و حسابرسی، عمران و توسعه، و نظارت قانونی فعالیت می‌کنند.'
    ],
    keyHighlightsEn: [
      '100% Not-for-Profit charitable status with all funds reinvested in school',
      'Independent Board of Governors with diverse corporate & academic expertise',
      'Full compliance with Singapore Committee for Private Education (CPE) standards'
    ],
    keyHighlightsFa: [
      'وضعیت ۱۰۰٪ غیرانتفاعی با سرمایه‌گذاری کامل درآمدها در آموزش کودکان',
      'هیئت امنای مستقل متشکل از نخبگان دانشگاهی، حقوقی و کارآفرینان برجسته',
      'انطباق کامل با چارچوب‌ها و استانداردهای کمیته آموزش خصوصی سنگاپور (CPE)'
    ],
    ctaTextEn: 'View Board of Governors Directory',
    ctaTextFa: 'مشاهده اعضای هیئت امنای تانگلین'
  }
};
