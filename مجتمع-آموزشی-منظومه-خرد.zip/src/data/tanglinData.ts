import { NavItem, StatItem, SchoolStage, TimelineMilestone, CampusFacility, AcademicMetric, NewsItem } from '../types';

export const navigationItems: NavItem[] = [
  {
    id: 'about',
    titleEn: 'About Tanglin',
    titleFa: 'درباره تانگلین',
    href: '#about-section',
    children: [
      {
        titleEn: 'Welcome from the CEO',
        titleFa: 'پیام مدیرعامل و سرپرست مدرسه',
        descriptionEn: 'A personal message from CEO Craig Considine on Tanglin’s vision and community.',
        descriptionFa: 'پیام شخصی کریگ کانسیدین، مدیرعامل تانگلین، درباره چشم‌انداز و جامعه مدرسه.',
        href: '#ceo-welcome'
      },
      {
        titleEn: 'Our Centenary (1925–2025)',
        titleFa: 'جشن صد سالگی تانگلین (۱۹۲۵–۲۰۲۵)',
        descriptionEn: 'Celebrating 100 years of British-based education in Singapore and Southeast Asia.',
        descriptionFa: 'گرامیداشت یک قرن آموزش بریتانیایی در سنگاپور و جنوب شرق آسیا.',
        href: '#centenary'
      },
      {
        titleEn: 'Mission, Vision & Values',
        titleFa: 'ماموریت، چشم‌انداز و ارزش‌ها',
        descriptionEn: 'Fostering Respect, Responsibility, and Purpose across our diverse community.',
        descriptionFa: 'پرورش احترام، مسئولیت‌پذیری و هدفمندی در سراسر جامعه مدرسه.',
        href: '#mission-values'
      },
      {
        titleEn: 'Academic Results & Pathways',
        titleFa: 'نتایج درخشان تحصیلی و مسیرها',
        descriptionEn: 'Outstanding IB Diploma and A-Level outcomes opening doors to top world universities.',
        descriptionFa: 'نتایج ممتاز دیپلم بین‌المللی IB و آزمون‌های A-Level برای ورود به برترین دانشگاه‌ها.',
        href: '#academics'
      },
      {
        titleEn: 'Inspections & Accreditations',
        titleFa: 'بازرسی‌ها و استانداردهای بین‌المللی',
        descriptionEn: 'Rated Outstanding in every category by British Schools Overseas (BSO).',
        descriptionFa: 'کسب رتبه ممتاز در تمام شاخص‌ها از سوی سازمان مدارس بریتانیایی خارج از کشور (BSO).',
        href: '#inspections'
      },
      {
        titleEn: 'Campus & Centenary Building',
        titleFa: 'پردیس و ساختمان صدمین سالگرد',
        descriptionEn: 'Explore our world-class 50m pool, climbing wall, robotics suites, and arts theatre.',
        descriptionFa: 'مشاهده امکانات استخر ۵۰ متری المپیک، دیواره صخره‌نوردی، آزمایشگاه رباتیک و تالار نمایش.',
        href: '#campus'
      }
    ]
  },
  {
    id: 'admissions',
    titleEn: 'Admissions',
    titleFa: 'پذیرش و ثبت‌نام',
    href: '#admissions-section',
    children: [
      {
        titleEn: 'How to Apply',
        titleFa: 'مراحل ثبت‌نام',
        descriptionEn: 'Step-by-step guidance on entry criteria, assessment, and admissions rounds.',
        descriptionFa: 'راهنمای گام‌به‌گام شرایط ورود، سنجش و دوره‌های پذیرش تحصیلی.',
        href: '#admissions-section'
      },
      {
        titleEn: 'Fees & Structure',
        titleFa: 'شهریه و هزینه‌ها',
        descriptionEn: 'Transparent not-for-profit fee structure with full educational reinvestment.',
        descriptionFa: 'ساختار شفاف شهریه موسسه غیرانتفاعی با سرمایه‌گذاری تمام عواید در آموزش.',
        href: '#admissions-section'
      },
      {
        titleEn: 'Book a Campus Visit',
        titleFa: 'رزرو بازدید حضوری از پردیس',
        descriptionEn: 'Experience the vibrant atmosphere of our One-North campus in person.',
        descriptionFa: 'تجربه حضور و بازدید مستقیم از پردیس مدرن وان-نورث سنگاپور.',
        href: '#book-tour'
      }
    ]
  },
  {
    id: 'learning',
    titleEn: 'Learning & Schools',
    titleFa: 'آموزش و مقاطع',
    href: '#schools',
    children: [
      {
        titleEn: 'Infant School (Ages 3–7)',
        titleFa: 'مدرسه خردسالان (۳ تا ۷ سال)',
        descriptionEn: 'Nurturing curiosity, joy, and foundational literacy through play-based discovery.',
        descriptionFa: 'پرورش کنجکاوی و سواد پایه از طریق یادگیری مبتنی بر بازی و کاوش.',
        href: '#schools'
      },
      {
        titleEn: 'Junior School (Ages 7–11)',
        titleFa: 'مدرسه کودکان (۷ تا ۱۱ سال)',
        descriptionEn: 'Building academic confidence, critical inquiry, and compassionate friendships.',
        descriptionFa: 'تقویت اعتماد به نفس علمی، تفکر نقادانه و مهارت‌های فردی و اجتماعی.',
        href: '#schools'
      },
      {
        titleEn: 'Senior School (Ages 11–16)',
        titleFa: 'دبیرستان دوره اول (۱۱ تا ۱۶ سال)',
        descriptionEn: 'Rigorous British National Curriculum culminating in (I)GCSE excellence.',
        descriptionFa: 'برنامه درسی ملی بریتانیا منتهی به امتحانات معتبر بین‌المللی (I)GCSE.',
        href: '#schools'
      },
      {
        titleEn: 'Sixth Form (Ages 16–18)',
        titleFa: 'کالج پیش‌دانشگاهی (۱۶ تا ۱۸ سال)',
        descriptionEn: 'Singapore’s premier dual pathway offering both A-Levels and IB Diploma.',
        descriptionFa: 'تنها مرکز دو مسیره در سنگاپور با ارائه همزمان دوره‌های A-Level و دیپلم IB.',
        href: '#dual-pathway'
      }
    ]
  },
  {
    id: 'school-life',
    titleEn: 'School Life',
    titleFa: 'زندگی در مدرسه',
    href: '#campus',
    children: [
      {
        titleEn: 'Co-Curricular & Sports',
        titleFa: 'فعالیت‌های فوق برنامه و ورزش',
        descriptionEn: 'Over 140 CCAs, competitive sports teams, gymnastics, and swimming academies.',
        descriptionFa: 'بیش از ۱۴۰ باشگاه فوق برنامه، تیم‌های ورزشی، ژیمناستیک و آکادمی شنا.',
        href: '#campus'
      },
      {
        titleEn: 'The Arts & Music',
        titleFa: 'هنر و موسیقی',
        descriptionEn: 'Vibrant orchestral ensembles, drama productions in the 400-seat theatre, and fine arts.',
        descriptionFa: 'ارکسترهای پرنشاط، تولیدات تئاتر در سالن ۴۰۰ نفره و آتلیه‌های هنرهای تجسمی.',
        href: '#campus'
      },
      {
        titleEn: 'Pastoral Care & Wellbeing',
        titleFa: 'سلامت روان و مراقبت پرورشی',
        descriptionEn: 'Holistic support systems ensuring every student feels valued, safe, and heard.',
        descriptionFa: 'سیستم جامع حمایتی برای تضمین امنیت روانی، تعلق خاطر و سلامت دانش‌آموزان.',
        href: '#ceo-welcome'
      }
    ]
  },
  {
    id: 'community',
    titleEn: 'Community & Centenary',
    titleFa: 'جامعه و فارغ‌التحصیلان',
    href: '#centenary'
  }
];

export const keyStats: StatItem[] = [
  {
    value: '1925',
    labelEn: 'Founded in Singapore',
    labelFa: 'تاسیس در سنگاپور',
    detailEn: 'Celebrating 100 Years of British international education excellence',
    detailFa: 'جشن یک قرن پیشگامی در آموزش بریتانیایی در جنوب شرق آسیا'
  },
  {
    value: '2,800+',
    labelEn: 'Students from 55+ Nations',
    labelFa: 'دانش‌آموز از ۵۵+ ملیت',
    detailEn: 'A harmonious, warm, and internationally-minded global community',
    detailFa: 'جامعه‌ای صمیمی، پویا و با نگاهی جهانی در قلب سنگاپور'
  },
  {
    value: 'Dual Pathway',
    labelEn: 'IB Diploma & A-Levels',
    labelFa: 'مسیر دوگانه IB و A-Level',
    detailEn: 'The only school in Singapore offering this unique Sixth Form choice',
    detailFa: 'تنها مدرسه بین‌المللی سنگاپور با امکان انتخاب بین A-Level و دیپلم IB'
  },
  {
    value: '39.1',
    labelEn: 'Average IB Score (World: 30.2)',
    labelFa: 'میانگین نمره IB (جهانی: ۳۰.۲)',
    detailEn: 'Consistently ranked among the top international schools worldwide',
    detailFa: 'همواره در صدر رتبه‌بندی برترین مدارس بین‌المللی جهان'
  },
  {
    value: 'Outstanding',
    labelEn: 'BSO Inspection Rating',
    labelFa: 'رتبه عالی در بازرسی BSO',
    detailEn: 'Awarded the highest grade across all inspection categories',
    detailFa: 'بالاترین رتبه ممکن در تمامی بخش‌های نظارتی سازمان مدارس بریتانیا'
  },
  {
    value: '100%',
    labelEn: 'Not-For-Profit Trust',
    labelFa: 'موسسه صددرصد غیرانتفاعی',
    detailEn: 'Every single dollar reinvested into student learning and facilities',
    detailFa: 'سرمایه‌گذاری کامل کلیه شهریه‌ها در جهت ارتقای امکانات و آموزش دانش‌آموزان'
  }
];

export const schoolStages: SchoolStage[] = [
  {
    id: 'infant',
    nameEn: 'Infant School',
    nameFa: 'مدرسه خردسالان',
    ageRange: 'Ages 3–7',
    yearGroupsEn: 'Nursery to Year 2',
    yearGroupsFa: 'مهد کودک تا پایه دوم',
    headEn: 'Victoria Thomas (Head of Infant School)',
    headFa: 'ویکتوریا توماس (مدیر مدرسه خردسالان)',
    descriptionEn: 'Tanglin’s Infant School provides a joyful, stimulating, and nurturing environment where children discover a lifelong love of learning. Combining the Early Years Foundation Stage (EYFS) and Key Stage 1 curriculum with outdoor learning, bespoke ateliers, and specialist music and physical education.',
    descriptionFa: 'مدرسه خردسالان تانگلین محیطی شاد، پرانرژی و امن فراهم می‌کند که در آن کودکان اشتیاق همیشگی به یادگیری را کشف می‌کنند. این مقطع با تلفیق برنامه دوران آغازین بریتانیا با آموزش در فضای باز، آتلیه‌های خلاقانه و معلمان متخصص هنر و ورزش همراه است.',
    highlightsEn: [
      'Reggio Emilia inspired exploratory ateliers',
      'Specialist music, swim, and PE coaching from age 3',
      'Bilingual exposure with Chinese Mandarin immersion',
      'Purpose-built outdoor natural play sensory gardens'
    ],
    highlightsFa: [
      'آتلیه‌های کاوش و خلاقیت الهام‌گرفته از متد رجیو امیلیا',
      'آموزش تخصصی موسیقی، شنا و ورزش از سن ۳ سالگی',
      'آشنایی زبانی دوگانه همراه با آموزش زبان چینی ماندارین',
      'باغ‌های حسی و فضای طبیعی اختصاصی بازی در فضای آزاد'
    ],
    image: 'https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'junior',
    nameEn: 'Junior School',
    nameFa: 'مدرسه کودکان (ابتدایی)',
    ageRange: 'Ages 7–11',
    yearGroupsEn: 'Years 3 to 6',
    yearGroupsFa: 'پایه‌های سوم تا ششم',
    headEn: 'Clare Anderson (Head of Junior School)',
    headFa: 'کلر اندرسون (مدیر مدرسه ابتدایی)',
    descriptionEn: 'The Junior School balances high academic standards with outstanding pastoral care. Students develop resilience, independence, and empathy. The curriculum extends far beyond the classroom into robotics, orchestra, drama, and regional outdoor residential expeditions.',
    descriptionFa: 'مدرسه ابتدایی تانگلین استانداردهای علمی بالا را با پشتیبانی تربیتی دقیق همراه می‌سازد. دانش‌آموزان استقلال فکری، تاب‌آوری و تفکر نقادانه را فرا می‌گیرند و برنامه درسی فراتر از کلاس به آزمایشگاه رباتیک، ارکستر و اردوهای طبیعت‌گردی گسترش می‌یابد.',
    highlightsEn: [
      '1:1 iPad learning with Apple Distinguished School status',
      'Extensive Junior Orchestra, Choir, and Drama festival',
      'Annual residential outdoor education expeditions in SE Asia',
      'Junior House System nurturing sportsmanship and leadership'
    ],
    highlightsFa: [
      'آموزش هوشمند یک‌به‌یک با تبلت‌های اپل و نشان افتخار Apple Distinguished School',
      'ارکستر اختصاصی، گروه کُر و جشنواره سالانه تئاتر کودکان',
      'اردوهای سالانه اکتشافی و مهارتی در طبیعت جنوب شرق آسیا',
      'سیستم گروه‌های ۴گانه مدرسه (Houses) برای پرورش روحیه کار گروهی و رهبری'
    ],
    image: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'senior',
    nameEn: 'Senior School',
    nameFa: 'دبیرستان دوره اول (راهنمایی و سال‌های اول)',
    ageRange: 'Ages 11–16',
    yearGroupsEn: 'Years 7 to 11',
    yearGroupsFa: 'پایه‌های هفتم تا یازدهم',
    headEn: 'Chris Seal (Head of Senior School)',
    headFa: 'کریس سیل (مدیر دبیرستان)',
    descriptionEn: 'In Senior School, students transition into rigorous subject discipline, guided by world-class subject specialists. The curriculum builds toward Cambridge and Edexcel (I)GCSE examinations, complemented by debate, international MUN, competitive athletics, and community service.',
    descriptionFa: 'در مقطع دبیرستان، دانش‌آموزان زیر نظر اساتید برجسته رشته‌های تخصصی وارد مباحث عمیق علمی می‌شوند. این دوره زمینه درخشش در امتحانات بین‌المللی (I)GCSE را همراه با مسابقات شبیه‌سازی سازمان ملل (MUN)، دو و میدانی قهرمانی و کارهای داوطلبانه فراهم می‌کند.',
    highlightsEn: [
      'Over 28 diverse (I)GCSE subject choices available',
      '78% of all grades awarded A* or A (Grades 9–7)',
      'Global Duke of Edinburgh International Award programme',
      'State-of-the-art Nixon science labs & digital design suites'
    ],
    highlightsFa: [
      'ارائه بیش از ۲۸ درس متنوع در امتحانات نهایی (I)GCSE',
      'کسب رتبه A* یا A در بیش از ۷۸٪ کل نتایج دانش‌آموزان',
      'برنامه بین‌المللی اعطای جایزه دوک ادینبرو (Duke of Edinburgh)',
      'آزمایشگاه‌های پیشرفته علوم نیکسون و آتلیه‌های طراحی دیجیتال'
    ],
    image: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'sixth-form',
    nameEn: 'Sixth Form',
    nameFa: 'کالج پیش‌دانشگاهی (سیکث فرم)',
    ageRange: 'Ages 16–18',
    yearGroupsEn: 'Years 12 & 13',
    yearGroupsFa: 'پایه‌های دوازدهم و سیزدهم',
    headEn: 'Richard Foster (Head of Sixth Form)',
    headFa: 'ریچارد فاستر (مدیر سیکث فرم)',
    descriptionEn: 'The only international school in Singapore offering a structured dual pathway: students may choose between A-Levels (deep specialization) or the International Baccalaureate (IB) Diploma (broad interdisciplinary mastery). Graduates matriculate to Oxford, Cambridge, Ivy League, and leading global universities.',
    descriptionFa: 'تنها مدرسه بین‌المللی سنگاپور با سیستم دو مسیره: دانش‌آموزان می‌توانند بر اساس علاقه و اهداف دانشگاهی، میان آزمون‌های تخصصی A-Level یا دیپلم بین‌المللی چندرشته‌ای IB انتخاب کنند. فارغ‌التحصیلان تانگلین پذیرش مستقیم آکسفورد، کمبریج، آیوی لیگ و دانشگاه‌های برتر دنیا را کسب می‌کنند.',
    highlightsEn: [
      'Average IB Diploma score of 39.1 points (World average: 30.2)',
      '58% A* or A grades in A-Levels with a 100% overall pass rate',
      'Dedicated bespoke university & careers guidance team',
      'Collegiate Sixth Form Centre with private seminar & study halls'
    ],
    highlightsFa: [
      'میانگین نمره ۳۹.۱ در دیپلم بین‌المللی IB (میانگین جهانی: ۳۰.۲)',
      '۵۸٪ نمرات A* یا A در آزمون‌های A-Level و قبولی ۱۰۰٪',
      'تیم مشاوره اختصاصی برای پذیرش در دانشگاه‌های تراز اول انگلستان، آمریکا و جهان',
      'مرکز دانشگاهی سیکث فرم با سالن‌های سمینار، کتابخانه مستقل و فضاهای پژوهشی'
    ],
    image: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1200&q=80'
  }
];

export const timelineMilestones: TimelineMilestone[] = [
  {
    year: '1925',
    titleEn: 'Foundation by Anne Griffith-Jones',
    titleFa: 'بنیان‌گذاری توسط آن گریفیث-جونز',
    descriptionEn: 'Founded with just five pupils in the grounds of the Tanglin Club to serve British families in Singapore with traditional values and academic rigor.',
    descriptionFa: 'آغاز فعالیت مدرسه با تنها ۵ دانش‌آموز در محوطه کلوب تانگلین برای خانواده‌های مقیم سنگاپور بر پایه استانداردهای غنی بریتانیایی.',
    category: 'Foundation',
    image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80'
  },
  {
    year: '1958',
    titleEn: 'Tanglin Trust Established',
    titleFa: 'ثبت خیریه و سازمان امنای تانگلین',
    descriptionEn: 'The school became a registered non-profit educational trust, ensuring that all proceeds were directly reinvested in student learning and faculty development.',
    descriptionFa: 'تبدیل مدرسه به یک نهاد غیرانتفاعی خیریه آموزشی برای تضمین سرمایه‌گذاری تمام عواید در تجهیز امکانات و استخدام بهترین اساتید بین‌المللی.',
    category: 'Foundation',
    image: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=800&q=80'
  },
  {
    year: '1981',
    titleEn: 'Move to Portsdown Road Campus',
    titleFa: 'انتقال به پردیس اختصاصی پورتزداون',
    descriptionEn: 'Tanglin consolidated onto its expansive leafy campus on Portsdown Road in the One-North research and high-tech educational hub of Singapore.',
    descriptionFa: 'تجمیع تمام بخش‌های مدرسه در پردیس سرسبز و پهناور جاده پورتزداون در منطقه فناوری و علمی وان-نورث سنگاپور.',
    category: 'Growth',
    image: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=800&q=80'
  },
  {
    year: '2009',
    titleEn: 'Pioneering the Dual Pathway',
    titleFa: 'پیشگامی در مسیر دوگانه Sixth Form',
    descriptionEn: 'Tanglin made history by becoming the only school in Singapore to offer Sixth Form students the choice between both A-Levels and the IB Diploma Programme.',
    descriptionFa: 'ثبت رکوردی کم‌نظیر در سنگاپور با ارائه حق انتخاب همزمان دیپلم IB و آزمون‌های تخصصی A-Level به دانش‌آموزان پیش‌دانشگاهی.',
    category: 'Academic',
    image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=800&q=80'
  },
  {
    year: '2023',
    titleEn: 'The Tanglin Centenary Building Opens',
    titleFa: 'افتتاح ساختمان مجلل صدمین سالگرد',
    descriptionEn: 'Opening of the landmark 11-storey Centenary Building featuring an Olympic 50m pool, 15m climbing gym, Institute of Learning, and gymnastics center.',
    descriptionFa: 'بهره‌برداری از ساختمان ۱۱ طبقه صدمین سالگرد شامل استخر ۵۰ متری المپیک، دیواره ۱۵ متری صخره‌نوردی، انستیتوی یادگیری و سالن ژیمناستیک حرفه‌ای.',
    category: 'Centenary',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80'
  },
  {
    year: '2025',
    titleEn: '100 Years: Generations of Excellence',
    titleFa: 'یک قرن تعالی (جشن ۱۰۰ سالگی تانگلین)',
    descriptionEn: 'Centenary celebrations honouring a century of shaping compassionate world leaders, visionary innovators, and outstanding global scholars.',
    descriptionFa: 'گرامیداشت یک قرن تربیت رهبران کارآمد، پژوهشگران برجسته و انسان‌های بااخلاق و تاثیرگذار در جامعه جهانی.',
    category: 'Centenary',
    image: 'https://images.unsplash.com/photo-1525921429624-479b6a26d84d?auto=format&fit=crop&w=800&q=80'
  }
];

export const campusFacilities: CampusFacility[] = [
  {
    id: 'centenary-building',
    nameEn: 'Tanglin Centenary Building',
    nameFa: 'ساختمان صدمین سالگرد تانگلین',
    category: 'Sports',
    descriptionEn: 'An 11-storey architectural masterpiece dedicated to athletic excellence, wellbeing, and teacher development, inaugurated for our 100th year.',
    descriptionFa: 'شاهکار معماری ۱۱ طبقه اختصاص یافته به ورزش قهرمانی، سلامت روان و مرکز توانمندسازی اساتید، احداث شده به مناسبت صدمین سالگرد.',
    featuresEn: [
      '50m FINA-specification 10-lane covered Olympic swimming pool',
      '15-metre indoor competition climbing wall',
      'Tanglin Institute of Learning CPD & innovation centre',
      'Elite Gymnastics training centre with full foam pit'
    ],
    featuresFa: [
      'استخر سرپوشیده ۵۰ متری ۱۰ خطه استاندارد مسابقات بین‌المللی فینا',
      'دیواره صخره‌نوردی مسابقه‌ای داخل سالن با ارتفاع ۱۵ متر',
      'انستیتوی پژوهش و نوآوری آموزشی تانگلین (Institute of Learning)',
      'سالن تخصصی ژیمناستیک با پیت‌های ایمن اسفنجی'
    ],
    image: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'theatre-arts',
    nameEn: 'The Griffith Theatre & Arts Centre',
    nameFa: 'تالار تئاتر گریفیث و مرکز هنرهای نمایشی',
    category: 'Arts',
    descriptionEn: 'A state-of-the-art 400-seat professional proscenium theatre equipped with modern automated lighting and acoustics for student musicals and drama.',
    descriptionFa: 'سالن تئاتر ۴۰۰ نفره حرفه‌ای مجهز به مدرن‌ترین سیستم‌های نورپردازی دیجیتال و آکوستیک جهت برگزاری کنسرت‌ها و نمایش‌های موزیکال.',
    featuresEn: [
      '400-seat multi-tier professional auditorium',
      'Black-box drama studio for immersive workshop rehearsals',
      'Acoustically isolated music practice suites and recording studio',
      'Full digital mixing console and staging workshop'
    ],
    featuresFa: [
      'سالن اصلی با ۴۰۰ صندلی ارگونومیک چندطبقه و صحنه استاندارد',
      'استودیوی جعبه سیاه (Black-box) برای تمرینات خلاقانه تئاتر',
      'اتاق‌های عایق صدا جهت تمرین ساز و استودیوی ضبط صدا',
      'میز میکس پیشرفته دیجیتال و کارگاه دکورسازی'
    ],
    image: 'https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'science-stem',
    nameEn: 'Nixon Science & STEM Laboratories',
    nameFa: 'آزمایشگاه‌های علوم و فناوری نیکسون',
    category: 'Academic',
    descriptionEn: 'Twenty purpose-designed science laboratories and maker-spaces where chemistry, physics, biology, robotics, and environmental science flourish.',
    descriptionFa: 'بیست آزمایشگاه تخصصی و کارگاه ساخت دیجیتال که در آنها فیزیک، شیمی، زیست‌شناسی، رباتیک و علوم محیطی به صورت عملی آموزش داده می‌شوند.',
    featuresEn: [
      '20 fully equipped university-grade laboratory stations',
      '3D printing, laser-cutting, and CNC prototyping maker-space',
      'Dedicated VEX Robotics competitive arena',
      'Greenhouse and micro-propagation biology garden'
    ],
    featuresFa: [
      '۲۰ ایستگاه آزمایشگاهی استاندارد دانشگاهی با بالاترین ضرایب ایمنی',
      'کارگاه ساخت مجهز به پرینترهای سه‌بعدی و برش لیزری CNC',
      'میدان مسابقات رباتیک بین‌المللی VEX',
      'گلخانه پژوهشی زیست‌فناوری و باغبانی علمی'
    ],
    image: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'sports-fields',
    nameEn: 'Sports Fields & Berrick Sports Complex',
    nameFa: 'زمین‌های ورزشی و مجتمع ورزشی بریک',
    category: 'Sports',
    descriptionEn: 'Expansive all-weather playing pitches, multi-purpose sports halls, tennis courts, and fitness suites fostering physical health and team spirit.',
    descriptionFa: 'زمین‌های چمن مصنوعی استاندارد برای تمام فصول، سالن‌های چندمنظوره سرپوشیده، زمین تنیس و سالن‌های بدنسازی برای آمادگی جسمانی دانش‌آموزان.',
    featuresEn: [
      'All-weather FIFA-certified synthetic rugby and football field',
      '4 full-size outdoor tennis and netball courts',
      'Air-conditioned indoor multi-court sports halls',
      'Cardio & strength conditioning fitness gym with coaching staff'
    ],
    featuresFa: [
      'زمین چمن مصنوعی استاندارد بین‌المللی فیفا برای فوتبال و راگبی',
      '۴ زمین تنیس و نت‌بال با نورافکن‌های شبانه',
      'سالن‌های ورزشی چندمنظوره با سیستم تهویه مطبوع پیشرفته',
      'باشگاه بدنسازی و پرورش اندام همراه با مربیان بدنساز حرفه‌ای'
    ],
    image: 'https://images.unsplash.com/photo-1526232761682-d26e03ac148e?auto=format&fit=crop&w=1000&q=80'
  }
];

export const academicMetrics: AcademicMetric[] = [
  {
    titleEn: 'IB Diploma Average',
    titleFa: 'میانگین نمره دیپلم IB',
    stat: '39.1',
    benchmarkEn: 'Global Average: 30.2 (Maximum: 45)',
    benchmarkFa: 'میانگین جهانی: ۳۰.۲ (حداکثر نمره: ۴۵)',
    detailsEn: '3 students scored a maximum 45 points; over 52% scored 40+ points, placing them in the top 3% worldwide.',
    detailsFa: '۳ دانش‌آموز نمره کامل ۴۵ را کسب کردند و بیش از ۵۲٪ فارغ‌التحصیلان نمره ۴۰ به بالا گرفتند (جزو ۳٪ برتر جهان).'
  },
  {
    titleEn: 'A-Level Excellence',
    titleFa: 'نتایج امتحانات A-Level',
    stat: '58% A*/A',
    benchmarkEn: 'UK National Average: 27.2%',
    benchmarkFa: 'میانگین سراسری بریتانیا: ۲۷.۲٪',
    detailsEn: '82% of all entries achieved A* to B, with a 100% overall pass rate across 24 distinct subject areas.',
    detailsFa: '۸۲٪ کل نمرات در رده‌های عالی A* تا B ثبت شد و نرخ قبولی کلی ۱۰۰٪ در ۲۴ رشته تخصصی حاصل گردید.'
  },
  {
    titleEn: '(I)GCSE High Grades',
    titleFa: 'امتحانات بین‌المللی (I)GCSE',
    stat: '78% 9–7',
    benchmarkEn: 'Equivalent to A* or A grades',
    benchmarkFa: 'معادل نمرات A* و A در سیستم سنتی',
    detailsEn: 'Tanglin students consistently outperform independent school benchmarks in the United Kingdom.',
    detailsFa: 'دانش‌آموزان تانگلین به طور پیوسته نتایجی فراتر از مدارس خصوصی برتر خود بریتانیا کسب می‌کنند.'
  },
  {
    titleEn: 'University Matriculation',
    titleFa: 'پذیرش در برترین دانشگاه‌ها',
    stat: '98%',
    benchmarkEn: 'First or Second Choice Institutions',
    benchmarkFa: 'قبولی در انتخاب اول یا دوم داوطلبان',
    detailsEn: 'Destinations include Oxford, Cambridge, Imperial, UCL, Harvard, Stanford, Columbia, NUS, and Melbourne.',
    detailsFa: 'مقاصد اصلی شامل آکسفورد، کمبریج، امپریال، هاروارد، استنفورد، کلمبیا، دانشگاه ملی سنگاپور و ملبورن است.'
  }
];

export const latestNews: NewsItem[] = [
  {
    id: 'news-1',
    date: 'March 2025',
    titleEn: 'Centenary Gala: Celebrating 100 Years of Educational Impact',
    titleFa: 'مراسم باشکوه صدمین سالگرد: یک قرن تاثیرگذاری ماندگار آموزشی',
    summaryEn: 'Alumni, parents, and distinguished dignitaries gathered to celebrate Tanglin’s 100th anniversary at the Marina Bay Sands Grand Ballroom.',
    summaryFa: 'گردهمایی باحضور فارغ‌التحصیلان، اولیا و مهمانان ویژه بین‌المللی به مناسبت یکصد سالگی تاسیس تانگلین در سنگاپور.',
    category: 'Centenary',
    image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80',
    readTime: '3 min read'
  },
  {
    id: 'news-2',
    date: 'February 2025',
    titleEn: 'Tanglin Named Apple Distinguished School for Fifth Consecutive Term',
    titleFa: 'انتخاب تانگلین به عنوان مدرسه برگزیده اپل برای پنجمین دوره متوالی',
    summaryEn: 'Recognised for continuous innovation in educational technology, digital citizenship, and interactive classroom learning.',
    summaryFa: 'تقدیر از نوآوری مستمر در به کارگیری فناوری‌های نوین آموزشی و شهروندی دیجیتال در تمامی کلاس‌ها.',
    category: 'Innovation',
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80',
    readTime: '2 min read'
  },
  {
    id: 'news-3',
    date: 'January 2025',
    titleEn: 'British Schools Overseas: Outstanding Rating in Every Inspection Area',
    titleFa: 'گزارش بازرسی مدارس بریتانیا: کسب رتبه عالی (Outstanding) در تمام ابعاد',
    summaryEn: 'Inspectors praised the inspirational leadership, exemplary student behaviour, and unparalleled breadth of curriculum.',
    summaryFa: 'تایید کیفیت بی‌نظیر آموزشی، مدیریت تحسین‌برانگیز و گستردگی استثنایی برنامه‌های درسی تانگلین.',
    category: 'Accreditation',
    image: 'https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&w=800&q=80',
    readTime: '4 min read'
  }
];

export const values = [
  {
    id: 'self-awareness',
    titleEn: 'Self-Awareness & Growth Through Feedback',
    titleFa: 'شناخت خود و رشد از دل بازخورد',
    descriptionEn: 'At Kherad, we learn to honestly recognize our strengths and weaknesses, using feedback from others to become better.',
    descriptionFa: 'در خرد یاد می‌گیریم نقاط قوت و ضعف خودمان را بی‌تعارف بشناسیم و از بازخورد دیگران برای بهتر شدن استفاده کنیم.'
  },
  {
    id: 'inquiry',
    titleEn: 'Inquiry & Clear Thinking',
    titleFa: 'پرسش‌گری و تفکر روشن',
    descriptionEn: 'At Kherad, we learn to question, investigate, and reach sound conclusions with an open mind before making decisions.',
    descriptionFa: 'در خرد یاد می‌گیریم پیش از هر تصمیم بپرسیم، بررسی کنیم و با فکر باز به پاسخ درست برسیم.'
  },
  {
    id: 'purposeful-effort',
    titleEn: 'Purposeful Effort for Genuine Impact',
    titleFa: 'تلاش هدفمند برای نتیجه‌ی واقعی',
    descriptionEn: 'For us, the quality and tangible impact of effort matter most, not merely the volume of work or hours spent.',
    descriptionFa: 'برایمان کیفیت و اثر واقعی تلاش مهم است، نه فقط حجم کار یا ساعت‌های زیاد.'
  },
  {
    id: 'society-nature-responsibility',
    titleEn: 'Responsibility to Society & Nature',
    titleFa: 'مسئولیت در قبال جامعه و طبیعت',
    descriptionEn: 'We respect public goods, steward the environment, and engage consciously and ethically with technology.',
    descriptionFa: 'به اموال عمومی احترام می‌گذاریم، از محیط زیست مراقبت می‌کنیم و از فناوری آگاهانه استفاده می‌کنیم.'
  },
  {
    id: 'teamwork',
    titleEn: 'Collaboration & Teamwork',
    titleFa: 'همکاری و کار تیمی',
    descriptionEn: 'We believe togetherness yields the best results; family, student, and school progress hand in hand.',
    descriptionFa: 'باور داریم با هم بودن نتیجه بهتری می‌دهد؛ خانواده، دانش‌آموز و مدرسه دست در دست هم پیش می‌روند.'
  },
  {
    id: 'honesty',
    titleEn: 'Honesty & Transparency in All Relationships',
    titleFa: 'صداقت و شفافیت در همه‌ی روابط',
    descriptionEn: 'Our words match our actions; we report honestly, honor our commitments, and safeguard private trust.',
    descriptionFa: 'حرف و عملمان یکی است؛ صادقانه گزارش می‌دهیم، به قول‌هایمان پایبندیم و امانت‌دار اطلاعات هستیم.'
  },
  {
    id: 'holistic-growth',
    titleEn: 'Holistic Development & Wellbeing',
    titleFa: 'رشد همه‌جانبه',
    descriptionEn: 'Academics is only one facet of life; we care deeply about mental health, sports, arts, and inner peace.',
    descriptionFa: 'درس فقط یک بخش از زندگی دانش‌آموز است؛ به سلامت روان، ورزش، هنر و آرامش او هم اهمیت می‌دهیم.'
  },
  {
    id: 'kindness',
    titleEn: 'Kindness & Respect for All',
    titleFa: 'مهربانی و احترام',
    descriptionEn: 'Every individual at Kherad, regardless of age or ability, is seen, heard, and treated with unconditional dignity.',
    descriptionFa: 'هر نفر در خرد، فارغ از سن و توانایی‌اش، دیده می‌شود، شنیده می‌شود و با احترام با او رفتار می‌شود.'
  }
];
