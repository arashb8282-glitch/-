export interface SitemapSubItem {
  id: string;
  title: string;
  englishTitle?: string;
  category?: string;
  description?: string;
  englishDescription?: string;
  tag?: string;
  isHeader?: boolean;
}

export interface SitemapCategory {
  id: string;
  title: string;
  englishTitle: string;
  iconName: string;
  summary: string;
  subItems: SitemapSubItem[];
}

export const topSystemLinks = [
  { id: 'lms', title: 'سامانه مدیریت یادگیری', en: 'Learning Management System (LMS)', url: '#lms' },
  { id: 'services', title: 'سامانه خدمات سازمانی', en: 'Organizational Services Portal', url: '#services' },
];

export const sitemapData: SitemapCategory[] = [
  {
    id: 'systems',
    title: 'سامانه‌های الکترونیکی خرد',
    englishTitle: 'Kherad Portals & Systems',
    iconName: 'Laptop',
    summary: 'دسترسی سریع به سامانه‌های الکترونیکی خرد شامل سامانه مدیریت یادگیری و سامانه خدمات سازمانی.',
    subItems: [
      { 
        id: 'lms', 
        title: 'سامانه مدیریت یادگیری (LMS)', 
        englishTitle: 'Learning Management System (LMS)', 
        description: 'پرتال جامع آموزش مجازی، تکالیف درسی، محتوای چندرسانه‌ای، کلاس‌های برخط و کارنامه‌های توصیفی دانش‌آموزان منظومه خرد.' 
      },
      { 
        id: 'services', 
        title: 'سامانه خدمات سازمانی', 
        englishTitle: 'Organizational Services Portal', 
        description: 'پرتال یکپارچه امور اداری، خدمات پرسنلی، ارتباط با اولیا، درخواست‌های مالی و اداری و اتوماسیون جامع سازمانی خرد.' 
      },
    ]
  },
  {
    id: 'about',
    title: 'درباره خرد',
    englishTitle: 'About Kherad',
    iconName: 'Building',
    summary: 'تاسیس ۱۳۷۹ در محله ولنجک تهران با مساحت ۱۲٬۰۰۰ متر مربع، ۷ طبقه آموزشی، محیطی یادگیرنده و پیشرو در توسعه فردی.',
    subItems: [
      { id: 'about-main', title: 'درباره خرد', englishTitle: 'About Kherad', description: 'آشنایی کلی با منظومه آموزشی و فرهنگی خرد و اهداف بنیادین' },
      { id: 'mission-vision', title: 'مأموریت، چشم‌انداز و ارزش‌های خرد', englishTitle: 'Mission, Vision & Core Values', description: 'ارزش‌های هشت‌گانه خرد؛ راهنمای رفتار روزانه در کلاس، خانواده و تصمیم‌های مدیریتی' },
      { id: 'history', title: 'تاریخچه مدرسه', englishTitle: 'School History & Heritage', description: 'سیر تحول از سال ۱۳۷۹ به همت خیریه بیگم حائری‌زاده تا استقرار در مجتمع آموزشی خرد (ولنجک)' },
      { id: 'results', title: 'نتایج تحصیلی', englishTitle: 'Academic Results & Admissions', description: 'درخشش در کنکور سراسری، مدال‌های المپیادهای ملی و جهانی' },
      { id: 'awards', title: 'جوایز و افتخارات', englishTitle: 'Awards & Distinctions', description: 'مقام‌های برتر جشنواره‌های خوارزمی، روبوکاپ و مسابقات علمی و فرهنگی' },
      { id: 'virtual-tour', title: 'بازدید مجازی', englishTitle: '360° Virtual Campus Tour', description: 'گشت ۳۶۰ درجه در طبقات، آزمایشگاه‌ها، کتابخانه‌ها و آتلیه‌ها' },
      { id: 'management', title: 'ساختار مدیریتی', englishTitle: 'Governance & Leadership', description: 'شورای راهبری، هیئت امنا و کمیته‌های علمی و اجرایی منظومه خرد' },
      { id: 'contact', title: 'تماس با ما', englishTitle: 'Contact Us', description: 'آدرس ولنجک، تلفن‌های مستقیم واحدها، ایمیل و موقعیت جغرافیایی' },
      { id: 'sustainability', title: 'محیط زیست و توسعه پایدار', englishTitle: 'Environment & Sustainability', description: 'برآمده از ارزش مسئولیت در قبال جامعه و طبیعت؛ تفکیک پسماند، مدرسه سبز، بهینه‌سازی انرژی و سواد فناورانه' },
      { id: 'alumni', title: 'فارغ‌التحصیلان', englishTitle: 'Alumni Network', description: 'شبکه ارتباطی فارغ‌التحصیلان خرد بر اساس مصاحبه‌های تیم کتاب سال' },
      { id: 'kheradnameh', title: 'خردنامه', englishTitle: 'Kheradnameh Journal', description: 'نشریه تخصصی، مقالات آموزشی، بازتاب رویدادها و دستاوردهای دانش‌آموزی' },
    ]
  },
  {
    id: 'admissions-student',
    title: 'پذیرش دانش‌آموز',
    englishTitle: 'Student Admissions',
    iconName: 'GraduationCap',
    summary: 'فرایند شفاف و استاندارد ثبت‌نام و ارزیابی جامع استعدادهای فردی دانش‌آموزان در تمام مقاطع تحصیلی.',
    subItems: [
      { id: 'adm-intro', title: 'پذیرش', englishTitle: 'Admissions Overview', description: 'معرفی کلی آیین‌نامه و اصول پذیرش دانش‌آموز در مجتمع' },
      { id: 'adm-age-criteria', title: 'شرایط سنی و پایه تحصیلی', englishTitle: 'Age Criteria & Grade Placement', description: 'جدول انطباق سن تولد با پایه‌های پیش‌دبستانی تا متوسطه دوم' },
      { id: 'adm-tour', title: 'بازدید از مدرسه', englishTitle: 'Campus Visits & Open Days', description: 'ثبت‌نام برای شرکت در تورهای معارفه حضوری و گفتگو با مشاوران' },
      { id: 'adm-guide', title: 'نحوه پیش‌ثبت‌نام', englishTitle: 'Application Guidelines', description: 'راهنمای گام‌به‌گام تکمیل مدارک و پرداخت اینترنتی فرم درخواست' },
      { id: 'adm-apply', title: 'پیش‌ثبت‌نام', englishTitle: 'Online Registration Portal', description: 'ورود به سامانه الکترونیکی پذیرش و پر کردن مشخصات اولیه' },
      { id: 'adm-tracking', title: 'پیگیری پیش‌ثبت‌نام', englishTitle: 'Application Tracking', description: 'استعلام وضعیت پرونده با کد رهگیری و کد ملی' },
      { id: 'adm-faq', title: 'پرسش‌های متداول پذیرش', englishTitle: 'Admissions FAQ', description: 'پاسخ به سوالات پرتکرار اولیا درباره آزمون، مصاحبه و مدارک' },
      { id: 'adm-contact', title: 'تماس با واحد پذیرش', englishTitle: 'Contact Admissions Office', description: 'ارتباط مستقیم تلفنی و ایمیلی با کارشناسان پذیرش خرد' },
    ]
  },
  {
    id: 'admissions-staff',
    title: 'پذیرش همکار',
    englishTitle: 'Staff Recruitment',
    iconName: 'Users',
    summary: 'فرصت‌های همکاری حرفه‌ای برای دبیران، مربیان و کارشناسان نخبه آموزشی با امکان رشد و آموزش مستمر.',
    subItems: [
      { id: 'staff-intro', title: 'پذیرش', englishTitle: 'Careers Overview', description: 'فرهنگ سازمانی، شرایط احراز صلاحیت‌های حرفه‌ای و مربی‌گری' },
      { id: 'staff-guide', title: 'نحوه پیش‌ثبت‌نام', englishTitle: 'How to Apply', description: 'دستورالعمل بارگذاری رزومه، سوابق تحصیلی و مستندات تدریس' },
      { id: 'staff-apply', title: 'پیش‌ثبت‌نام همکار', englishTitle: 'Faculty Application Portal', description: 'تکمیل فرم آنلاین استخدام و اعلام حوزه‌های تخصصی تدریس' },
      { id: 'staff-tracking', title: 'پیگیری پیش‌ثبت‌نام', englishTitle: 'Application Tracking', description: 'بررسی مرحله ارزیابی رزومه و زمان‌بندی جلسات مصاحبه' },
      { id: 'staff-faq', title: 'پرسش‌های متداول پذیرش', englishTitle: 'Recruitment FAQ', description: 'پاسخ به سوالات متقاضیان استخدام درباره بیمه، دوره‌ها و حقوق' },
      { id: 'staff-hr-contact', title: 'تماس با واحد منابع انسانی', englishTitle: 'Contact Human Resources', description: 'راه‌های مکاتبه و هماهنگی با مدیریت سرمایه انسانی خرد' },
    ]
  },
  {
    id: 'preschool',
    title: 'پیش‌دبستانی',
    englishTitle: 'Preschool',
    iconName: 'Smile',
    summary: 'محیطی شاداب، امن و کاوشگرانه برای کودکان ۳ تا ۶ سال با رویکرد یادگیری مبتنی بر بازی و کنجکاوی.',
    subItems: [
      { id: 'pre-main', title: 'پیش‌دبستانی', englishTitle: 'Preschool Overview', category: 'معرفی', description: 'فلسفه یادگیری کودک‌محور و کشف جهان پیرامون' },
      { id: 'pre-edu', title: 'برنامه درسی: آموزش', englishTitle: 'Curriculum & Instruction', category: 'برنامه درسی', description: 'مهارت‌های کلامی، دست‌ورزی، ریاضیات حسی و مفاهیم شناختی' },
      { id: 'pre-eval', title: 'پیشرفت تحصیلی و گزارش‌دهی', englishTitle: 'Progress & Portfolio Reports', category: 'برنامه درسی', description: 'پوشه کار، ارزیابی توصیفی و جلسات مشاوره‌ای رشد فردی' },
      { id: 'pre-lib', title: 'کتابخانه کودک', englishTitle: 'Children’s Library', category: 'برنامه درسی', description: 'فضای اختصاصی قصه‌گویی، نمایش خلاق و آشنایی با کتاب' },
      { id: 'pre-ext-title', title: 'فعالیت‌های فوق برنامه:', englishTitle: 'Extracurricular Activities:', isHeader: true, description: 'فعالیت‌های مهارتی و تکمیلی پیش‌دبستانی' },
      { id: 'pre-sport', title: '- ورزش و فعالیت بدنی', englishTitle: '- Physical Activity & Sports', category: 'فوق‌برنامه', description: 'ژیمناستیک ریتمیک، بازی‌های تعادلی و مهارت‌های حرکتی پایه' },
      { id: 'pre-art', title: '- هنر', englishTitle: '- Creative Arts & Music', category: 'فوق‌برنامه', description: 'کارگاه‌های نقاشی حسی، سفالگری، موسیقی ارف و کاردستی' },
      { id: 'pre-tech', title: '- فناوری', englishTitle: '- Interactive Technology', category: 'فوق‌برنامه', description: 'آشنایی اولیه با مفاهیم منطقی و بازی‌های تعاملی آموزشی' },
    ]
  },
  {
    id: 'primary',
    title: 'دبستان',
    englishTitle: 'Primary School',
    iconName: 'BookOpen',
    summary: 'پرورش تفکر انتقادی، اخلاق‌مداری و یادگیری عمیق در دوره‌های اول و دوم دبستان با رویکرد پژوهش‌محور.',
    subItems: [
      { id: 'pri-main', title: 'دبستان', englishTitle: 'Primary School Overview', category: 'معرفی', description: 'ساختار پایه‌های اول تا ششم دبستان دخترانه خرد' },
      { id: 'pri-edu', title: 'برنامه درسی: آموزش', englishTitle: 'Curriculum & Instruction', category: 'برنامه درسی', description: 'ریاضیات اکتشافی، فارسی خلاق، زبان دوم و مطالعات اجتماعی' },
      { id: 'pri-eval', title: 'پیشرفت تحصیلی و گزارش‌دهی', englishTitle: 'Assessment & Progress Reports', category: 'برنامه درسی', description: 'بازخوردهای عملکردی، سنجش توصیفی و تعامل مستمر با اولیا' },
      { id: 'pri-sci', title: 'برنامه درسی: علوم و فناوری', englishTitle: 'Science & Technology Labs', category: 'برنامه درسی', description: 'آزمایشگاه علوم تجربی، کدنویسی مقدماتی و فناوری اطلاعات' },
      { id: 'pri-lib', title: 'برنامه درسی: کتابخانه', englishTitle: 'Library & Reading Club', category: 'برنامه درسی', description: 'باشگاه کتابخوانی، نقد داستان و ترویج مطالعه عمیق' },
      { id: 'pri-ext-title', title: 'فعالیت‌های فوق برنامه:', englishTitle: 'Extracurricular Activities:', isHeader: true, description: 'فعالیت‌های مهارتی، هنری و ورزشی دبستان' },
      { id: 'pri-sport', title: '- ورزش', englishTitle: '- Athletics & Physical Fitness', category: 'فوق‌برنامه', description: 'شنا، بسکتبال، والیبال، تنیس روی میز و آمادگی جسمانی' },
      { id: 'pri-art', title: '- هنر', englishTitle: '- Visual Arts & Choral Music', category: 'فوق‌برنامه', description: 'طراحی، خوشنویسی، سرود، صنایع دستی و تلفیق هنر با درس' },
      { id: 'pri-sci-club', title: '- انجمن علمی', englishTitle: '- Junior Science Association', category: 'فوق‌برنامه', description: 'پروژه‌های پژوهشی دانش‌آموزی، آزمایش‌های میدانی و اختراعات' },
      { id: 'pri-camp', title: '- اردو', englishTitle: '- Educational Camps & Trips', category: 'فوق‌برنامه', description: 'اردوهای طبیعت‌گردی، بازدید از موزه‌ها و تجارب گروهی مستقل' },
    ]
  },
  {
    id: 'middle-school',
    title: 'متوسطه اول',
    englishTitle: 'Middle School (Grades 7–9)',
    iconName: 'Layers',
    summary: 'پایه‌های هفتم تا نهم، شکل‌گیری شخصیت نوجوان، خودراهبری در یادگیری و آمادگی برای انتخاب رشته.',
    subItems: [
      { id: 'mid-main', title: 'متوسطه اول', englishTitle: 'Middle School Overview', category: 'معرفی', description: 'پایه‌های هفتم، هشتم و نهم در منظومه خرد' },
      { id: 'mid-edu', title: 'برنامه درسی: آموزش', englishTitle: 'Academic Curriculum', category: 'برنامه درسی', description: 'علوم تلفیقی، ریاضیات پیشرفته، ادبیات، زبان انگلیسی و عربی' },
      { id: 'mid-eval', title: 'پیشرفت تحصیلی و گزارش‌دهی', englishTitle: 'Academic Progress & Evaluation', category: 'برنامه درسی', description: 'سنجش مستمر و کارنامه‌های توصیفی-تحلیلی پیشرفت' },
      { id: 'mid-sci', title: 'علوم و فناوری', englishTitle: 'STEM & Robotics Labs', category: 'برنامه درسی', description: 'برنامه‌نویسی پایتون، رباتیک، آزمایشگاه‌های شیمی، فیزیک و زیست' },
      { id: 'mid-lib', title: 'کتابخانه پژوهشی', englishTitle: 'Research Library', category: 'برنامه درسی', description: 'روش تحقیق علمی، مقاله‌نویسی و مرجع‌شناسی' },
      { id: 'mid-sport-honors', title: 'افتخارات ورزشی خرد', englishTitle: 'Athletic Honors & Trophies', category: 'افتخارات', description: 'مقام‌های استانی و کشوری شنا، بسکتبال و دوومیدانی' },
      { id: 'mid-ext-title', title: 'فعالیت‌های فوق برنامه:', englishTitle: 'Extracurricular Activities:', isHeader: true, description: 'فعالیت‌های مهارتی، کارگاهی و اردویی متوسطه اول' },
      { id: 'mid-sport', title: '- ورزش', englishTitle: '- Athletics & Physical Training', category: 'فوق‌برنامه', description: 'رشته‌های قهرمانی تیمی و انفرادی با مربیان برجسته' },
      { id: 'mid-theatre', title: '- نمایش', englishTitle: '- Theatre & Performing Arts', category: 'فوق‌برنامه', description: 'تئاتر صحنه‌ای، نمایشنامه‌خوانی و فن بیان دانش‌آموزی' },
      { id: 'mid-visual-arts', title: '- هنرهای تجسمی', englishTitle: '- Visual Arts & Media', category: 'فوق‌برنامه', description: 'عکاسی دیجیتال، طراحی پوستر، نقاشی و گرافیک' },
      { id: 'mid-sci-assoc', title: '- انجمن علمی', englishTitle: '- Science Societies', category: 'فوق‌برنامه', description: 'حضور در جشنواره خوارزمی و انجمن‌های نجوم، زیست‌محیطی و ریاضی' },
      { id: 'mid-camp', title: '- اردو', englishTitle: '- Field Trips & Expeditions', category: 'فوق‌برنامه', description: 'اردوهای سازنده بوم‌گردی، کوهنوردی و مسئولیت‌پذیری اجتماعی' },
    ]
  },
  {
    id: 'high-school',
    title: 'متوسطه دو',
    englishTitle: 'High School (Grades 10–12)',
    iconName: 'Award',
    summary: 'پایه‌های دهم تا دوازدهم با هدایت تحصیلی تخصصی، تقویت تفکر استدلالی و آمادگی کامل برای دانشگاه‌های برتر.',
    subItems: [
      { id: 'high-main', title: 'متوسطه دو', englishTitle: 'High School Overview', category: 'معرفی', description: 'رشته‌های ریاضی-فیزیک و علوم تجربی با کادر علمی برجسته' },
      { id: 'high-edu', title: 'برنامه درسی: آموزش', englishTitle: 'Academic Program & Advanced Courses', category: 'برنامه درسی', description: 'طرح درس‌های جامع کنکور و امتحانات نهایی، آزمون‌های استاندارد' },
      { id: 'high-eval', title: 'پیشرفت تحصیلی و گزارش‌دهی', englishTitle: 'Academic Advisory & Counseling', category: 'برنامه درسی', description: 'مشاوره اختصاصی کنکور، تحلیل رتبه و هدایت مسیر شغلی' },
      { id: 'high-sci', title: 'علوم و فناوری', englishTitle: 'Advanced Science & Olympiads', category: 'برنامه درسی', description: 'تحقیقات دانشگاهی، سنتز مواد، المپیاد شیمی و آزمایشگاه‌های پیشرفته' },
      { id: 'high-lib', title: 'کتابخانه و سالن مطالعه', englishTitle: 'Senior Library & Study Hall', category: 'برنامه درسی', description: 'سالن مطالعه اختصاصی کنکور و پایگاه مقالات علمی بین‌المللی' },
      { id: 'high-sport-honors', title: 'افتخارات ورزشی خرد', englishTitle: 'Athletic Honors & Cups', category: 'افتخارات', description: 'کسب کاپ‌های اخلاق و قهرمانی در المپیادهای مدارس منطقه ۱' },
      { id: 'high-ext-title', title: 'فعالیت‌های فوق برنامه:', englishTitle: 'Extracurricular Activities:', isHeader: true, description: 'فعالیت‌های فوق‌برنامه مقطع متوسطه دو' },
      { id: 'high-sport', title: '- ورزش', englishTitle: '- Athletics & Wellness', category: 'فوق‌برنامه', description: 'ساعت‌های نشاط، سلامت جسمی و کاهش استرس در مجموعه ورزشی' },
      { id: 'high-theatre', title: '- نمایش', englishTitle: 'Dramatic Arts & Productions', category: 'فوق‌برنامه', description: 'اجراهای تئاتری سالانه به زبان‌های فارسی و انگلیسی' },
      { id: 'high-visual-arts', title: '- هنرهای تجسمی', englishTitle: 'Fine Arts Exhibitions', category: 'فوق‌برنامه', description: 'گالری‌های سالانه نقاشی، خط و عکاسی حرفه‌ای دانش‌آموزان' },
      { id: 'high-sci-assoc', title: '- انجمن علمی', englishTitle: 'Scientific Associations & MUN', category: 'فوق‌برنامه', description: 'تیم‌های المپیاد، مسابقات رباتیک و همایش‌های شبیه‌سازی ملل متحد' },
      { id: 'high-camp', title: '- اردو', englishTitle: 'Senior Expeditions & Visits', category: 'فوق‌برنامه', description: 'اردوهای فارغ‌التحصیلی، بازدیدهای صنعتی و دانشگاهی' },
    ]
  },
  {
    id: 'vocational-school',
    title: 'هنرستان',
    englishTitle: 'Vocational / Art School',
    iconName: 'Palette',
    summary: 'هنرستان تخصصی دخترانه خرد، تربیت طراحان، گرافیست‌ها و هنرمندان خلاق و مستقل با کارگاه‌های پیشرفته.',
    subItems: [
      { id: 'voc-main', title: 'هنرستان', englishTitle: 'Art School Overview', category: 'معرفی', description: 'رشته‌های گرافیک، نقاشی، انیمیشن و سینما با مجوز رسمی' },
      { id: 'voc-support', title: 'پشتیبانی آموزشی', englishTitle: 'Mentorship & Studio Support', category: 'برنامه درسی', description: 'منتورشیپ توسط اساتید بنام هنر و آمادگی کنکور هنر' },
      { id: 'voc-eval', title: 'پیشرفت تحصیلی و گزارش‌دهی', englishTitle: 'Portfolio Review & Jury Assessments', category: 'برنامه درسی', description: 'ارزیابی ژوژمان‌های عملی، پورتفولیو و نمایشگاه‌های فصلی' },
      { id: 'voc-studios', title: 'کارگاه‌های هنری', englishTitle: 'Art Studios & Specialized Ateliers', category: 'امکانات', description: 'آتلیه طراحی، کارگاه چاپ دستی، استودیوی عکاسی و پویانمایی' },
      { id: 'voc-lib', title: 'کتابخانه تخصصی هنر', englishTitle: 'Specialized Art Library', category: 'برنامه درسی', description: 'آرشیو کتاب‌های مرجع هنرهای تجسمی، معماری و طراحی گرافیک' },
      { id: 'voc-honors', title: 'افتخارات ورزشی خرد', englishTitle: 'Athletic Recognition', category: 'افتخارات', description: 'حضور فعال هنرجویان در رقابت‌های ورزشی مدارس تهران' },
      { id: 'voc-ext-title', title: 'فعالیت‌های فوق برنامه:', englishTitle: 'Extracurricular Activities:', isHeader: true, description: 'فعالیت‌های فوق‌برنامه هنرستان خرد' },
      { id: 'voc-sport', title: '- ورزش', englishTitle: '- Wellness & Ergonomics', category: 'فوق‌برنامه', description: 'برنامه‌های حفظ سلامت بدنی، ارگونومی کار هنری و آمادگی جسمانی' },
      { id: 'voc-theatre', title: '- نمایش', englishTitle: '- Set Design & Puppetry', category: 'فوق‌برنامه', description: 'طراحی صحنه و لباس، گریم، ماسک‌سازی و تئاتر عروسکی' },
      { id: 'voc-visual-arts', title: '- هنرهای تجسمی', englishTitle: '- Student Art Exhibitions', category: 'فوق‌برنامه', description: 'نمایشگاه‌های گروهی و انفرادی آثار هنرجویان در گالری خرد' },
      { id: 'voc-sci-assoc', title: '- انجمن علمی هنر', englishTitle: '- Art & Tech Interdisciplinary Lab', category: 'فوق‌برنامه', description: 'پژوهش‌های میان‌رشته‌ای هنر و تکنولوژی و طراحی دیجیتال' },
      { id: 'voc-camp', title: '- اردو', englishTitle: '- Plein Air Trips & Biennales', category: 'فوق‌برنامه', description: 'سفرهای عکاسی، اتود در طبیعت و بازدید از بینال‌های هنری' },
    ]
  },
  {
    id: 'institute-activities',
    title: 'سایر فعالیت‌های مؤسسه',
    englishTitle: 'Other Institute Activities',
    iconName: 'Compass',
    summary: 'معرفی فعالیت‌های مؤسسه منظومه خرد، پیام آقای سلیمانی‌ها و مراکز تخصصی وابسته.',
    subItems: [
      { id: 'inst-culture', title: 'خانه فرهنگ', englishTitle: 'House of Culture', description: 'نشست‌های شاهنامه‌خوانی، تحلیل ادبیات، فلسفه برای کودک و رویدادهای فرهنگی' },
      { id: 'inst-art', title: 'خانه هنر', englishTitle: 'House of Art', description: 'آموزش تخصصی موسیقی، هنرهای تجسمی، نقاشی، خوشنویسی و کارگاه‌های خلاق' },
      { id: 'inst-paydar', title: 'خانه پایدار', englishTitle: 'House of Sustainability', description: 'پژوهش و ترویج توسعه پایدار، بوم‌شناسی، کاهش مصرف منابع و اقتصاد چرخشی' },
      { id: 'inst-sports', title: 'مجموعه ورزشی', englishTitle: 'Athletic Complex', description: 'استخر سرپوشیده استاندارد، سالن توپی چندمنظوره، بدنسازی و ایروبیک' },
      { id: 'inst-pub', title: 'انتشارات', englishTitle: 'Kherad Publishing House', description: 'چاپ و نشر کتاب‌های تخصصی آموزشی، روانشناسی تربیتی و تالیفات اساتید خرد' },
      { id: 'inst-design', title: 'استودیو دیزاین', englishTitle: 'Design Studio', description: 'طراحی هویت بصری، گرافیک محیطی، دیزاین تعاملی و پروژه‌های هنری معاصر' },
    ]
  },
  {
    id: 'school-services',
    title: 'خدمات مدرسه',
    englishTitle: 'School Services',
    iconName: 'HeartHandshake',
    summary: 'امکانات رفاهی استاندارد شامل ناهارخوری سالم، کافه و سرویس‌های منظم رفت و آمد.',
    subItems: [
      { id: 'srv-lunch', title: 'ناهارخوری', englishTitle: 'Dining Hall & Nutrition', description: 'ارائه وعده‌های غذایی گرم و مغذی متناسب با رژیم‌های سلامت زیر نظر متخصص تغذیه' },
      { id: 'srv-cafe', title: 'کافه مدرسه', englishTitle: 'School Café', description: 'فضایی صمیمی برای استراحت، نوشیدنی‌های سالم و گفتگوهای دوستانه دانش‌آموزان و معلمان' },
      { id: 'srv-bus', title: 'سرویس مدرسه', englishTitle: 'Transportation Fleet', description: 'سامانه ایمن و دقیق حمل‌ونقل دانش‌آموزان با پوشش کامل مناطق مختلف تهران' },
    ]
  },
  {
    id: 'news-events',
    title: 'اخبار و رویدادها',
    englishTitle: 'News & Events',
    iconName: 'Calendar',
    summary: 'تازه‌ترین گزارش‌ها از رویدادها، افتخارات دانش‌آموزان و رویدادهای پیش‌روی منظومه خرد.',
    subItems: [
      { id: 'news-academic', title: 'اخبار تحصیلی و موفقیت‌ها', englishTitle: 'Academic Achievements', description: 'کسب افتخارات در المپیادها و قبولی در دانشگاه‌های تراز اول' },
      { id: 'news-cultural', title: 'رویدادهای خانه فرهنگ و هنر', englishTitle: 'Culture & Arts Gatherings', description: 'کنسرت‌های موسیقی، تئاترهای صحنه‌ای و شب‌های شعر و ادب' },
      { id: 'news-calendar', title: 'تقویم رویدادها و جلسات', englishTitle: 'Calendar of Events', description: 'تاریخ‌های امتحانات، همایش‌های اولیا و برنامه‌های اردویی' },
    ]
  },
  {
    id: 'staff-units',
    title: 'واحدهای ستادی',
    englishTitle: 'Headquarters Units',
    iconName: 'Briefcase',
    summary: 'بخش‌های راهبری سازمانی، مالی، فناوری اطلاعات و توسعه زیرساخت‌های منظومه.',
    subItems: [
      { id: 'unit-it', title: 'فناوری اطلاعات و هوشمندسازی', englishTitle: 'IT & Digital Transformation', description: 'توسعه پلتفرم‌های ابری، اینترنت پرسرعت فیبر و کلاس‌های هوشمند' },
      { id: 'unit-finance', title: 'امور مالی و اداری', englishTitle: 'Finance & Administration', description: 'مدیریت شفاف امور اداری، شهریه، قراردادها و رفاه کارکنان' },
      { id: 'unit-rd', title: 'تحقیق و توسعه آموزشی (R&D)', englishTitle: 'Educational Research & Development', description: 'بازنگری سالانه برنامه‌های درسی و روش‌های تدریس نوین' },
      { id: 'unit-pr', title: 'روابط عمومی و امور بین‌الملل', englishTitle: 'Public Relations & Global Affairs', description: 'پل ارتباطی با رسانه‌ها، خانواده‌ها و سازمان‌های علمی جهانی' },
    ]
  },
  {
    id: 'charity',
    title: 'کانون رهپویان دانایی خرد',
    englishTitle: 'Rahpooyan Danaee',
    iconName: 'Heart',
    summary: 'توضیح در مورد رسالت عام‌المنفعه کانون، بورسیه دانش‌آموزان مستعد و راهنمایی به سایت اختصاصی کانون رهپویان دانایی خرد.',
    subItems: [
      { id: 'charity-mission', title: 'رسالت کانون رهپویان دانایی خرد', englishTitle: 'Mission & Vision', description: 'تعهد به عدالت آموزشی و حمایت از کودکان مستعد سراسر کشور' },
      { id: 'charity-scholarships', title: 'طرح بورسیه و توانمندسازی', englishTitle: 'Scholarships & Empowerment', description: 'پوشش هزینه‌های تحصیلی، بسته‌های یادگیری و حمایت‌های روانشناختی' },
      { id: 'charity-schools', title: 'تجهیز مدارس و کتابخانه‌ها', englishTitle: 'School & Library Building', description: 'ساخت و اهدای کتابخانه به روستاهای کمتر برخوردار' },
      { id: 'charity-portal', title: 'ورود به سایت رسمی کانون', englishTitle: 'Official Website', description: 'انتقال مستقیم به پایگاه اطلاع‌رسانی کانون رهپویان دانایی خرد' },
    ]
  }
];

export const kheradStatsData = [
  { number: '۲۵', label: 'سال سابقه تعالی آموزشی (از ۱۳۷۹)', sub: 'پایه‌گذاری بر اصول آموزش نوین' },
  { number: '۵', label: 'مقطع تحصیلی دخترانه', sub: 'پیش‌دبستانی تا هنرستان' },
  { number: '۱۲٬۰۰۰', label: 'متر مربع زیربنا در ولنجک', sub: '۷ طبقه تخصصی با نور طبیعی' },
  { number: '۹۸٪', label: 'قبولی دانشگاه‌های برتر', sub: 'تهران، شریف، امیرکبیر و علوم‌پزشکی' },
  { number: '۳۵+', label: 'آزمایشگاه، کارگاه و استودیو', sub: 'تجهیزات مدرن نانو و رباتیک' },
  { number: '۱۵۰+', label: 'کادر علمی و مربیان متخصص', sub: 'بهره‌گیری از استانداردهای روز تدریس' },
  { number: '۲٬۵۰۰+', label: 'فارغ‌التحصیل موفق و تأثیرگذار', sub: 'حضور در مجامع علمی و کارآفرینی' },
  { number: '۱', label: 'عنوان مدرسه سبز و پایدار', sub: 'پیشرو در مسئولیت زیست‌محیطی' },
];
