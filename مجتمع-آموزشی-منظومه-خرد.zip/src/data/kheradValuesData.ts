export interface ValueAudienceExample {
  audience: 'parents' | 'students' | 'staff';
  labelFa: string;
  labelEn: string;
  exampleFa: string;
  exampleEn: string;
}

export interface KheradValueItem {
  id: string;
  indexNumber: number;
  badgeFa: string;
  badgeEn: string;
  titleFa: string;
  titleEn: string;
  quoteFa: string;
  quoteEn: string;
  expandedConceptFa: string;
  expandedConceptEn: string;
  examples: ValueAudienceExample[];
}

export const kheradValuesData: KheradValueItem[] = [
  {
    id: 'self-awareness-feedback',
    indexNumber: 1,
    badgeFa: 'ارزش ۱',
    badgeEn: 'Value 1',
    titleFa: 'شناخت خود و رشد از دل بازخورد',
    titleEn: 'Self-Awareness & Growth Through Feedback',
    quoteFa: 'در خرد یاد می‌گیریم نقاط قوت و ضعف خودمان را بی‌تعارف بشناسیم و از بازخورد دیگران برای بهتر شدن استفاده کنیم.',
    quoteEn: 'At Kherad, we learn to honestly recognize our strengths and areas for growth, using feedback from others to become better.',
    expandedConceptFa: 'به جای پنهان کردن ضعف یا حالت دفاعی گرفتن، آن را می‌پذیریم و مسیر بهبود را پیدا می‌کنیم.',
    expandedConceptEn: 'Instead of concealing weaknesses or being defensive, we embrace them and chart a constructive path toward improvement.',
    examples: [
      {
        audience: 'parents',
        labelFa: 'والدین',
        labelEn: 'Parents',
        exampleFa: 'استقبال از نظرات اولیا پیرامون وضعیت تحصیلی و عاطفی فرزند و همراهی برای رفع چالش‌ها با نگاهی همدلانه و سازنده.',
        exampleEn: 'Welcoming parental insights on student academic and emotional well-being to collaborate constructively.'
      },
      {
        audience: 'students',
        labelFa: 'دانش‌آموز',
        labelEn: 'Students',
        exampleFa: 'نگاه به کارنامه و ارزیابی‌های توصیفی به عنوان نقشه راه رشد فردی، بدون ترس از قضاوت و با انگیزه یادگیری عمیق‌تر.',
        exampleEn: 'Viewing progress evaluations as personal roadmaps for growth rather than stressful benchmarks.'
      },
      {
        audience: 'staff',
        labelFa: 'مدیریت و همکاران',
        labelEn: 'Management & Staff',
        exampleFa: 'جلسات منظم ارزیابی همتا و بازخورد ۳۶۰ درجه برای توسعه مداوم روش‌های تدریس و تعامل اداری سالم.',
        exampleEn: 'Peer reviews and 360-degree feedback sessions for continuous professional development.'
      }
    ]
  },
  {
    id: 'inquiry-clear-thinking',
    indexNumber: 2,
    badgeFa: 'ارزش ۲',
    badgeEn: 'Value 2',
    titleFa: 'پرسش‌گری و تفکر روشن',
    titleEn: 'Inquiry & Clear Thinking',
    quoteFa: 'در خرد یاد می‌گیریم پیش از هر تصمیم بپرسیم، بررسی کنیم و با فکر باز به پاسخ درست برسیم.',
    quoteEn: 'At Kherad, we learn to question, investigate, and reach sound conclusions with an open mind before making decisions.',
    expandedConceptFa: 'به چالش کشیدن فرضیات اولیه، تحلیل نقادانه شواهد و استقبال از نگاه‌های متفاوت برای رسیدن به داوری درست.',
    expandedConceptEn: 'Challenging initial assumptions, critically analyzing evidence, and welcoming diverse perspectives to reach sound judgment.',
    examples: [
      {
        audience: 'students',
        labelFa: 'دانش‌آموز',
        labelEn: 'Students',
        exampleFa: 'طرح پرسش‌های پژوهش‌محور در کلاس، آزمایش فرضیه‌ها در کارگاه‌ها و تحلیل عمیق پدیده‌ها به جای حفظ کردن طوطی‌وار.',
        exampleEn: 'Asking research questions in class, testing hypotheses in laboratories, and prioritizing conceptual depth over rote memorization.'
      },
      {
        audience: 'parents',
        labelFa: 'والدین',
        labelEn: 'Parents',
        exampleFa: 'گفتگوی استدلالی با مدرسه پیرامون تصمیمات آموزشی با اتکا به شواهد و منطق تربیتی روشن.',
        exampleEn: 'Engaging in constructive dialogue with educators grounded in pedagogical rationale and evidence.'
      },
      {
        audience: 'staff',
        labelFa: 'مدیریت و همکاران',
        labelEn: 'Management & Staff',
        exampleFa: 'طراحی محیط‌های یادگیری مسئله‌محور و تشویق استدلال منطقی و استقلال فکری در تمام مقاطع.',
        exampleEn: 'Designing problem-based inquiry environments and nurturing cognitive independence across all grade levels.'
      }
    ]
  },
  {
    id: 'purposeful-effort-real-result',
    indexNumber: 3,
    badgeFa: 'ارزش ۳',
    badgeEn: 'Value 3',
    titleFa: 'تلاش هدفمند برای نتیجه‌ی واقعی',
    titleEn: 'Purposeful Effort for Genuine Impact',
    quoteFa: 'برایمان کیفیت و اثر واقعی تلاش مهم است، نه فقط حجم کار یا ساعت‌های زیاد.',
    quoteEn: 'For us, the quality and tangible impact of effort matter most, not merely the volume of work or hours spent.',
    expandedConceptFa: 'تمرکز بر یادگیری عمیق، خروجی‌های معنادار و سنجش مهارت‌های ماندگار به جای تکالیف مکانیکی و خسته‌کننده.',
    expandedConceptEn: 'Focusing on deep mastery, authentic outcomes, and enduring skills rather than repetitive drills.',
    examples: [
      {
        audience: 'students',
        labelFa: 'دانش‌آموز',
        labelEn: 'Students',
        exampleFa: 'برنامه‌ریزی هوشمندانه ساعات مطالعه، تمرکز روی درک مفاهیم کلیدی و ارزیابی خود با سنجه‌های عملکرد واقعی.',
        exampleEn: 'Smart study habits focusing on concept comprehension and measuring oneself against tangible progress metrics.'
      },
      {
        audience: 'parents',
        labelFa: 'والدین',
        labelEn: 'Parents',
        exampleFa: 'حمایت از تعادل روحی فرزند و ارزش‌گذاری بر کیفیت آموخته‌ها به جای فشار برای ساعت‌های بی‌پایان تست‌زنی.',
        exampleEn: 'Supporting child well-being and valuing conceptual learning quality over pressure for excessive drills.'
      },
      {
        audience: 'staff',
        labelFa: 'مدیریت و همکاران',
        labelEn: 'Management & Staff',
        exampleFa: 'تدوین برنامه‌های درسی متمرکز بر صلاحیت‌های کلیدی و بازنگری مداوم اثرگذاری آموزشی در نتایج واقعی دانش‌آموزان.',
        exampleEn: 'Designing competency-based curricula and continuously evaluating actual educational impact.'
      }
    ]
  },
  {
    id: 'society-nature-responsibility',
    indexNumber: 4,
    badgeFa: 'ارزش ۴',
    badgeEn: 'Value 4',
    titleFa: 'مسئولیت در قبال جامعه و طبیعت',
    titleEn: 'Responsibility to Society & Nature',
    quoteFa: 'به اموال عمومی احترام می‌گذاریم، از محیط زیست مراقبت می‌کنیم و از فناوری آگاهانه استفاده می‌کنیم.',
    quoteEn: 'We respect public goods, steward the environment, and engage consciously and ethically with technology.',
    expandedConceptFa: 'تعهد به پایداری زیست‌محیطی در مدرسه سبز مجتمع آموزشی خرد، مسئولیت اجتماعی شهروندی و سواد دیجیتال اخلاقی.',
    expandedConceptEn: 'Commitment to environmental sustainability in the Velenjak green campus, civic responsibility, and ethical digital literacy.',
    examples: [
      {
        audience: 'students',
        labelFa: 'دانش‌آموز',
        labelEn: 'Students',
        exampleFa: 'مشارکت فعال در تفکیک پسماند مدرسه، کاشت و نگهداری فضای سبز، و استفاده مسئولانه از ابزارهای هوش مصنوعی و اینترنت.',
        exampleEn: 'Active participation in campus recycling, green projects, and responsible use of AI and online tools.'
      },
      {
        audience: 'parents',
        labelFa: 'والدین',
        labelEn: 'Parents',
        exampleFa: 'همکاری در پویش‌های عام‌المنفعه کانون رهپویان دانایی خرد و کاهش ردپای کربن در رفت‌وآمدهای روزانه.',
        exampleEn: 'Partnering in charitable initiatives and promoting eco-friendly transportation and waste reduction.'
      },
      {
        audience: 'staff',
        labelFa: 'مدیریت و همکاران',
        labelEn: 'Management & Staff',
        exampleFa: 'مدیریت بهینه انرژی در ساختمان ۱۲ هزار متری، حذف کاغذ از فرآیندهای اداری و آموزش توسعه پایدار در برنامه درسی.',
        exampleEn: 'Optimizing resource usage in our 12,000 sqm campus, reducing paper, and integrating sustainability into curricula.'
      }
    ]
  },
  {
    id: 'collaboration-teamwork',
    indexNumber: 5,
    badgeFa: 'ارزش ۵',
    badgeEn: 'Value 5',
    titleFa: 'همکاری و کار تیمی',
    titleEn: 'Collaboration & Teamwork',
    quoteFa: 'باور داریم با هم بودن نتیجه بهتری می‌دهد؛ خانواده، دانش‌آموز و مدرسه دست در دست هم پیش می‌روند.',
    quoteEn: 'We believe togetherness yields the best results; family, student, and school progress hand in hand.',
    expandedConceptFa: 'ترویج هم‌افزایی به جای رقابت ناسالم، تقویت مهارت‌های گوش دادن فعال، حل مسئله جمعی و مشارکت صمیمانه.',
    expandedConceptEn: 'Fostering synergy over unhealthy competition, active listening, collective problem solving, and genuine partnership.',
    examples: [
      {
        audience: 'students',
        labelFa: 'دانش‌آموز',
        labelEn: 'Students',
        exampleFa: 'همکاری در پروژه‌های علمی، کارهای گروهی هنری و المپیادها و آموختن اینکه موفقیت تیم، موفقیت تک‌تک اعضاست.',
        exampleEn: 'Collaborating in group projects, arts, and competitions, realizing collective triumphs elevate everyone.'
      },
      {
        audience: 'parents',
        labelFa: 'والدین',
        labelEn: 'Parents',
        exampleFa: 'همراهی موثر با انجمن اولیا و مربیان و همکاری همسو با معلمان در حمایت از اهداف تربیتی فرزند.',
        exampleEn: 'Constructive partnership with the PTA and aligning home support with pedagogical goals.'
      },
      {
        audience: 'staff',
        labelFa: 'مدیریت و همکاران',
        labelEn: 'Management & Staff',
        exampleFa: 'همکاری بین‌رشته‌ای میان معلمان پایه‌های مختلف برای ایجاد پیوستگی آموزشی از پیش‌دبستان تا هنرستان و متوسطه دوم.',
        exampleEn: 'Cross-disciplinary collaboration ensuring a seamless educational journey from preschool through high school.'
      }
    ]
  },
  {
    id: 'honesty-transparency',
    indexNumber: 6,
    badgeFa: 'ارزش ۶',
    badgeEn: 'Value 6',
    titleFa: 'صداقت و شفافیت در همه‌ی روابط',
    titleEn: 'Honesty & Transparency in All Relationships',
    quoteFa: 'حرف و عملمان یکی است؛ صادقانه گزارش می‌دهیم، به قول‌هایمان پایبندیم و امانت‌دار اطلاعات هستیم.',
    quoteEn: 'Our words match our actions; we report honestly, honor our commitments, and safeguard private trust.',
    expandedConceptFa: 'انعکاس دقیق واقعیت‌ها، پاسداری از حریم خصوصی افراد، شفافیت مالی و اخلاق‌مداری علمی و آموزشی.',
    expandedConceptEn: 'Reflecting realities accurately, protecting privacy, maintaining financial clarity, and upholding academic integrity.',
    examples: [
      {
        audience: 'staff',
        labelFa: 'مدیریت و همکاران',
        labelEn: 'Management & Staff',
        exampleFa: 'گزارش‌دهی دقیق و صادقانه فرآیند پیشرفت دانش‌آموزان به والدین و پایبندی شفاف به تقویم و تعهدات اجرایی.',
        exampleEn: 'Transparent reporting of student progress to parents and strict adherence to calendar and institutional commitments.'
      },
      {
        audience: 'students',
        labelFa: 'دانش‌آموز',
        labelEn: 'Students',
        exampleFa: 'رعایت صداقت تحصیلی در آزمون‌ها، ارجاع دقیق منابع در پژوهش‌ها و شجاعت گفتن حقیقت در مواجهه با چالش‌ها.',
        exampleEn: 'Practicing academic honesty in assessments, citing sources properly, and having the courage to speak truth.'
      },
      {
        audience: 'parents',
        labelFa: 'والدین',
        labelEn: 'Parents',
        exampleFa: 'اشتراک‌گذاری صادقانه ویژگی‌های روحی و رفتاری فرزند با کادر مشاوره برای دریافت بهترین راهنمایی.',
        exampleEn: 'Sharing open and honest observations with counseling staff to receive optimal developmental guidance.'
      }
    ]
  },
  {
    id: 'holistic-growth',
    indexNumber: 7,
    badgeFa: 'ارزش ۷',
    badgeEn: 'Value 7',
    titleFa: 'رشد همه‌جانبه',
    titleEn: 'Holistic Development & Wellbeing',
    quoteFa: 'درس فقط یک بخش از زندگی دانش‌آموز است؛ به سلامت روان، ورزش، هنر و آرامش او هم اهمیت می‌دهیم.',
    quoteEn: 'Academics is only one facet of life; we care deeply about mental health, sports, arts, and inner peace.',
    expandedConceptFa: 'تعادل میان رشد شناختی، عاطفی، جسمانی، اجتماعی و معنوی به عنوان شالوده یک زندگی شاداب و شکوفا.',
    expandedConceptEn: 'Balancing cognitive, emotional, physical, social, and aesthetic development for a joyful, thriving life.',
    examples: [
      {
        audience: 'students',
        labelFa: 'دانش‌آموز',
        labelEn: 'Students',
        exampleFa: 'حضور فعال در استخر و سالن‌های ورزشی، آموختن موسیقی و نقاشی در خانه هنر، و مراقبت از سلامت روحی خود.',
        exampleEn: 'Engaging actively in sports, swimming, artistic disciplines in Khaneh Honar, and tending to personal wellness.'
      },
      {
        audience: 'parents',
        labelFa: 'والدین',
        labelEn: 'Parents',
        exampleFa: 'پرهیز از محدود کردن ارزش فرزند به نمرات صرف و تشویق او به علایق ادبی، هنری، ورزشی و مهارت‌های زندگی.',
        exampleEn: 'Refraining from narrowing success to test scores alone; encouraging arts, sports, and practical life skills.'
      },
      {
        audience: 'staff',
        labelFa: 'مدیریت و همکاران',
        labelEn: 'Management & Staff',
        exampleFa: 'طراحی زنگ‌های شاداب، فعالیت‌های فوق‌برنامه متنوع و نظارت مشاوران بالینی و تربیتی بر توازن برنامه‌ها.',
        exampleEn: 'Integrating wellbeing breaks, diverse extracurriculars, and psychological counseling support across campus.'
      }
    ]
  },
  {
    id: 'kindness-respect',
    indexNumber: 8,
    badgeFa: 'ارزش ۸',
    badgeEn: 'Value 8',
    titleFa: 'مهربانی و احترام',
    titleEn: 'Kindness & Respect for All',
    quoteFa: 'هر نفر در خرد، فارغ از سن و توانایی‌اش، دیده می‌شود، شنیده می‌شود و با احترام با او رفتار می‌شود.',
    quoteEn: 'Every individual at Kherad, regardless of age or ability, is seen, heard, and treated with unconditional dignity.',
    expandedConceptFa: 'پذیرش تفاوت‌های فردی، حفظ کرامت انسانی همه اعضای جامعه خرد و ایجاد فضایی امن و سرشار از مهر و همدلی.',
    expandedConceptEn: 'Embracing neurodiversity and individual differences, preserving human dignity, and nurturing an inclusive environment.',
    examples: [
      {
        audience: 'students',
        labelFa: 'دانش‌آموز',
        labelEn: 'Students',
        exampleFa: 'برخورد گرم و صمیمانه با هم‌کلاسی‌ها، حمایت از دوستان جدیدالورود و ایستادگی در برابر هرگونه رفتار ناخوشایند یا تمسخر.',
        exampleEn: 'Welcoming peers warmly, standing up against teasing or exclusion, and fostering mutual appreciation.'
      },
      {
        audience: 'parents',
        labelFa: 'والدین',
        labelEn: 'Parents',
        exampleFa: 'ارتباط احترام‌آمیز و پرمهر با تمام معلمان، مربیان و پرسنل شریف خدمات و پشتیبانی مدرسه.',
        exampleEn: 'Maintaining respectful and empathetic interactions with teachers, administrators, and support staff alike.'
      },
      {
        audience: 'staff',
        labelFa: 'مدیریت و همکاران',
        labelEn: 'Management & Staff',
        exampleFa: 'شنیدن صدای همه دانش‌آموزان بدون تبعیض، رفتار محترمانه با همه همکاران و ایجاد فرهنگ مهرورزی سازمانی.',
        exampleEn: 'Listening attentively to every child without bias, valuing every staff member, and modeling compassion.'
      }
    ]
  }
];

export const kheradMissionVision = {
  breadcrumbFa: 'ماموریت و چشم‌انداز',
  breadcrumbEn: 'Mission & Vision',
  titleFa: 'ارزش‌های خرد',
  titleEn: 'Kherad Core Values',
  subtitleFa: 'این ارزش‌ها راهنمای رفتار روزانه ما در خرد هستند — در کلاس درس، در تعامل با خانواده‌ها و در تصمیم‌های مدیریتی.',
  subtitleEn: 'These values guide our daily conduct at Kherad — in the classroom, in partnerships with families, and across management decisions.',
  missionFa: 'مأموریت منظومه خرد، ایجاد محیطی یادگیرنده، امن و پژوهش‌محور است تا دختران سرزمینمان با پرورش تفکر نقاد، خودراهبری و آگاهی اجتماعی، به انسان‌هایی اثرگذار، مهربان و توانمند برای جامعه تبدیل شوند.',
  missionEn: 'The mission of Kherad is to foster an inclusive, inquiry-driven learning organization where students cultivate critical inquiry, self-direction, and civic responsibility to become influential, compassionate leaders.',
  visionFa: 'چشم‌انداز خرد، دستیابی به تراز یک الگوی الهام‌بخش آموزش عمومی در خاورمیانه است که تعالی علمی را با مهارت‌های زیستن اخلاقی، تعهد زیست‌محیطی و شکوفایی همه‌جانبه پیوند می‌زند.',
  visionEn: 'Our vision is to be an inspiring model of holistic education in the region, bridging academic excellence with ethical living, environmental stewardship, and lifelong well-being.'
};
