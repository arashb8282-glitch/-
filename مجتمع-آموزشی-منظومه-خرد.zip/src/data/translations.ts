export type SupportedLanguage = 'fa' | 'en';

export interface TranslationDictionary {
  // Navigation & Quick Actions
  nav: {
    about: string;
    campusTour: string;
    admissions: string;
    menu: string;
    closeMenu: string;
    searchPlaceholder: string;
    langSwitch: string;
    sitemap: string;
    allRightsReserved: string;
    lms: string;
    services: string;
  };
  // Hero
  hero: {
    title: string;
    subtitle: string;
    leadBadge: string;
    explore: string;
    established: string;
  };
  // About Panel
  aboutPanel: {
    breadcrumbHome: string;
    breadcrumbAbout: string;
    breadcrumbCurrent: string;
    title: string;
    lead: string;
    bodyPart1: string;
    resultsLink: string;
    bodyPart2: string;
    imgAlt: string;
  };
  // Honor Panel
  honors: {
    badge: string;
    title: string;
    subtitle: string;
    viewAllBtn: string;
    cardBadge1: string;
    cardTitle1: string;
    cardSub1: string;
    cardDesc1: string;
    cardBadge2: string;
    cardTitle2: string;
    cardSub2: string;
    cardDesc2: string;
    cardBadge3: string;
    cardTitle3: string;
    cardSub3: string;
    cardDesc3: string;
    cardCta: string;
  };
  // 6 Pillars Grid
  pillars: {
    badge: string;
    title: string;
    subtitle: string;
    items: Array<{
      id: string;
      title: string;
      subtitle: string;
      desc: string;
      btnText: string;
    }>;
  };
  // 8 Stats
  stats: {
    badge: string;
    title: string;
    subtitle: string;
    footnote: string;
    items: Array<{
      number: string;
      label: string;
      sub: string;
    }>;
  };
  // Schools
  schools: {
    badge: string;
    title: string;
    subtitle: string;
    curriculumTitle: string;
    items: Array<{
      id: string;
      title: string;
      ageBadge: string;
      stageName: string;
      desc: string;
      curriculum: string;
      btnText: string;
    }>;
  };
  // Institutions / Hubs
  hubs: {
    badge: string;
    title: string;
    subtitle: string;
    cta: string;
    items: Array<{
      id: string;
      title: string;
      category: string;
      summary: string;
    }>;
  };
  // Footer
  footer: {
    schoolName: string;
    schoolTagline: string;
    applyBtn: string;
    tourBtn: string;
    colAboutTitle: string;
    colAboutText: string;
    colAboutMissionLabel: string;
    colAboutMissionText: string;
    colContactTitle: string;
    addressLabel: string;
    addressVal: string;
    phoneCentralLabel: string;
    phoneAdmissionsLabel: string;
    postalCode: string;
    smsSystem: string;
    colLinksTitle: string;
    integratedPortals: string;
    copyright: string;
    backToTop: string;
  };
}

export const translations: Record<SupportedLanguage, TranslationDictionary> = {
  fa: {
    nav: {
      about: 'درباره منظومه خرد',
      campusTour: 'گشت مجازی ۳۶۰ درجه مجتمع آموزشی خرد',
      admissions: 'پیش‌ثبت‌نام آنلاین',
      menu: 'منوی ناوبری و نقشه سایت',
      closeMenu: 'بستن منو',
      searchPlaceholder: 'برای پیدا کردن چه چیزی میتونم کمکتون کنم؟',
      langSwitch: 'English',
      sitemap: 'نقشه سایت خرد',
      allRightsReserved: 'تمامی حقوق مادی و معنوی برای مؤسسه‌ی منظومه‌ی خرد محفوظ است — ۱۴۰۶',
      lms: 'سامانه مدیریت یادگیری',
      services: 'سامانه خدمات سازمانی'
    },
    hero: {
      title: 'مجتمع آموزشی و فرهنگی دخترانه خرد',
      subtitle: 'یادگیری عمیق، تفکر نقاد و زیست اخلاقی بر پایه مسئولیت فردی و اجتماعی',
      leadBadge: 'تاسیس ۱۳۷۹ • مجتمع آموزشی خرد ولنجک',
      explore: 'کاوش در منظومه خرد',
      established: '۲۵ سال آموزش پیشرو'
    },
    aboutPanel: {
      breadcrumbHome: 'خانه',
      breadcrumbAbout: 'درباره‌ی مجتمع آموزشی خرد',
      breadcrumbCurrent: 'معرفی مجتمع آموزشی خرد',
      title: 'درباره‌ی مجتمع آموزشی خرد',
      lead: 'مجتمع آموزشی خرد، بنیان‌گذاری‌شده در سال ۱۳۷۹ به همت خیریه بیگم حائری‌زاده، از پیشروترین مجموعه‌های آموزشی دخترانه کشور است که رویکرد آموزش پژوهش‌محور، مهارت‌های زندگی و یادگیری مادام‌العمر را با استانداردهای تراز جهانی برای فرزندان از ۳ تا ۱۸ سال در تهران ارائه می‌دهد.',
      bodyPart1: 'خرد جامعه‌ای پویا و یادگیرنده با بیش از ۲٬۰۰۰ دانش‌آموز در مجتمع آموزشی خرد به وسعت ۱۲٬۰۰۰ متر مربع در ولنجک است و بستری یکپارچه برای رشد همه‌جانبه دختران از پیش‌دبستانی تا پایان دوره دوم متوسطه و هنرستان فراهم می‌آورد. به عنوان یک سازمان آموزشی عام‌المنفعه، تمام شهریه‌ها و ظرفیت‌ها وقف ارائه والاترین کیفیت یادگیری، کشف استعدادها و توانمندسازی اخلاقی و علمی دانش‌آموزان می‌گردد. دانش‌آموختگان خرد همواره در آزمون‌های سراسری، المپیادها و مسابقات به ',
      resultsLink: 'نتایج درخشان آموزشی',
      bodyPart2: ' دست یافته و سالانه بیش از ۹۶٪ فارغ‌التحصیلان آن موفق به کسب قبولی در برترین دانشگاه‌های تراز اول داخلی و معتبر بین‌المللی می‌شوند.',
      imgAlt: 'معلم و دانش‌آموز در محیط یادگیری پویا و پژوهش‌محور در مجتمع آموزشی خرد'
    },
    honors: {
      badge: 'افتخارات و کارنامه تعالی آموزشی منظومه خرد',
      title: 'درخشش مستمر در عرصه‌های علمی، فرهنگی و پژوهشی',
      subtitle: 'نتایج افتخارآفرین خرد حاصل رویکرد پژوهش‌محور، هدایت تحصیلی اختصاصی و همراهی اساتید نخبه کشور است.',
      viewAllBtn: 'مشاهده کارنامه افتخارات تحصیلی، جوایز و المپیادها',
      cardBadge1: 'افتخار علمی',
      cardTitle1: 'رتبه‌های برتر کنکور سراسری و المپیادها',
      cardSub1: 'قبولی ۹۸٪ دانش‌آموزان در رشته‌های مهندسی، پزشکی و هنر دانشگاه‌های تراز اول کشور',
      cardDesc1: 'حضور مستمر در جمع دارندگان مدال‌های طلای المپیادهای ادبیات، زیست‌شناسی، شیمی، کامپیوتر و المپیاد نجوم.',
      cardBadge2: 'پژوهش و فناوری',
      cardTitle2: 'برگزیده جشنواره خوارزمی و روبوکاپ',
      cardSub2: 'کسب رتبه‌های نخست پژوهش‌های دانش‌آموزی و ساخت نمونه‌های صنعتی در آزمایشگاه‌های خرد',
      cardDesc2: 'تلفیق دانش تئوریک با آزمایشگاه‌های سنتز مواد، برنامه‌نویسی پایتون و طراحی مکاترونیک.',
      cardBadge3: 'توسعه پایدار',
      cardTitle3: 'پیشگام ملی آموزش محیط زیست و مدرسه سبز',
      cardSub3: 'دریافت تندیس برتر در مدیریت پسماند، انرژی‌های تجدیدپذیر و بهینه‌سازی منابع زیستی',
      cardDesc3: 'پروژه‌های عملیاتی بازیافت، باغچه ارگانیک دانش‌آموزی و فعالیت‌های بنیاد پایدار خرد.',
      cardCta: 'مشاهده دستاوردهای این حوزه'
    },
    pillars: {
      badge: 'ارکان بنیادین منظومه خرد',
      title: 'کاوش در حوزه‌های اصلی مدرسه و مؤسسه',
      subtitle: 'از اصول آموزشی و فلسفه یادگیری تا امکانات زیرساختی، فعالیت‌های فرهنگی و دستاوردهای ۲۵ ساله دختران خرد.',
      items: [
        {
          id: 'mission-vision',
          title: 'مأموریت، چشم‌انداز و ارزش‌های خرد',
          subtitle: 'ارزش‌های هشت‌گانه و راهنمای رفتار در کلاس، خانواده و مدیریت',
          desc: 'ارزش‌های بنیادین خرد شامل شناخت خود و رشد از بازخورد، تفکر روشن، تلاش هدفمند، مسئولیت در قبال جامعه و طبیعت، کار تیمی، صداقت، رشد همه‌جانبه و مهربانی.',
          btnText: 'مشاهده مأموریت و ۸ ارزش خرد'
        },
        {
          id: 'history',
          title: 'تاریخچه ۲۵ ساله مدرسه',
          subtitle: 'از بنیان‌گذاری ۱۳۷۹ تا مجتمع آموزشی خرد',
          desc: 'روایت ۲۵ سال بالندگی از آغاز به همت خیریه بیگم حائری‌زاده تا احداث مجتمع آموزشی خرد در ولنجک با ۱۲ هزار متر مربع زیربنا.',
          btnText: 'مرور خط زمانی'
        },
        {
          id: 'results',
          title: 'نتایج تحصیلی و المپیادها',
          subtitle: 'موفقیت‌های درخشان کنکور سراسری و رقابت‌های علمی',
          desc: 'کارنامه درخشان قبولی‌های رشته‌های پزشکی، مهندسی و هنر در دانشگاه‌های تراز اول و مدال‌های المپیادهای ملی و جهانی.',
          btnText: 'بررسی نتایج'
        },
        {
          id: 'culture-art',
          title: 'خانه‌ی فرهنگ خرد',
          subtitle: 'کانون غنی ادبیات، تئاتر، موسیقی و هنرهای تجسمی',
          desc: 'برگزاری کارگاه‌های شاهنامه‌خوانی، نقد سینما و ادبیات در خانه فرهنگ؛ و آموزش تخصصی موسیقی، نقاشی و گرافیک در خانه هنر خرد.',
          btnText: 'ورود به خانه هنر و فرهنگ'
        },
        {
          id: 'campus',
          title: 'مجتمع، کارگاه‌ها و آزمایشگاه‌ها',
          subtitle: '۷ طبقه مجهز به پیشرفته‌ترین فناوری‌های روز',
          desc: 'آزمایشگاه‌های سنتز نانو، کارگاه‌های رباتیک و کدنویسی، آتلیه‌های چاپ و هنرستان، کتابخانه‌های غنی و استخر اختصاصی.',
          btnText: 'نقشه و تور مجتمع خرد'
        },
        {
          id: 'management',
          title: 'ساختار مدیریتی و هیئت امنا',
          subtitle: 'شورای راهبری، هیئت مدیره و کمیته‌های علمی',
          desc: 'مدیریت حرفه‌ای مبتنی بر شایسته‌سالاری، شفافیت عملکرد سازمانی، ارزیابی مستمر و مشارکت مستمر اولیا و مربیان.',
          btnText: 'آشنایی با مدیریت'
        }
      ]
    },
    stats: {
      badge: 'منظومه خرد در یک نگاه آماری',
      title: 'شاخص‌های کلیدی و دستاوردهای ۲۵ ساله',
      subtitle: 'شاخص‌های کمّی و کیفی که خرد را به یکی از معتبرترین مجتمع‌های آموزشی دخترانه ایران تبدیل کرده است.',
      footnote: '(اطلاعات و شاخص‌های آماری مستند بر اساس سال تحصیلی ۱۴۰۳-۱۴۰۴)',
      items: [
        { number: '۲۵', label: 'سال سابقه تعالی آموزشی (از ۱۳۷۹)', sub: 'پایه‌گذاری بر اصول آموزش نوین' },
        { number: '۵', label: 'مقطع تحصیلی دخترانه', sub: 'پیش‌دبستانی تا هنرستان' },
        { number: '۱۲٬۰۰۰', label: 'متر مربع زیربنا در ولنجک', sub: '۷ طبقه تخصصی با نور طبیعی' },
        { number: '۹۸٪', label: 'قبولی دانشگاه‌های برتر', sub: 'تهران، شریف، امیرکبیر و علوم‌پزشکی' },
        { number: '۳۵+', label: 'آزمایشگاه، کارگاه و استودیو', sub: 'تجهیزات مدرن نانو و رباتیک' },
        { number: '۱۵۰+', label: 'کادر علمی و مربیان متخصص', sub: 'بهره‌گیری از استانداردهای روز تدریس' },
        { number: '۲٬۵۰۰+', label: 'فارغ‌التحصیل موفق و تأثیرگذار', sub: 'حضور در مجامع علمی و کارآفرینی' },
        { number: '۱', label: 'عنوان مدرسه سبز و پایدار', sub: 'پیشرو در مسئولیت زیست‌محیطی' }
      ]
    },
    schools: {
      badge: 'زنجیره پیوسته آموزشی منظومه خرد',
      title: 'دوره‌های تحصیلی از خردسالی تا دانشگاه',
      subtitle: 'محیط‌های آموزشی متناسب با نیازهای رشدی، شناختی و روانی هر دوره سنی با پیوستگی تربیتی و اخلاقی.',
      curriculumTitle: 'سرفصل‌های آموزشی:',
      items: [
        {
          id: 'preschool',
          title: 'پیش‌دبستانی خرد',
          ageBadge: 'سن ۳ تا ۶ سال',
          stageName: 'دوره آموزش کودک‌محور',
          desc: 'پرورش مهارت‌های کلامی، حرکتی و حسی از طریق بازی، کشف طبیعت، کارگاه‌های قصه و نمایش خلاق و کتابخانه کودک.',
          curriculum: 'آموزش حسی، ریاضیات اکتشافی، زبان دوم، هنر و بازی‌های ریتمیک',
          btnText: 'برنامه درسی پیش‌دبستانی'
        },
        {
          id: 'primary',
          title: 'دبستان خرد (دوره‌های اول و دوم)',
          ageBadge: 'پایه‌های اول تا ششم',
          stageName: 'یادگیری عمیق و تفکر نقاد',
          desc: 'تقویت کنجکاوی و اخلاق‌مداری با رویکرد پژوهش‌محور، آزمایشگاه‌های فعال علوم، کدنویسی مقدماتی، انجمن علمی و اردوهای اکتشافی.',
          curriculum: 'علوم تجربی، ریاضی تعاملی، ادبیات خلاق، هنر، باشگاه کتابخوانی و ورزش',
          btnText: 'برنامه درسی دبستان'
        },
        {
          id: 'middle-school',
          title: 'متوسطه دوره اول خرد',
          ageBadge: 'پایه‌های هفتم تا نهم',
          stageName: 'خودراهبری و هویت‌یابی نوجوان',
          desc: 'دوره تثبیت شخصیت علمی و اخلاقی، آزمایشگاه‌های تخصصی شیمی و فیزیک، برنامه‌نویسی پایتون، رباتیک، هنرهای تجسمی و تئاتر صحنه‌ای.',
          curriculum: 'علوم تلفیقی، ریاضی پیشرفته، زبان‌های خارجی، جشنواره خوارزمی و انجمن‌های علمی',
          btnText: 'برنامه درسی متوسطه اول'
        },
        {
          id: 'high-school',
          title: 'متوسطه دوره دوم خرد',
          ageBadge: 'پایه‌های دهم تا دوازدهم',
          stageName: 'هدایت تخصصی و ورود به دانشگاه',
          desc: 'رشته‌های ریاضی-فیزیک و علوم تجربی با برنامه جامع کنکور و المپیاد، مشاوره فردی، سالن مطالعه اختصاصی و آزمون‌های تحلیلی استاندارد.',
          curriculum: 'دروس تخصصی رشته‌ها، تست‌زنی پیشرفته، مقاله‌نویسی علمی و هدایت مسیر شغلی',
          btnText: 'برنامه درسی متوسطه دوم'
        },
        {
          id: 'vocational-school',
          title: 'هنرستان تخصصی دخترانه خرد',
          ageBadge: 'پایه‌های دهم تا دوازدهم هنر',
          stageName: 'خلاقیت هنری و مهارت‌آموزی حرفه‌ای',
          desc: 'رشته‌های گرافیک، نقاشی، انیمیشن و معماری با آتلیه‌های مجهز، کارگاه‌های چاپ دستی، استودیوی عکاسی و پویانمایی دیجیتال.',
          curriculum: 'طراحی پایه، ژوژمان‌های عملی، فتوشاپ و افترافکت، تاریخ هنر و پورتفولیو',
          btnText: 'برنامه هنرستان دخترانه'
        }
      ]
    },
    hubs: {
      badge: 'مؤسسه و سایر فعالیت‌ها',
      title: 'مراکز فرهنگی، هنری، ورزشی و پایدار خرد',
      subtitle: 'بازوهای تخصصی منظومه خرد که فراتر از برنامه رسمی درسی، زیست فرهنگی و اجتماعی جامعه خرد را شکل می‌دهند.',
      cta: 'اطلاعات بیشتر و برنامه‌ها',
      items: [
        {
          id: 'culture',
          title: 'خانه فرهنگ خرد',
          category: 'فرهنگ و ادب',
          summary: 'کانون تفکر انتقادی، برگزاری نشست‌های تاریخ معاصر، شاهنامه‌خوانی، نقد ادبیات، سینما و اسطوره‌شناسی برای دانش‌آموزان و خانواده‌ها.'
        },
        {
          id: 'art',
          title: 'خانه هنر خرد',
          category: 'موسیقی و تجسمی',
          summary: 'آموزش تخصصی سازهای ایرانی و جهانی، موسیقی ارف کودکان، هنرهای تجسمی، کارگاه‌های عکاسی، تئاتر و برگزاری نمایشگاه‌های فصلی.'
        },
        {
          id: 'paydar',
          title: 'بنیاد پایدار خرد',
          category: 'محیط زیست و پایداری',
          summary: 'ترویج فرهنگ حفاظت از محیط زیست، تفکیک پسماند از مبدأ، پروژه‌های انرژی پاک، صرفه‌جویی در مصرف آب و کاشت گیاهان دارویی.'
        },
        {
          id: 'sports',
          title: 'مجموعه ورزشی خرد',
          category: 'ورزش و سلامت',
          summary: 'استخر سرپوشیده استاندارد، سالن چندمنظوره والیبال و بسکتبال، سالن ژیمناستیک، پیلاتس و آمادگی جسمانی زیر نظر مربیان بین‌المللی.'
        },
        {
          id: 'publish',
          title: 'انتشارات خرد',
          category: 'نشر و پژوهش',
          summary: 'چاپ و نشر کتاب‌های روانشناسی تربیت فرزند، طرح‌درس‌های خلاق معلمان، مجله پژوهشی خردنامه و آثار تألیفی اساتید و دانش‌آموزان.'
        },
        {
          id: 'charity',
          title: 'کانون رهپویان دانایی خرد',
          category: 'مسئولیت اجتماعی',
          summary: 'تعهد به مسئولیت اجتماعی؛ بورسیه تحصیلی دانش‌آموزان مستعد مناطق کم‌برخوردار کشور و تجهیز آزمایشگاه‌ها و کتابخانه‌های مدارس روستایی.'
        }
      ]
    },
    footer: {
      schoolName: 'مجتمع آموزشی و فرهنگی منظومه خرد',
      schoolTagline: 'پیشتاز آموزش پژوهش‌محور، سازمان یادگیرنده و حامی توسعه پایدار',
      applyBtn: 'پیش‌ثبت‌نام سال تحصیلی',
      tourBtn: 'بازدید مجازی مجتمع آموزشی خرد',
      colAboutTitle: 'درباره منظومه خرد',
      colAboutText: 'مجتمع آموزشی دخترانه منظومه خرد در سال ۱۳۷۹ توسط بانو خیریه بیگم حائری‌زاده تاسیس شد. ساختمان مجتمع با زیربنای ۱۲ هزار متر مربع در ۷ طبقه، دربرگیرنده دوره‌های پیش‌دبستانی، دبستان، متوسطه اول، متوسطه دوم، هنرستان خرد، خانه فرهنگ، خانه هنر و بنیاد پایدار است.',
      colAboutMissionLabel: 'مأموریت خرد:',
      colAboutMissionText: 'کمک به افراد جامعه برای توانمندتر شدن در حد بالاترین پتانسیل فردی و یادگیری مادام‌العمر.',
      colContactTitle: 'اطلاعات تماس و موقعیت مجتمع آموزشی خرد',
      addressLabel: 'نشانی مجتمع آموزشی خرد:',
      addressVal: 'تهران، منطقه ۱، ولنجک، بلوار دانشجو، بالاتر از میدان یاسمن',
      phoneCentralLabel: 'تلفن تماس مرکزی: ۰۲۱-۲۲۱۷۰۰۰۰ (۱۰ خط مستقیم)',
      phoneAdmissionsLabel: 'واحد پذیرش دانش‌آموز: ۰۲۱-۲۲۱۷۰۰۰۱',
      postalCode: 'کد پستی: ۱۹۸۴۱-۳۳۴۵۱',
      smsSystem: 'سامانه پیامک: ۳۰۰۰۲۲۱۷',
      colLinksTitle: 'پیوندهای منتخب نقشه سایت',
      integratedPortals: 'سامانه‌های یکپارچه:',
      copyright: '© تمامی حقوق مادی و معنوی این وب‌سایت متعلق به مجتمع آموزشی و فرهنگی منظومه خرد است (۱۳۷۹–۱۴۰۴).',
      backToTop: 'بازگشت به بالای صفحه'
    }
  },
  en: {
    nav: {
      about: 'About Kherad',
      campusTour: '360° Virtual Campus Tour',
      admissions: 'Online Admissions',
      menu: 'Navigation Menu & Sitemap',
      closeMenu: 'Close Menu',
      searchPlaceholder: 'How can we help you explore Kherad?',
      langSwitch: 'فارسی',
      sitemap: 'Kherad Sitemap',
      allRightsReserved: 'All rights reserved for Kherad Educational & Cultural Complex — 2026',
      lms: 'Learning Management System (LMS)',
      services: 'Institutional Services Portal'
    },
    hero: {
      title: 'Kherad Girls’ Educational & Cultural Complex',
      subtitle: 'Inquiry-driven learning, critical thinking, and ethical living grounded in personal and civic responsibility',
      leadBadge: 'Established 2000 • Velenjak Campus',
      explore: 'Explore Kherad Complex',
      established: '25 Years of Educational Excellence'
    },
    aboutPanel: {
      breadcrumbHome: 'HOME',
      breadcrumbAbout: 'ABOUT KHERAD',
      breadcrumbCurrent: 'INTRODUCING KHERAD',
      title: 'About Kherad Educational Complex',
      lead: 'Established in 2000 through the visionary philanthropy of Ms. Kheyrieh Beigom Haerizadeh, Kherad Educational Complex is one of Iran’s foremost schools for girls, delivering world-class inquiry-based learning, character formation, and lifelong skills for learners aged 3 to 18 in Tehran.',
      bodyPart1: 'Kherad is a vibrant, co-educational learning community of over 2,000 students spanning 12,000 square meters across 7 purpose-built floors in Velenjak, providing a seamless educational journey from Preschool through High School and Art Vocational studies. As a non-profit foundation, all institutional resources are reinvested to deliver the highest quality education and unlock every student’s potential. Graduates of Kherad consistently achieve ',
      resultsLink: 'stellar academic outcomes',
      bodyPart2: ', with over 96% securing admission to leading domestic and prestigious international universities each year.',
      imgAlt: 'Educator and student engaged in collaborative, inquiry-based learning at Kherad campus'
    },
    honors: {
      badge: 'Academic Excellence & Recognition Portfolio',
      title: 'Enduring Distinction in Science, Culture & Research',
      subtitle: 'Our remarkable achievements stem from an inquiry-centered pedagogy, dedicated academic mentorship, and partnership with premier educators.',
      viewAllBtn: 'View Academic Honors, Awards & Olympiad Results',
      cardBadge1: 'Academic Honor',
      cardTitle1: 'Top National Entrance Exam & Olympiad Rankings',
      cardSub1: '98% acceptance rate into top engineering, medicine, and arts faculties across tier-one universities',
      cardDesc1: 'Continuous gold, silver, and bronze medals in national and international Olympiads in Literature, Biology, Chemistry, Informatics, and Astronomy.',
      cardBadge2: 'Research & Innovation',
      cardTitle2: 'Khwarizmi Youth Festival & Robocup Champions',
      cardSub2: 'First-place research awards and industrial prototype innovations developed in Kherad state-of-the-art laboratories',
      cardDesc2: 'Integrating rigorous theoretical science with advanced synthesis labs, Python algorithmic thinking, and mechatronic design.',
      cardBadge3: 'Sustainable Development',
      cardTitle3: 'National Eco-School & Green Campus Pioneer',
      cardSub3: 'Highest commendation for waste minimization, renewable energy stewardship, and ecological resource optimization',
      cardDesc3: 'Student-led organic gardens, campus-wide source-separation recycling, and initiatives by Kherad Sustainable Living Foundation.',
      cardCta: 'Explore Achievements in this Field'
    },
    pillars: {
      badge: 'Core Pillars of Kherad',
      title: 'Explore the Foundational Dimensions of Our Institution',
      subtitle: 'From educational philosophy and core values to architectural facilities, cultural initiatives, and 25 years of milestones.',
      items: [
        {
          id: 'mission-vision',
          title: 'Mission, Vision & Core Values',
          subtitle: 'The 8 core ethical tenets guiding classroom, family, and leadership decisions',
          desc: 'Self-awareness through constructive feedback, inquiry and clear thinking, purposeful effort for authentic results, environmental and civic responsibility, teamwork, honesty, holistic growth, and unconditional kindness.',
          btnText: 'View Mission & 8 Values'
        },
        {
          id: 'history',
          title: '25-Year Heritage & Milestone Journey',
          subtitle: 'From foundational inception in 2000 to the Velenjak flagship campus',
          desc: 'Tracing a quarter-century of educational leadership from grassroots philanthropic origins to our landmark 12,000 sqm campus in Tehran.',
          btnText: 'Explore Timeline'
        },
        {
          id: 'results',
          title: 'Academic Results & Olympiad Honors',
          subtitle: 'Exceptional university admissions and national Olympiad medals',
          desc: 'Decades of outstanding results in medicine, engineering, fine arts, and prestigious international academic competitions.',
          btnText: 'Review Results'
        },
        {
          id: 'culture-art',
          title: 'Khaneh Farhang & Khaneh Honar (Culture & Arts)',
          subtitle: 'A vibrant hub for literature, theater, music, and contemporary fine arts',
          desc: 'Hosting classical Persian literary seminars, film analysis, philosophy for youth, and accredited masterclasses in music and visual arts.',
          btnText: 'Enter Culture & Arts Hub'
        },
        {
          id: 'campus',
          title: 'Campus, Laboratories & Specialized Studios',
          subtitle: '7 vertical levels equipped with progressive educational technologies',
          desc: 'Nanotechnology synthesis labs, robotics workshops, printmaking studios, extensive multilingual libraries, and indoor athletic aquatic complex.',
          btnText: 'Campus Map & Virtual Tour'
        },
        {
          id: 'management',
          title: 'Leadership Structure & Board of Trustees',
          subtitle: 'Strategic steering council, academic boards, and executive committees',
          desc: 'Transparent institutional governance grounded in meritocracy, continuous multi-tiered assessment, and active parental collaboration.',
          btnText: 'Meet Leadership'
        }
      ]
    },
    stats: {
      badge: 'Kherad at a Glance: Statistical Highlights',
      title: 'Key Benchmarks & 25 Years of Impact',
      subtitle: 'Quantitative and qualitative metrics establishing Kherad among the most trusted educational institutions in the region.',
      footnote: '(Statistical indicators verified for the 2024–2025 academic calendar)',
      items: [
        { number: '25', label: 'Years of Educational Excellence', sub: 'Founded on modern pedagogy in 2000' },
        { number: '5', label: 'Educational Stages for Girls', sub: 'Preschool through Vocational High School' },
        { number: '12,000', label: 'Sq. Meters Built Campus', sub: '7 floors bathed in natural light' },
        { number: '98%', label: 'Top Tier University Acceptance', sub: 'Tehran, Sharif, Amirkabir & Medical' },
        { number: '35+', label: 'Laboratories, Studios & Workshops', sub: 'State-of-the-art STEM & Art facilities' },
        { number: '150+', label: 'Faculty & Specialized Mentors', sub: 'Dedicated to progressive methodologies' },
        { number: '2,500+', label: 'Distinguished Alumni Leaders', sub: 'Excelling globally in academia & industry' },
        { number: '1', label: 'National Green Flag Eco-School', sub: 'Leader in ecological responsibility' }
      ]
    },
    schools: {
      badge: 'Continuous Educational Continuum',
      title: 'Academic Stages from Early Childhood to University',
      subtitle: 'Tailored learning environments responding to the developmental, cognitive, and emotional milestones of each age cohort.',
      curriculumTitle: 'Curriculum Highlights:',
      items: [
        {
          id: 'preschool',
          title: 'Kherad Preschool',
          ageBadge: 'Ages 3 to 6',
          stageName: 'Child-Centered Exploratory Stage',
          desc: 'Fostering linguistic, motor, and socio-emotional capacities through sensory play, nature discovery, creative drama, and story workshops.',
          curriculum: 'Sensory discovery, early numeracy, second language immersion, arts, and rhythmic gymnastics',
          btnText: 'Preschool Curriculum'
        },
        {
          id: 'primary',
          title: 'Kherad Primary School',
          ageBadge: 'Grades 1 to 6',
          stageName: 'Deep Conceptual Inquiry & Critical Thought',
          desc: 'Nurturing ethical curiosity through inquiry-led science labs, foundational coding, young researchers scientific clubs, and outdoor field trips.',
          curriculum: 'Experimental sciences, interactive mathematics, creative Persian, second languages, book clubs, and athletics',
          btnText: 'Primary Curriculum'
        },
        {
          id: 'middle-school',
          title: 'Kherad Middle School',
          ageBadge: 'Grades 7 to 9',
          stageName: 'Self-Direction & Adolescent Identity',
          desc: 'Solidifying academic discipline and moral grounding through dedicated chemistry/physics labs, Python programming, robotics, theater, and visual arts.',
          curriculum: 'Integrated sciences, advanced mathematics, modern languages, Khwarizmi research, and academic societies',
          btnText: 'Middle School Curriculum'
        },
        {
          id: 'high-school',
          title: 'Kherad High School',
          ageBadge: 'Grades 10 to 12',
          stageName: 'Specialized Pathways & University Readiness',
          desc: 'Mathematics-Physics and Experimental Sciences streams featuring comprehensive university entrance counseling, individual mentorship, and quiet study halls.',
          curriculum: 'Advanced domain coursework, standardized test mastery, academic research papers, and career orientation',
          btnText: 'High School Curriculum'
        },
        {
          id: 'vocational-school',
          title: 'Kherad Vocational & Arts School',
          ageBadge: 'Grades 10 to 12 (Arts)',
          stageName: 'Creative Mastery & Professional Portfolios',
          desc: 'Specialized programs in Graphic Design, Fine Painting, Digital Animation, and Architectural Drafting with modern printmaking studios and darkrooms.',
          curriculum: 'Core draftsmanship, live jury assessments, Adobe creative suite, art history, and portfolio curation',
          btnText: 'Vocational Art Curriculum'
        }
      ]
    },
    hubs: {
      badge: 'Institution & Extended Activities',
      title: 'Cultural, Artistic, Athletic & Sustainability Centers',
      subtitle: 'Specialized arms extending beyond standard curricula to nurture the vibrant civic, intellectual, and aesthetic fabric of our community.',
      cta: 'Explore Programs & Details',
      items: [
        {
          id: 'culture',
          title: 'Khaneh Farhang (Culture House)',
          category: 'Literature & Humanities',
          summary: 'A sanctuary for critical discourse, hosting Shahnameh recitations, contemporary history symposiums, literature circles, and philosophical inquiry for families.'
        },
        {
          id: 'art',
          title: 'Khaneh Honar (Arts Academy)',
          category: 'Music & Visual Arts',
          summary: 'Masterclass instruction in Persian and Western instruments, Orff music for children, fine painting, darkroom photography, theater, and seasonal exhibitions.'
        },
        {
          id: 'paydar',
          title: 'Bonyad Paydar (Sustainability Foundation)',
          category: 'Ecology & Green Campus',
          summary: 'Championing ecological literacy, on-site zero-waste management, renewable energy adoption, water conservation, and botanical stewardship.'
        },
        {
          id: 'sports',
          title: 'Kherad Athletic Complex',
          category: 'Sports & Wellbeing',
          summary: 'Standard semi-Olympic indoor pool, multipurpose arena for volleyball and basketball, gymnastics, pilates, and conditioning led by licensed coaches.'
        },
        {
          id: 'publish',
          title: 'Kherad Publishing House',
          category: 'Academic Publishing',
          summary: 'Publishing pedagogical research, developmental psychology titles for parents, inventive teacher curricula, and the scholarly Kheradnameh journal.'
        },
        {
          id: 'charity',
          title: 'Kherad Philanthropic Foundation',
          category: 'Social Responsibility',
          summary: 'Committed to educational equity: offering scholarships to gifted students in underserved regions and outfitting rural schools with modern libraries and science kits.'
        }
      ]
    },
    footer: {
      schoolName: 'Kherad Educational & Cultural Complex',
      schoolTagline: 'Pioneering inquiry-based learning, a continuous learning organization & sustainability champion',
      applyBtn: 'Admissions for Academic Year',
      tourBtn: '360° Virtual Campus Tour',
      colAboutTitle: 'About Kherad Complex',
      colAboutText: 'Kherad Girls’ Educational Complex was established in 2000 by Ms. Kheyrieh Beigom Haerizadeh. The flagship Velenjak campus encompasses 12,000 m² across 7 floors, hosting Preschool, Primary, Middle School, High School, Vocational Arts School, Khaneh Farhang, Khaneh Honar, and Bonyad Paydar.',
      colAboutMissionLabel: 'Kherad Mission:',
      colAboutMissionText: 'Empowering individuals in society to realize their highest personal potential and nurture lifelong learning.',
      colContactTitle: 'Contact Details & Campus Location',
      addressLabel: 'Velenjak Campus Address:',
      addressVal: 'Tehran, District 1, Velenjak, Daneshjou Blvd, above Yasaman Square',
      phoneCentralLabel: 'Central Switchboard: +98 (21) 2217-0000 (10 direct lines)',
      phoneAdmissionsLabel: 'Admissions Office: +98 (21) 2217-0001',
      postalCode: 'Postal Code: 19841-33451',
      smsSystem: 'SMS Gateway: 30002217',
      colLinksTitle: 'Selected Sitemap Navigation',
      integratedPortals: 'Integrated Portals:',
      copyright: '© All intellectual and material rights belong to Kherad Educational and Cultural Complex (2000–2026).',
      backToTop: 'Back to Top'
    }
  }
};
