export type Language = 'en' | 'fa';

export interface NavItem {
  id: string;
  titleEn: string;
  titleFa: string;
  href: string;
  children?: {
    titleEn: string;
    titleFa: string;
    descriptionEn?: string;
    descriptionFa?: string;
    href: string;
  }[];
}

export interface StatItem {
  value: string;
  labelEn: string;
  labelFa: string;
  detailEn: string;
  detailFa: string;
}

export interface SchoolStage {
  id: string;
  nameEn: string;
  nameFa: string;
  ageRange: string;
  yearGroupsEn: string;
  yearGroupsFa: string;
  headEn: string;
  headFa: string;
  descriptionEn: string;
  descriptionFa: string;
  highlightsEn: string[];
  highlightsFa: string[];
  image: string;
}

export interface TimelineMilestone {
  year: string;
  titleEn: string;
  titleFa: string;
  descriptionEn: string;
  descriptionFa: string;
  category: 'Foundation' | 'Growth' | 'Academic' | 'Centenary';
  image: string;
}

export interface CampusFacility {
  id: string;
  nameEn: string;
  nameFa: string;
  category: 'Sports' | 'Arts' | 'Academic' | 'Community';
  descriptionEn: string;
  descriptionFa: string;
  featuresEn: string[];
  featuresFa: string[];
  image: string;
}

export interface AcademicMetric {
  titleEn: string;
  titleFa: string;
  stat: string;
  benchmarkEn: string;
  benchmarkFa: string;
  detailsEn: string;
  detailsFa: string;
}

export interface NewsItem {
  id: string;
  date: string;
  titleEn: string;
  titleFa: string;
  summaryEn: string;
  summaryFa: string;
  category: string;
  image: string;
  readTime: string;
}
