import React from 'react';
import { MapPin, Phone, Mail, ChevronUp } from 'lucide-react';
import { topSystemLinks, sitemapData } from '../data/kheradSitemap';
import { useLanguage } from '../context/LanguageContext';

interface KheradFooterProps {
  onOpenApply: () => void;
  onOpenTour: () => void;
  onSelectCategory: (catId: string) => void;
}

export const KheradFooter: React.FC<KheradFooterProps> = ({
  onOpenApply,
  onOpenTour,
  onSelectCategory
}) => {
  const { t, isPersian } = useLanguage();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#EDEDF0] text-slate-800 font-persian border-none select-none" dir={isPersian ? 'rtl' : 'ltr'}>
      {/* Main Footer Body - Seamlessly connected to Location section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 lg:py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Col 1: Institutional Intro & Heritage */}
          <div className="lg:col-span-4 space-y-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-black/[0.06] pb-2.5 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-none bg-[#2A6AB2]" />
              <span>{t.footer.colAboutTitle}</span>
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed font-light">
              {t.footer.colAboutText}
            </p>
            <div className="p-4 bg-white/90 rounded-none border border-black/[0.06] text-xs text-slate-600 space-y-1 shadow-none">
              <span className="font-semibold text-[#2A6AB2] block">{t.footer.colAboutMissionLabel}</span>
              <p className="font-light">{t.footer.colAboutMissionText}</p>
            </div>
          </div>

          {/* Col 2: Contact Details */}
          <div className="lg:col-span-4 space-y-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-black/[0.06] pb-2.5 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-none bg-[#2A6AB2]" />
              <span>{t.footer.colContactTitle}</span>
            </h3>

            <div className="space-y-3 text-xs text-slate-600 font-light">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 stroke-[1.4] text-[#2A6AB2] shrink-0 mt-0.5" />
                <span>
                  <strong className="text-slate-800 font-medium">{t.footer.addressLabel}</strong><br />
                  {t.footer.addressVal}
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 stroke-[1.4] text-[#2A6AB2] shrink-0" />
                <span>{t.footer.phoneCentralLabel}</span>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 stroke-[1.4] text-[#2A6AB2] shrink-0" />
                <span>{t.footer.phoneAdmissionsLabel}</span>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 stroke-[1.4] text-[#2A6AB2] shrink-0" />
                <span className="font-mono text-[11px]">info@kheradedu.ir | admissions@kheradedu.ir</span>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
              <span className="bg-white/90 border border-black/[0.06] px-3 py-1 rounded-none">{t.footer.postalCode}</span>
              <span className="bg-white/90 border border-black/[0.06] px-3 py-1 rounded-none">{t.footer.smsSystem}</span>
            </div>
          </div>

          {/* Col 3: Quick Sitemap Portal Links */}
          <div className="lg:col-span-4 space-y-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-black/[0.06] pb-2.5 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-none bg-[#2A6AB2]" />
              <span>{t.footer.colLinksTitle}</span>
            </h3>

            <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 font-light">
              {sitemapData.slice(0, 10).map((cat) => (
                <button 
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)} 
                  className={`${isPersian ? 'text-right' : 'text-left'} hover:text-[#2A6AB2] transition-colors cursor-pointer truncate`}
                >
                  {isPersian ? cat.title : (cat.englishTitle || cat.title)}
                </button>
              ))}
            </div>

            <div className="pt-3 border-t border-black/[0.06]">
              <span className="text-[11px] text-slate-500 block mb-2 font-medium">{t.footer.integratedPortals}</span>
              <div className="flex flex-wrap gap-2 text-xs">
                {topSystemLinks.map((link) => (
                  <button
                    key={link.id}
                    onClick={() => onSelectCategory(link.id)}
                    className="bg-white/90 hover:bg-white hover:text-[#2A6AB2] text-slate-700 border border-black/[0.06] px-3 py-1 rounded-none transition-colors text-[11px] cursor-pointer shadow-none"
                  >
                    {isPersian ? link.title : link.en}
                  </button>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Legal & Bottom Bar */}
      <div className="bg-[#E4E5E9] py-4 px-4 sm:px-8 border-t border-black/[0.05] text-[11px] text-slate-500 font-light">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <span>{t.footer.copyright}</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1 text-slate-600 hover:text-[#2A6AB2] transition-colors p-1 cursor-pointer"
              title={t.footer.backToTop}
            >
              <span>{t.footer.backToTop}</span>
              <ChevronUp className="w-4 h-4 stroke-[1.5]" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
