import React, { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';

interface KheradHonorPanelProps {
  onOpenHonors: () => void;
}

export const KheradHonorPanel: React.FC<KheradHonorPanelProps> = ({ onOpenHonors }) => {
  const { isPersian } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const baseShowcaseItems = [
    {
      id: 'entrance-exam',
      title: isPersian ? 'رتبه‌های برتر کنکور ۱۴۰۳' : 'Top Entrance Exam Ranks',
      subtitle: isPersian ? 'کسب رتبه‌های تک‌رقمی و دورقمی ریاضی و تجربی' : 'Single & double-digit national ranks',
      ctaText: isPersian ? 'مشاهده رتبه‌ها' : 'View ranks',
      photo: '/assets/kherad-brand/photos/29.webp',
    },
    {
      id: 'khwarizmi',
      title: isPersian ? 'مدال‌آوران المپیادهای ملی' : 'Olympiad Gold Medallists',
      subtitle: isPersian ? 'مدال‌های طلای المپیاد زیست، شیمی و نجوم' : 'National Biology, Chemistry & Astronomy medals',
      ctaText: isPersian ? 'افتخارآفرینان' : 'Medallists',
      photo: '/assets/kherad-brand/photos/30.webp',
    },
    {
      id: 'green-school',
      title: isPersian ? 'نخستین مدرسه سبز ایران' : 'Pioneering Green School',
      subtitle: isPersian ? 'مدیریت مصرف انرژی، تفکیک پسماند و پنل‌های خورشیدی' : 'Zero-waste campus & solar energy',
      ctaText: isPersian ? 'طرح مدرسه سبز' : 'Explore Eco',
      photo: '/assets/kherad-brand/photos/31.webp',
    },
    {
      id: 'culture-art',
      title: isPersian ? 'جشنواره‌های بین‌المللی تئاتر' : 'Global Theater & Arts',
      subtitle: isPersian ? 'اجراهای برگزیده در فستیوال‌های بین‌المللی و گروه کر' : 'Acclaimed international stage & choir awards',
      ctaText: isPersian ? 'مشاهده رویدادها' : 'Explore Arts',
      photo: '/assets/kherad-brand/photos/32.webp',
    },
    {
      id: 'sports',
      title: isPersian ? 'قهرمانی مدارس تهران' : 'Tehran Championships',
      subtitle: isPersian ? 'جام‌های قهرمانی پیاپی والیبال، شنا و بسکتبال' : 'Consecutive volleyball, swimming & track cups',
      ctaText: isPersian ? 'کارنامه ورزشی' : 'Sports report',
      photo: '/assets/kherad-brand/photos/34.webp',
    },
    {
      id: 'stem',
      title: isPersian ? 'آزمایشگاه‌های پژوهشی نوین' : 'Advanced Robotics Labs',
      subtitle: isPersian ? 'ربات‌های امدادگر، برنامه‌نویسی و ساخت هوشمند' : 'Autonomous robotics & coding competitions',
      ctaText: isPersian ? 'دستاوردهای علمی' : 'Discover Tech',
      photo: '/assets/kherad-brand/photos/28.webp',
    }
  ];

  // Tripled items array to enable truly infinite, uninterrupted horizontal looping
  const loopedItems = [
    ...baseShowcaseItems.map((item, i) => ({ ...item, uniqueKey: `set1-${item.id}-${i}` })),
    ...baseShowcaseItems.map((item, i) => ({ ...item, uniqueKey: `set2-${item.id}-${i}` })),
    ...baseShowcaseItems.map((item, i) => ({ ...item, uniqueKey: `set3-${item.id}-${i}` })),
  ];

  // Setup initial scroll position to middle set and attach listeners
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    // Start in the middle set once layout is ready
    const initTimer = setTimeout(() => {
      if (container) {
        const singleSetWidth = container.scrollWidth / 3;
        container.scrollLeft = singleSetWidth;
      }
    }, 50);

    // Handle horizontal mouse wheel scroll without hitting any limits
    const handleWheel = (e: WheelEvent) => {
      if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
        e.preventDefault();
        container.scrollLeft += e.deltaY;
      }
    };

    // Seamless loop wrap-around logic
    const handleScroll = () => {
      const singleSetWidth = container.scrollWidth / 3;
      if (singleSetWidth <= 0) return;

      // Wrap-around seamlessly when reaching either end
      if (container.scrollLeft >= singleSetWidth * 2) {
        container.scrollLeft -= singleSetWidth;
      } else if (container.scrollLeft <= 5) {
        container.scrollLeft += singleSetWidth;
      }

      // Calculate active card index (0 to baseShowcaseItems.length - 1)
      const center = container.scrollLeft + container.clientWidth / 2;
      const cards = container.querySelectorAll<HTMLElement>('.apple-card');
      let closestIdx = 0;
      let minDiff = Infinity;
      cards.forEach((card, idx) => {
        const cardCenter = card.offsetLeft + card.clientWidth / 2;
        const diff = Math.abs(cardCenter - center);
        if (diff < minDiff) {
          minDiff = diff;
          closestIdx = idx;
        }
      });
      setCurrentIndex(closestIdx % baseShowcaseItems.length);
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    container.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      clearTimeout(initTimer);
      container.removeEventListener('wheel', handleWheel);
      container.removeEventListener('scroll', handleScroll);
    };
  }, [baseShowcaseItems.length]);

  // Jump to specific item in the middle set
  const scrollToCard = (index: number) => {
    const container = scrollContainerRef.current;
    if (!container) return;
    const cards = container.querySelectorAll<HTMLElement>('.apple-card');
    // Pick corresponding card in middle set
    const targetIdx = baseShowcaseItems.length + index;
    if (cards[targetIdx]) {
      const card = cards[targetIdx];
      const targetScroll = card.offsetLeft - (container.clientWidth / 2) + (card.clientWidth / 2);
      container.scrollTo({
        left: targetScroll,
        behavior: 'smooth'
      });
      setCurrentIndex(index);
    }
  };

  return (
    <section 
      id="apple-style-showcase"
      style={{ backgroundColor: '#ffffff' }}
      className="w-full bg-white pt-5 pb-6 sm:pt-6 sm:pb-7 overflow-hidden select-none border-none transition-colors"
      dir="ltr"
    >
      {/* Infinite Horizontal Carousel Track - Seamless Repeating Loop */}
      <div className="w-full relative overflow-hidden">
        <div
          ref={scrollContainerRef}
          className="flex items-center gap-3.5 sm:gap-4 md:gap-5 overflow-x-auto no-scrollbar py-2 px-4 sm:px-8 md:px-12 scroll-smooth [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
          style={{ 
            scrollbarWidth: 'none',
            msOverflowStyle: 'none'
          }}
        >
          {loopedItems.map((item, idx) => {
            const isActive = (idx % baseShowcaseItems.length) === currentIndex;
            return (
              <div
                key={item.uniqueKey}
                onClick={() => scrollToCard(idx % baseShowcaseItems.length)}
                className={`apple-card relative shrink-0 w-[74vw] sm:w-[350px] md:w-[390px] lg:w-[420px] h-[205px] sm:h-[225px] md:h-[240px] rounded-none overflow-hidden cursor-pointer transition-all duration-300 shadow-none border border-black/[0.06] ${
                  isActive ? 'opacity-100' : 'opacity-85 hover:opacity-100'
                }`}
              >
                {/* Full-bleed Photo Background - Natural, Clear, Vibrant without gray tint */}
                <img
                  src={item.photo}
                  alt={item.title}
                  className="w-full h-full object-cover object-center rounded-none transition-transform duration-700 hover:scale-105"
                  loading="lazy"
                />

                {/* Blue pulse scan motion wave over photo */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden">
                  <div className="absolute inset-x-0 h-24 bg-gradient-to-b from-transparent via-[#0b82c6]/20 to-transparent animate-blue-pulse-wave" />
                </div>

                {/* Subtle bottom text scrim only (rest of photo has zero gray tint) */}
                <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-black/85 via-black/40 to-transparent pointer-events-none rounded-none" />

                {/* Card Content Overlay - Positioned cleanly at the bottom */}
                <div className="absolute inset-0 flex flex-col justify-end p-4 sm:p-5 z-10 text-white" dir={isPersian ? 'rtl' : 'ltr'}>
                  <div className="flex items-end justify-between gap-3">
                    <div className="max-w-[240px] sm:max-w-[270px] space-y-1 text-right">
                      <h3 className="text-sm sm:text-base md:text-lg font-bold text-white leading-snug drop-shadow-sm truncate">
                        {item.title}
                      </h3>
                      <p className="text-[11px] sm:text-xs text-slate-200 font-light leading-tight line-clamp-1">
                        {item.subtitle}
                      </p>
                    </div>

                    {/* Action Button - Fully Rounded Pill Box (دور گرد کامل) */}
                    <div className="shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenHonors();
                        }}
                        className="bg-white hover:bg-white/95 text-black font-bold text-[11px] sm:text-xs px-4 py-1.5 sm:py-2 rounded-full shadow-xs hover:shadow-sm transition-all cursor-pointer whitespace-nowrap active:scale-95"
                        title={item.ctaText}
                      >
                        {item.ctaText}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Slide Indicators - Exact Replica of Uploaded Apple Design (Screenshot 1405-07-13 at 22.46.24.png) */}
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 mt-4 sm:mt-5 flex items-center justify-center select-none">
        <div className="flex items-center gap-2.5 sm:gap-3">
          {baseShowcaseItems.map((item, idx) => {
            const isActive = idx === currentIndex;
            if (isActive) {
              return (
                /* Active: Capsule with solid black circular dot inside */
                <button
                  key={item.id}
                  onClick={() => scrollToCard(idx)}
                  className="w-10 sm:w-11 h-2.5 sm:h-3 rounded-full bg-[#86868b]/40 relative cursor-pointer focus:outline-none flex items-center px-0.5 transition-all duration-300 shrink-0"
                  title={item.title}
                  aria-label={`اسلاید ${idx + 1}`}
                >
                  <span className="w-2 sm:w-2.5 h-2 sm:h-2.5 rounded-full bg-black shadow-xs block" />
                </button>
              );
            }

            return (
              /* Inactive: Solid gray circular dot */
              <button
                key={item.id}
                onClick={() => scrollToCard(idx)}
                className="w-2.5 h-2.5 rounded-full bg-[#86868b] hover:bg-[#6e6e73] transition-colors cursor-pointer focus:outline-none shrink-0"
                title={item.title}
                aria-label={`اسلاید ${idx + 1}`}
              />
            );
          })}

          {/* 7th Fading Tail Dot from the sample image */}
          <span className="w-1.5 h-1.5 rounded-full bg-[#86868b]/60 inline-block pointer-events-none shrink-0" />
        </div>
      </div>
    </section>
  );
};
