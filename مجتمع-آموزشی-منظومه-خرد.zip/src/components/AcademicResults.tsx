import React from 'react';
import { academicMetrics } from '../data/tanglinData';
import { Language } from '../types';
import { Award, CheckCircle2, ShieldCheck, Star, FileText, ChevronRight } from 'lucide-react';

interface AcademicResultsProps {
  lang: Language;
}

export const AcademicResults: React.FC<AcademicResultsProps> = ({ lang }) => {
  const isPersian = lang === 'fa';

  const bsoAreas = [
    { titleEn: 'Quality of Education Provided', titleFa: 'کیفیت آموزش و یادگیری' },
    { titleEn: 'Spiritual, Moral, Social and Cultural Development', titleFa: 'رشد معنوی، اخلاقی، اجتماعی و فرهنگی دانش‌آموزان' },
    { titleEn: 'Welfare, Health and Safety of Pupils', titleFa: 'رفاه، سلامت روانی و ایمنی دانش‌آموزان' },
    { titleEn: 'Suitability of Staff, Supply Staff and Proprietors', titleFa: 'شایستگی و صلاحیت بالای کادر علمی و مدیریتی' },
    { titleEn: 'Premises and Accommodation', titleFa: 'استاندارد عالی فضاها و امکانات پردیس' },
    { titleEn: 'Provision of Information to Parents', titleFa: 'شفافیت و ارتباط مستمر با اولیا' },
    { titleEn: 'Manner in which Complaints are Handled', titleFa: 'رسیدگی دقیق به بازخوردها و پیشنهادات' },
    { titleEn: 'Quality of Leadership and Management', titleFa: 'کیفیت رهبری، هدایت و مدیریت کلان مدرسه' },
  ];

  return (
    <section id="academics" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0F2537]/5 text-[#0F2537] text-xs font-bold uppercase tracking-widest mb-3">
            <Award className="w-3.5 h-3.5 text-[#C5A85C]" />
            {isPersian ? 'افتخارات و کیفیت استاندارد' : 'Academic Excellence & Inspection'}
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-serif-heading text-[#0F2537]">
            {isPersian ? 'نتایج درخشان تحصیلی و رتبه ممتاز بین‌المللی' : 'Academic Results & Inspections'}
          </h2>
          <div className="w-16 h-1 bg-[#C5A85C] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            {isPersian
              ? 'مدرسه تانگلین به طور مستمر در زمره برترین مدارس بین‌المللی جهان از حیث نتایج امتحانات نهایی و نظارت کیفی قرار دارد.'
              : 'Our examination results consistently place Tanglin in the top tier of British international schools globally.'}
          </p>
        </div>

        {/* Academic Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {academicMetrics.map((item, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-slate-50 hover:bg-white border border-slate-200 hover:border-[#C5A85C] shadow-sm hover:shadow-xl transition-all flex flex-col justify-between"
            >
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#C5A85C]">
                  {isPersian ? 'شاخص موفقیت' : 'Benchmark'}
                </span>
                <h3 className="text-lg font-bold font-serif-heading text-[#0F2537] mt-1">
                  {isPersian ? item.titleFa : item.titleEn}
                </h3>
                <div className="my-4">
                  <div className="text-3xl sm:text-4xl font-extrabold text-[#0F2537] font-serif-heading">
                    {item.stat}
                  </div>
                  <div className="text-xs font-semibold text-[#C5A85C] mt-1">
                    {isPersian ? item.benchmarkFa : item.benchmarkEn}
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-600 border-t border-slate-200 pt-3 leading-relaxed">
                {isPersian ? item.detailsFa : item.detailsEn}
              </p>
            </div>
          ))}
        </div>

        {/* British Schools Overseas (BSO) Inspection Spotlight */}
        <div id="inspections" className="rounded-2xl bg-gradient-to-r from-[#0F2537] via-[#162E4A] to-[#0B1B2B] text-white p-6 sm:p-10 border border-[#C5A85C]/30 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-5 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A85C]/20 text-[#E5C97A] text-xs font-bold uppercase tracking-wider border border-[#C5A85C]/40">
                <ShieldCheck className="w-4 h-4 text-[#C5A85C]" />
                <span>British Schools Overseas (BSO)</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-bold font-serif-heading text-white">
                {isPersian ? 'رتبه ممتاز (Outstanding) در تمام ۸ بخش بازرسی' : 'Rated Outstanding in Every Inspection Standard'}
              </h3>

              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                {isPersian
                  ? 'بر اساس گزارش رسمی بازرسی مدارس بریتانیایی خارج از کشور (تحت نظارت مستقیم وزارت آموزش و پرورش انگلستان)، مدرسه تانگلین بالاترین درجه کیفی ممکن را در تمامی شاخص‌ها دریافت نموده است.'
                  : 'Following rigorous evaluation by independent inspectors against UK Department for Education standards, Tanglin achieved the highest possible grading of "Outstanding" in all eight inspected categories.'}
              </p>

              <div className="pt-2 flex items-center gap-3">
                <div className="flex items-center gap-1 text-[#C5A85C]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <span className="text-xs text-slate-300 font-semibold">
                  PENTA International Accredited
                </span>
              </div>
            </div>

            {/* Right: The 8 Inspected Areas */}
            <div className="lg:col-span-7">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {bsoAreas.map((area, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-white/5 border border-white/10 flex items-start gap-2.5 text-xs hover:bg-white/10 transition-colors"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#C5A85C] shrink-0 mt-0.5" />
                    <span className="text-slate-200">
                      {isPersian ? area.titleFa : area.titleEn}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex items-center justify-between pt-4 border-t border-white/10 text-xs text-slate-400">
                <span>{isPersian ? 'آخرین گزارش رسمی بازرسی کامل BSO' : 'Full BSO & Ofsted Alignment Report'}</span>
                <a
                  href="#download-report"
                  className="inline-flex items-center gap-1 text-[#C5A85C] hover:text-white font-bold transition-colors"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>{isPersian ? 'مشاهده فایل PDF گزارش' : 'Read Inspection Report (PDF)'}</span>
                </a>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
