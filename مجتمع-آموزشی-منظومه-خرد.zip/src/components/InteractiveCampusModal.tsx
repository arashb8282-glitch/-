import React, { useState } from 'react';
import { X, MapPin, Compass, Eye, Waves, Trophy, Theater, BookOpen, Cpu, School } from 'lucide-react';
import { Language } from '../types';

interface InteractiveCampusModalProps {
  isOpen: boolean;
  lang: Language;
  onClose: () => void;
  onOpenBookVisit: () => void;
}

interface FacilityHotspot {
  id: string;
  nameEn: string;
  nameFa: string;
  category: 'Sports' | 'Arts' | 'Academic' | 'Building';
  image: string;
  descEn: string;
  descFa: string;
  featuresEn: string[];
  featuresFa: string[];
  x: number; // percentage
  y: number; // percentage
}

const campusHotspots: FacilityHotspot[] = [
  {
    id: 'centenary',
    nameEn: 'The Centenary Building (11-Storey Landmark)',
    nameFa: 'ساختمان صدمین سالگرد (سازه‌ای ۱۱ طبقه)',
    category: 'Building',
    image: '/assets/photos/hero-centenary.jpg',
    descEn: 'Opened in 2023, the 11-storey Centenary Building houses world-class sports facilities, music technology suites, and the Institute@Tanglin.',
    descFa: 'این ساختمان مدرن ۱۱ طبقه در سال ۲۰۲۳ افتتاح شد و مجهز به مجتمع ورزش‌های آبی، استودیوهای فناوری موسیقی و موسسه پژوهشی تانگلین است.',
    featuresEn: ['50m Olympic swimming pool', '15m IFSC climbing wall', 'Gymnastics training arena', 'Institute@Tanglin research hub'],
    featuresFa: ['استخر سرپوشیده ۵۰ متری المپیک', 'دیواره صخره‌نوردی ۱۵ متری بین‌المللی', 'سالن ژیمناستیک حرفه‌ای', 'مرکز پژوهشی و اندیشکده تانگلین'],
    x: 48,
    y: 32
  },
  {
    id: 'infant-lib',
    nameEn: 'Infant School & Storybook Library',
    nameFa: 'مدرسه خردسال و کتابخانه کودک',
    category: 'Academic',
    image: '/assets/photos/campus-map.jpg',
    descEn: 'Purpose-built for children aged 3 to 7 with vibrant early literacy hubs, outdoor sensory playgrounds, and specialist art rooms.',
    descFa: 'محیطی اختصاصی برای کودکان ۳ تا ۷ سال با فضاهای قصه‌خوانی و کتابخانه کودک، زمین‌های بازی حسی روباز و کارگاه‌های نقاشی.',
    featuresEn: ['Early years reading amphitheatre', 'Sensory splash zone', 'Specialist music & movement studio'],
    featuresFa: ['آمفی‌تئاتر قصه‌خوانی کودک', 'محوطه بازی‌های حسی و آبی', 'استودیوی موسیقی و تحرک کودکان'],
    x: 25,
    y: 65
  },
  {
    id: 'nixon-theatre',
    nameEn: 'Nixon Building & 400-Seat Theatre',
    nameFa: 'ساختمان نیکسون و تالار تئاتر ۴۰۰ نفره',
    category: 'Arts',
    image: '/assets/photos/governance.jpg',
    descEn: 'Our premier performing arts venue featuring professional acoustic isolation, fly tower, orchestra pit, and technical control suite.',
    descFa: 'مرکز اصلی هنرهای نمایشی با عایق‌بندی صوتی پیشرفته، برج تجهیزات نور، جایگاه ارکستر زنده و اتاق فرمان فنی دیجیتال.',
    featuresEn: ['400-seat auditorium', 'Black box drama studio', 'Professional recording suite'],
    featuresFa: ['تالار اصلی با ظرفیت ۴۰۰ تماشاگر', 'استودیوی بلک‌باکس نمایش تجربی', 'استودیوی حرفه‌ای صدابرداری'],
    x: 72,
    y: 55
  },
  {
    id: 'junior-school',
    nameEn: 'Junior School & Arts Centre',
    nameFa: 'مدرسه دبستان و مرکز هنر کودک',
    category: 'Academic',
    image: '/assets/photos/junior-school.jpg',
    descEn: 'Dedicated Key Stage 2 classrooms equipped with interactive displays, maker spaces, and a bespoke Junior Arts Centre.',
    descFa: 'کلاس‌های هوشمند دوره دبستان با نمایشگرهای تعاملی، آزمایشگاه‌های ساخت و فناوری و مرکز هنرهای تجسمی کودکان.',
    featuresEn: ['Design & Technology lab', 'Junior science labs', 'Collaborative learning commons'],
    featuresFa: ['کارگاه طراحی و تکنولوژی', 'آزمایشگاه‌های علوم تجربی دبستان', 'فضاهای کار گروهی دانش‌آموزی'],
    x: 38,
    y: 45
  },
  {
    id: 'sixth-form-centre',
    nameEn: 'Sixth Form Centre & University Hub',
    nameFa: 'مرکز سال ششم و مشاوره پذیرش دانشگاهی',
    category: 'Academic',
    image: '/assets/photos/sixth-form.jpg',
    descEn: 'Collegiate study suites, silent research zones, and university counselling offices for Year 12 and 13 students.',
    descFa: 'فضاهای مطالعه دانشگاهی، سالن‌های پژوهش مستقل و دفاتر مشاوره تحصیلی ارشد برای دانش‌آموزان سال‌های ۱۲ و ۱۳.',
    featuresEn: ['Higher education guidance suites', 'Collaborative seminar rooms', 'Independent study carrels'],
    featuresFa: ['دفاتر راهنمای پذیرش دانشگاه‌های ممتاز', 'اتاق‌های سمینار گروهی', 'جایگاه‌های مطالعه انفرادی'],
    x: 62,
    y: 75
  }
];

export const InteractiveCampusModal: React.FC<InteractiveCampusModalProps> = ({
  isOpen,
  lang,
  onClose,
  onOpenBookVisit
}) => {
  const [selectedFacility, setSelectedFacility] = useState<FacilityHotspot>(campusHotspots[0]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div 
        className="relative w-full max-w-5xl bg-white rounded-xl shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col border border-gray-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#001744] text-white px-6 py-4 flex items-center justify-between border-b border-[#002169] shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-[#CE0E2D]">
              <Compass className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold font-serif-heading text-white">
                {lang === 'fa' ? 'نقشه تعاملی پردیس تانگلین تراست' : 'Interactive Campus Map & Facilities'}
              </h2>
              <p className="text-xs text-slate-300">
                {lang === 'fa' ? 'پردیس وان-نورث سنگاپور - خیابان پورتس‌داون' : 'Portsdown Road, One-North Singapore 139294'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Interactive Map Surface (7 cols on lg) */}
          <div className="lg:col-span-7 flex flex-col space-y-3">
            <div className="relative aspect-[4/3] rounded-lg overflow-hidden border-2 border-gray-200 shadow-inner bg-slate-900 group">
              {/* Illustrated Campus Aerial Backdrop */}
              <img
                src="/assets/photos/campus-map.jpg"
                alt="Campus Map Layout"
                className="w-full h-full object-cover opacity-85 group-hover:opacity-95 transition-opacity"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30 pointer-events-none" />

              {/* Interactive Hotspots Pins */}
              {campusHotspots.map((spot) => (
                <button
                  key={spot.id}
                  onClick={() => setSelectedFacility(spot)}
                  style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 p-2 rounded-full shadow-lg transition-all duration-300 transform hover:scale-125 focus:outline-none ${
                    selectedFacility.id === spot.id
                      ? 'bg-[#CE0E2D] text-white ring-4 ring-white ring-offset-2 z-20 scale-115'
                      : 'bg-[#002169] text-white hover:bg-[#CE0E2D] z-10'
                  }`}
                  title={lang === 'fa' ? spot.nameFa : spot.nameEn}
                >
                  <MapPin className="w-4 h-4" />
                </button>
              ))}

              <div className="absolute bottom-3 inset-x-3 bg-black/65 backdrop-blur-xs text-white px-3 py-1.5 rounded text-[11px] flex items-center justify-between">
                <span>{lang === 'fa' ? 'برای مشاهده جزئیات بر روی نشانگرهای نقشه کلیک کنید' : 'Click any map pin to explore that facility'}</span>
                <span className="font-bold text-[#CE0E2D]">{campusHotspots.length} Landmark Locations</span>
              </div>
            </div>

            {/* Quick Facility Selector Buttons */}
            <div className="flex flex-wrap gap-1.5">
              {campusHotspots.map((spot) => (
                <button
                  key={spot.id}
                  onClick={() => setSelectedFacility(spot)}
                  className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors ${
                    selectedFacility.id === spot.id
                      ? 'bg-[#002169] text-white shadow-xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {lang === 'fa' ? spot.nameFa : spot.nameEn}
                </button>
              ))}
            </div>
          </div>

          {/* Facility Details Panel (5 cols on lg) */}
          <div className="lg:col-span-5 bg-[#FAFBFD] p-5 rounded-lg border border-gray-200 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="relative aspect-[16/10] rounded-md overflow-hidden shadow-xs">
                <img
                  src={selectedFacility.image}
                  alt={selectedFacility.nameEn}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-2 right-2 bg-[#CE0E2D] text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xs">
                  {selectedFacility.category}
                </span>
              </div>

              <div>
                <h3 className="text-base sm:text-lg font-bold text-[#002169] leading-snug">
                  {lang === 'fa' ? selectedFacility.nameFa : selectedFacility.nameEn}
                </h3>
                <p className="mt-1 text-gray-600 text-xs sm:text-sm leading-relaxed">
                  {lang === 'fa' ? selectedFacility.descFa : selectedFacility.descEn}
                </p>
              </div>

              <div className="pt-1">
                <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider mb-1.5">
                  {lang === 'fa' ? 'ویژگی‌های برجسته' : 'Key Specifications'}
                </h4>
                <ul className="space-y-1">
                  {(lang === 'fa' ? selectedFacility.featuresFa : selectedFacility.featuresEn).map((feat, idx) => (
                    <li key={idx} className="text-xs text-gray-700 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#CE0E2D] shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-2 border-t border-gray-200">
              <button
                onClick={() => {
                  onClose();
                  onOpenBookVisit();
                }}
                className="w-full bg-[#002169] hover:bg-[#001744] text-white text-xs font-bold py-2.5 px-4 rounded transition-colors flex items-center justify-center gap-2"
              >
                <span>{lang === 'fa' ? 'رزرو تور حضوری از این بخش' : 'Book a Tour to See This in Person'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-50 px-6 py-3 border-t border-gray-200 flex items-center justify-between shrink-0">
          <span className="text-xs text-gray-500">
            {lang === 'fa' ? 'پردیس ۵.۵ هکتاری با پیشرفته‌ترین امکانات ورزشی و تحصیلی' : '5.5 Hectare World-Class International School Campus'}
          </span>
          <button
            onClick={onClose}
            className="text-xs font-bold text-gray-700 hover:text-gray-900"
          >
            {lang === 'fa' ? 'بستن' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
