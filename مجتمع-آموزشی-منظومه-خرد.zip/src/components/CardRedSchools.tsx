import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { schoolCardsData } from '../data/tanglinMainPageData';
import { Language } from '../types';

interface CardRedSchoolsProps {
  lang: Language;
  onSelectSchool: (schoolId: string) => void;
}

export const CardRedSchools: React.FC<CardRedSchoolsProps> = ({ lang, onSelectSchool }) => {
  return (
    <section className="w-full bg-[#FAFBFD] py-14 md:py-18 px-4 sm:px-8 border-b border-gray-200">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 md:mb-12">
          <span className="text-xs font-bold uppercase tracking-widest text-[#CE0E2D] bg-[#fdf2f4] px-3 py-1 rounded inline-block mb-3 border border-[#CE0E2D]/20">
            {lang === 'fa' ? 'مقاطع سه‌گانه تانگلین' : 'The Three Tanglin Schools'}
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif-heading font-bold text-[#002169] tracking-tight">
            {lang === 'fa' ? 'کاوش در مدارس تانگلین' : 'Discover Our Schools'}
          </h2>
          <p className="mt-2 text-gray-600 text-sm sm:text-base">
            {lang === 'fa'
              ? 'محیط‌های آموزشی اختصاصی و متناسب با هر دوره سنی، از نخستین سال‌های خردسالی تا ورود به دانشگاه‌های تراز اول'
              : 'Tailored learning communities designed for each stage of development, from early discovery to university preparation'}
          </p>
        </div>

        {/* 3 Schools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {schoolCardsData.map((school) => (
            <div
              key={school.id}
              className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 flex flex-col border border-gray-200 border-t-4 border-t-[#CE0E2D] group"
            >
              {/* Photo */}
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={school.image}
                  alt={school.titleEn}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <span className="absolute top-3 right-3 bg-[#002169] text-white text-[11px] font-bold px-2.5 py-1 rounded shadow-md">
                  {school.ageRange}
                </span>
              </div>

              {/* Content */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-[#002169] group-hover:text-[#CE0E2D] transition-colors whitespace-pre-line leading-tight">
                    {lang === 'fa' ? school.titleFa : school.titleEn}
                  </h3>
                  <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
                    {lang === 'fa' ? school.descriptionFa : school.descriptionEn}
                  </p>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => onSelectSchool(school.id)}
                    className="w-full inline-flex items-center justify-center gap-2 bg-[#CE0E2D] hover:bg-[#b00b25] text-white text-xs sm:text-sm font-bold py-2.5 px-4 rounded transition-all duration-200 shadow-xs group-hover:shadow-md"
                  >
                    <span>{lang === 'fa' ? school.buttonTextFa : school.buttonTextEn}</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
