import React, { useState } from 'react';
import { schoolStages } from '../data/tanglinData';
import { Language, SchoolStage } from '../types';
import { 
  GraduationCap, 
  Users, 
  CheckCircle2, 
  ArrowRight, 
  BookOpen, 
  UserCheck,
  Calendar
} from 'lucide-react';

interface SchoolsSectionProps {
  lang: Language;
  onOpenBookVisit: () => void;
}

export const SchoolsSection: React.FC<SchoolsSectionProps> = ({ lang, onOpenBookVisit }) => {
  const isPersian = lang === 'fa';
  const [activeSchoolId, setActiveSchoolId] = useState<string>('sixth-form');

  const currentSchool = schoolStages.find(s => s.id === activeSchoolId) || schoolStages[0];

  return (
    <section id="schools" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0F2537]/5 text-[#0F2537] text-xs font-bold uppercase tracking-widest mb-3">
            <GraduationCap className="w-3.5 h-3.5 text-[#C5A85C]" />
            {isPersian ? 'ساختار آموزشی یکپارچه' : 'Our Four Distinct Schools'}
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-serif-heading text-[#0F2537]">
            {isPersian ? 'چهار مقطع تحصیلی در پردیس تانگلین' : 'Schools Within Tanglin'}
          </h2>
          <div className="w-16 h-1 bg-[#C5A85C] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            {isPersian
              ? 'از مهدکودک ۳ سالگی تا کالج پیش‌دانشگاهی ۱۸ سالگی؛ هر مقطع با مدیریت، اساتید متخصص و ساختمان‌های متناسب با سن طراحی شده است.'
              : 'From age 3 in Nursery to age 18 in Sixth Form, each school provides specialized pastoral care and tailored academic facilities under one cohesive campus.'}
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-4 mb-8">
          {schoolStages.map((school) => {
            const isActive = school.id === activeSchoolId;
            return (
              <button
                key={school.id}
                onClick={() => setActiveSchoolId(school.id)}
                className={`p-4 rounded-xl text-left sm:text-center transition-all border ${
                  isActive
                    ? 'bg-[#0F2537] text-white border-[#0F2537] shadow-lg'
                    : 'bg-white text-slate-700 hover:bg-slate-100 border-slate-200'
                }`}
              >
                <div className={`text-xs font-bold uppercase tracking-wider ${isActive ? 'text-[#C5A85C]' : 'text-slate-400'}`}>
                  {school.ageRange}
                </div>
                <div className="text-sm sm:text-base font-bold font-serif-heading mt-1">
                  {isPersian ? school.nameFa : school.nameEn}
                </div>
                <div className={`text-[11px] mt-1 ${isActive ? 'text-slate-300' : 'text-slate-500'}`}>
                  {isPersian ? school.yearGroupsFa : school.yearGroupsEn}
                </div>
              </button>
            );
          })}
        </div>

        {/* School Feature Detail Box */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-xl border border-slate-200">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            
            {/* Left: Info & Curriculum */}
            <div className="lg:col-span-7 p-6 sm:p-10 space-y-6 flex flex-col justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-3 mb-2">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#C5A85C]/15 text-[#0F2537] border border-[#C5A85C]/30">
                    {currentSchool.ageRange}
                  </span>
                  <span className="text-xs font-semibold text-slate-500">
                    {isPersian ? currentSchool.yearGroupsFa : currentSchool.yearGroupsEn}
                  </span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-bold font-serif-heading text-[#0F2537]">
                  {isPersian ? currentSchool.nameFa : currentSchool.nameEn}
                </h3>

                {/* Head of School */}
                <div className="flex items-center gap-2 text-xs font-medium text-slate-600 mt-2 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <UserCheck className="w-4 h-4 text-[#C5A85C] shrink-0" />
                  <span>{isPersian ? currentSchool.headFa : currentSchool.headEn}</span>
                </div>

                {/* Description */}
                <p className="mt-4 text-slate-600 text-sm sm:text-base leading-relaxed">
                  {isPersian ? currentSchool.descriptionFa : currentSchool.descriptionEn}
                </p>

                {/* Highlights */}
                <div className="mt-6 space-y-2.5">
                  <div className="text-xs font-bold uppercase tracking-wider text-[#0F2537]">
                    {isPersian ? 'ویژگی‌های کلیدی این مقطع:' : 'Key Educational Highlights:'}
                  </div>
                  {(isPersian ? currentSchool.highlightsFa : currentSchool.highlightsEn).map((hl, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-[#C5A85C] shrink-0 mt-0.5" />
                      <span>{hl}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-6 border-t border-slate-100 flex flex-wrap items-center gap-3">
                <button
                  onClick={onOpenBookVisit}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#0F2537] text-white font-bold text-xs sm:text-sm hover:bg-[#162E4A] transition-colors shadow-md"
                >
                  <Calendar className="w-4 h-4 text-[#C5A85C]" />
                  <span>{isPersian ? 'رزرو بازدید از این مقطع' : 'Book a School Tour'}</span>
                </button>
                <a
                  href="#academics"
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg border border-slate-300 text-slate-700 font-semibold text-xs sm:text-sm hover:bg-slate-50 transition-colors"
                >
                  <BookOpen className="w-4 h-4 text-[#C5A85C]" />
                  <span>{isPersian ? 'مشاهده سرفصل‌های درسی' : 'View Curriculum Guide'}</span>
                </a>
              </div>
            </div>

            {/* Right: School Photography */}
            <div className="lg:col-span-5 relative min-h-[320px] lg:min-h-full">
              <img
                src={currentSchool.image}
                alt={currentSchool.nameEn}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0F2537]/80 via-transparent to-transparent flex items-end p-6">
                <div className="text-white">
                  <div className="text-xs font-bold text-[#C5A85C] uppercase tracking-wider">
                    {isPersian ? 'محیط آموزشی استاندارد' : 'Tanglin Learning Space'}
                  </div>
                  <div className="text-lg font-bold font-serif-heading">
                    {isPersian ? currentSchool.nameFa : currentSchool.nameEn}
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
