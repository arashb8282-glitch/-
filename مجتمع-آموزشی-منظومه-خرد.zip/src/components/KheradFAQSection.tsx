import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, HelpCircle, BookOpen, GraduationCap, Compass, Sparkles } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface FAQItem {
  id: string;
  category: 'philosophy' | 'programs' | 'admissions' | 'campus';
  questionFa: string;
  questionEn: string;
  answerFa: string;
  answerEn: string;
}

interface KheradFAQSectionProps {
  onOpenAdmissions?: () => void;
}

export const KheradFAQSection: React.FC<KheradFAQSectionProps> = ({ onOpenAdmissions }) => {
  const { isPersian } = useLanguage();
  const [activeTab, setActiveTab] = useState<string>('all');
  const [openIds, setOpenIds] = useState<string[]>(['faq-1']);

  const faqData: FAQItem[] = [
    {
      id: 'faq-1',
      category: 'philosophy',
      questionFa: 'رویکرد آموزشی و فلسفه تربیتی مجتمع آموزشی خرد چیست؟',
      questionEn: 'What is Kherad Complex’s educational philosophy and pedagogy?',
      answerFa: 'منظومه خرد بر پایه الگوی یادگیری سازنده‌گرا، انسان‌گرا و پروژه‌محور بنا شده است؛ با تأکید بر پرورش تفکر نقادانه، حل مسئله، اخلاق زیست‌محیطی و مهارت‌های زندگی در فضایی امن و سرشار از احترام متقابل.',
      answerEn: 'Kherad Complex is founded on constructivist, humanist, and project-based learning, fostering critical thinking, creative agency, problem-solving, and environmental ethics within an inclusive environment.'
    },
    {
      id: 'faq-2',
      category: 'admissions',
      questionFa: 'فرآیند پیش‌ثبت‌نام و پذیرش دانش‌آموزان در مقاطع مختلف چگونه انجام می‌شود؟',
      questionEn: 'How does student pre-registration and admission proceed across grades?',
      answerFa: 'پذیرش با ثبت‌نام اولیه در سامانه آنلاین آغاز می‌شود؛ در مقاطع پیش‌دبستان و دبستان از طریق جلسات تعاملی با والدین و کودک، و در دوره‌های متوسطه از طریق سنجش نگرشی-علمی و مصاحبه حضوری انجام می‌پذیرد.',
      answerEn: 'Admissions commence with an online application, followed by interactive parent-child dialogue for preschool/primary, and holistic aptitude evaluation with interviews for secondary stages.'
    },
    {
      id: 'faq-3',
      category: 'programs',
      questionFa: 'برنامه‌های پژوهشی، هنر و فعالیت‌های بین‌رشته‌ای چگونه سازمان‌دهی شده‌اند؟',
      questionEn: 'How are research, fine arts, and interdisciplinary programs structured?',
      answerFa: 'خرد دارای دپارتمان‌های یکپارچه پژوهش، هنر و توسعه پایدار است که در قالب کلوپ‌های تخصصی، جشنواره‌های پروژه‌محور، کارگاه‌های تجسمی و خانه هنر فعالیت می‌کنند.',
      answerEn: 'Kherad integrates dedicated Research, Arts, and Sustainability departments with specialized clubs, project-based competitions, and Art House productions.'
    },
    {
      id: 'faq-4',
      category: 'programs',
      questionFa: 'سیستم آموزش زبان‌های بین‌المللی در خرد چه ویژگی‌هایی دارد؟',
      questionEn: 'What are the defining characteristics of Kherad’s international language curriculum?',
      answerFa: 'آموزش زبان انگلیسی از پیش‌دبستانی با رویکرد غوطه‌وری محتوامحور (CLIL) آغاز شده و در دوره‌های بالاتر، زبان‌های فرانسه و آلمانی جهت آمادگی در آزمون‌های بین‌المللی ارائه می‌گردند.',
      answerEn: 'English instruction starts in Preschool through Content and Language Integrated Learning (CLIL), with French and German offered in advanced stages.'
    },
    {
      id: 'faq-5',
      category: 'philosophy',
      questionFa: 'مفهوم «مدرسه سبز» و توسعه پایدار در منظومه خرد چگونه عملیاتی می‌شود؟',
      questionEn: 'How is the "Green School" ethos and sustainability operationalized at Kherad?',
      answerFa: 'خرد به عنوان پیشگام مدارس سبز ایران، مدیریت انرژی، بازیافت، بام سبز آموزشی و پروژه‌های میدانی پایداری را در زیست روزمره مدرسه نهادینه کرده است.',
      answerEn: 'As an eco-school pioneer, Kherad embeds renewable conservation, recycling, educational green roofs, and organic gardens into everyday school culture.'
    },
    {
      id: 'faq-6',
      category: 'campus',
      questionFa: 'مجتمع آموزشی خرد در ولنجک چه امکانات رفاهی، ورزشی و آزمایشگاهی دارد؟',
      questionEn: 'What athletic, scientific, and community facilities are available on campus?',
      answerFa: 'دارای سالن همایش، مجموعه ورزشی و استخر سرپوشیده، زمین روباز، آزمایشگاه‌های تخصصی علوم، کارگاه‌های روباتیک، کتابخانه غنی و سالن غذاخوری مرکزی است.',
      answerEn: 'The campus features an auditorium, indoor sports and aquatic complex, dedicated science labs, robotics studios, library, and central dining facility.'
    },
  ];

  const categories = [
    { id: 'all', labelFa: 'همه', labelEn: 'All', icon: HelpCircle },
    { id: 'philosophy', labelFa: 'فلسفه و رویکرد', labelEn: 'Philosophy', icon: Compass },
    { id: 'admissions', labelFa: 'پذیرش و ثبت‌نام', labelEn: 'Admissions', icon: GraduationCap },
    { id: 'programs', labelFa: 'برنامه‌ها و آموزش', labelEn: 'Programs', icon: BookOpen },
    { id: 'campus', labelFa: 'امکانات مجتمع آموزشی خرد', labelEn: 'Campus', icon: Sparkles },
  ];

  const filteredFaqs = activeTab === 'all' 
    ? faqData 
    : faqData.filter(item => item.category === activeTab);

  const toggleItem = (id: string) => {
    setOpenIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  return (
    <section 
      id="kherad-faq"
      className="w-full bg-[#1c1f26] text-white py-10 md:py-14 px-4 sm:px-8 border-b border-white/[0.08] transition-colors"
      dir={isPersian ? 'rtl' : 'ltr'}
    >
      <div className="max-w-4xl mx-auto">
        {/* Minimal Compact Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-7 border-b border-white/[0.1] pb-4">
          <div>
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              <span className="w-1.5 h-1.5 rounded-none bg-[#0b82c6]" />
              <span className="text-slate-300">{isPersian ? 'پرسش‌های متداول' : 'FAQ'}</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight font-serif-heading">
              {isPersian ? 'پاسخ به سوالات پرتکرار' : 'Frequently Asked Questions'}
            </h2>
          </div>

          {/* Minimal Category Filter Tabs - Sharp corners */}
          <div className="flex items-center gap-1 flex-wrap">
            {categories.map((cat) => {
              const isActive = activeTab === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveTab(cat.id)}
                  className={`px-2.5 py-1 text-[11px] font-medium rounded-none border transition-colors cursor-pointer select-none ${
                    isActive
                      ? 'bg-[#0b82c6] text-white border-[#0b82c6]'
                      : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {isPersian ? cat.labelFa : cat.labelEn}
                </button>
              );
            })}
          </div>
        </div>

        {/* Minimal Accordion List - Font 2 sizes smaller (text-xs / 12px) */}
        <div className="divide-y divide-white/[0.08] border-y border-white/[0.08] bg-[#222630]">
          {filteredFaqs.map((faq, index) => {
            const isOpen = openIds.includes(faq.id);
            return (
              <div
                key={faq.id}
                className="transition-colors hover:bg-white/[0.03]"
              >
                <button
                  type="button"
                  onClick={() => toggleItem(faq.id)}
                  aria-expanded={isOpen}
                  className="w-full flex items-center justify-between gap-3 py-3 px-3.5 sm:px-4 text-left cursor-pointer focus:outline-none"
                  dir={isPersian ? 'rtl' : 'ltr'}
                >
                  <div className="flex items-center gap-2.5 flex-1 min-w-0">
                    <span className="text-[10px] font-mono text-slate-400 shrink-0 w-4 text-center">
                      {(index + 1).toString().padStart(2, '0')}
                    </span>
                    {/* Questions 2 sizes smaller: text-xs font-semibold */}
                    <h3 className={`text-xs sm:text-[12.5px] font-semibold text-right transition-colors truncate sm:whitespace-normal ${
                      isOpen ? 'text-[#0b82c6]' : 'text-slate-100'
                    }`}>
                      {isPersian ? faq.questionFa : faq.questionEn}
                    </h3>
                  </div>

                  <div className={`p-1 text-slate-400 shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180 text-[#0b82c6]' : ''}`}>
                    <ChevronDown className="w-3.5 h-3.5 stroke-[2]" />
                  </div>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      key="content"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2, ease: "easeInOut" }}
                      className="overflow-hidden bg-[#181b22]"
                    >
                      <div 
                        className={`px-3.5 sm:px-4 py-2.5 text-[11px] sm:text-xs leading-relaxed text-slate-300 font-normal border-t border-white/[0.06] ${
                          isPersian ? 'pr-9 sm:pr-10' : 'pl-9 sm:pl-10'
                        }`}
                        dir={isPersian ? 'rtl' : 'ltr'}
                      >
                        <p>{isPersian ? faq.answerFa : faq.answerEn}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

        {/* Minimal Bottom Admissions Link */}
        {onOpenAdmissions && (
          <div className="mt-4 flex items-center justify-between px-1 text-[11px] text-slate-400">
            <span>{isPersian ? 'پرسش دیگری دارید؟' : 'Have another question?'}</span>
            <button
              onClick={onOpenAdmissions}
              className="text-[#0b82c6] hover:text-[#38bdf8] hover:underline font-semibold cursor-pointer"
            >
              {isPersian ? 'تماس با واحد پذیرش خرد ←' : 'Contact Admissions →'}
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
