import React from 'react';
import { ArrowRight, Award } from 'lucide-react';
import { Language } from '../types';

interface PanelNavyAboutProps {
  lang: Language;
  onOpenDetails: (id: string) => void;
}

export const PanelNavyAbout: React.FC<PanelNavyAboutProps> = ({ lang, onOpenDetails }) => {
  return (
    <section className="w-full bg-[#16216a] text-white py-12 md:py-16 px-4 sm:px-8 border-b border-[#001744]">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Authentic Text (approx 5 cols on lg) */}
          <div className="lg:col-span-5 flex flex-col justify-center space-y-5">
            <div className="space-y-3">
              <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-[#f0b0bd] bg-white/10 px-2.5 py-1 rounded">
                <Award className="w-3.5 h-3.5 text-[#CE0E2D]" />
                {lang === 'fa' ? 'پیشگام آموزش بین‌المللی' : 'British International School in Singapore'}
              </span>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif-heading font-bold text-white tracking-tight leading-tight">
                {lang === 'fa' ? 'درباره تانگلین' : 'About Tanglin'}
              </h1>
            </div>

            <div className="space-y-4 text-slate-100 text-[15px] sm:text-[16px] leading-relaxed font-normal">
              <p>
                {lang === 'fa' ? (
                  <>
                    مدرسه <strong>تانگلین تراست (Tanglin Trust School)</strong> که در سال ۱۹۲۵ میلادی تاسیس شده، قدیمی‌ترین مدرسه بین‌المللی بریتانیایی در جنوب شرق آسیاست. تانگلین برنامه ملی درسی انگلستان را با رویکردی عمیقاً بین‌المللی به کودکان و نوجوانان ۳ تا ۱۸ سال در سنگاپور ارائه می‌دهد.
                  </>
                ) : (
                  <>
                    Established in 1925, <strong>Tanglin Trust School</strong> is the oldest British international school in Southeast Asia. Tanglin provides the English National Curriculum with an international perspective to children from 3 to 18 years in Singapore.
                  </>
                )}
              </p>

              <p>
                {lang === 'fa' ? (
                  <>
                    تانگلین جامعه‌ای پرنشاط و مختلط با <strong>۲٬۸۵۰ دانش‌آموز</strong> از بیش از <strong>۵۵ ملیت</strong> گوناگون است و محیط یادگیری کم‌نظیری از مهدکودک تا دوره پیش‌دانشگاهی (سال ششم) فراهم می‌سازد. به عنوان یک مدرسه <strong>غیرانتفاعی (Not-for-Profit)</strong>، تمامی شهریه‌ها و درآمدها وقف ارائه بهترین سطح آموزش می‌گردد. تانگلین تنها مدرسه در سنگاپور است که همزمان هر دو دوره <strong>A Level</strong> و <strong>دیپلم بین‌المللی IB</strong> را در سال ششم ارائه می‌دهد؛ این امر متضمن انتخابی استوار متناسب با استعداد هر دانش‌آموز است.
                  </>
                ) : (
                  <>
                    Tanglin is a vibrant co-educational school of <strong>2,850 students</strong> representing over <strong>55 nationalities</strong> and provides a unique learning environment for children from Nursery through to Sixth Form. As a <strong>not-for-profit school</strong>, tuition fees are devoted to the provision of an outstanding education. Tanglin is the only school in Singapore to offer <strong>A Level and the IB Diploma in Sixth Form</strong>, ensuring each student benefits from an educational pathway that is best suited to them.
                  </>
                )}
              </p>

              <p className="text-slate-200">
                {lang === 'fa' ? (
                  <>
                    مدرسه پیوسته به نتایج امتحانی برجسته‌ای دست می‌یابد که بسیار فراتر از میانگین‌های سنگاپور و جهان است. حدود <strong>۹۶٪ از فارغ‌التحصیلان تانگلین</strong> به طور معمول پذیرش نخستین یا دومین دانشگاه منتخب خود را در زمره برترین دانشگاه‌های جهان دریافت می‌کنند.
                  </>
                ) : (
                  <>
                    The school consistently achieves outstanding examination results that surpass Singapore and global averages. Around <strong>96% of graduates</strong> typically secure admission to their first or second-choice universities, which are amongst the best in the world.
                  </>
                )}
              </p>
            </div>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => onOpenDetails('academics')}
                className="inline-flex items-center gap-2 bg-[#CE0E2D] hover:bg-[#b00b25] text-white text-xs sm:text-sm font-bold px-5 py-2.5 rounded transition-all duration-200 shadow-md hover:shadow-lg"
              >
                <span>{lang === 'fa' ? 'مشاهده نتایج تحصیلی و دانشگاهی' : 'View Academic Results & Pathways'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              
              <button
                onClick={() => onOpenDetails('history')}
                className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-medium px-4 py-2.5 rounded border border-white/25 transition-all"
              >
                <span>{lang === 'fa' ? 'تاریخچه ۱۰۰ ساله' : '100-Year Heritage'}</span>
              </button>
            </div>
          </div>

          {/* Right Column: Graduation Photo (approx 7 cols on lg) */}
          <div className="lg:col-span-7">
            <div className="relative rounded-lg overflow-hidden shadow-2xl border-2 border-white/10 group">
              <img
                src="/assets/photos/graduates.jpg"
                alt="Tanglin Trust School Year 13 Graduates Celebrating"
                className="w-full h-auto object-cover object-center max-h-[520px] transition-transform duration-500 group-hover:scale-102"
                referrerPolicy="no-referrer"
                loading="lazy"
              />
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 text-white text-xs">
                <p className="font-medium">
                  {lang === 'fa' 
                    ? 'جشن فارغ‌التحصیلی سال ۲۵ تانگلین - راهیابی ۹۶٪ دانش‌آموزان به برترین دانشگاه‌های جهان'
                    : 'Tanglin Class of 2024/2025 Graduation - 96% secured first or second-choice universities'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
