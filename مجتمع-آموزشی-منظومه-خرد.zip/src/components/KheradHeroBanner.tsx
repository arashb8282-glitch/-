import React from 'react';
import { motion } from 'motion/react';
import { Search, Mail, Instagram, Linkedin } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface KheradHeroBannerProps {
  onScrollDown?: () => void;
  onOpenMenu?: () => void;
  onOpenSearch?: () => void;
  onLogoClick?: () => void;
  onSelectSystem?: (systemId: string) => void;
}

export const KheradHeroBanner: React.FC<KheradHeroBannerProps> = ({
  onScrollDown,
  onOpenMenu,
  onOpenSearch,
  onLogoClick,
  onSelectSystem
}) => {
  const { isPersian } = useLanguage();

  return (
    <section 
      id="hero-banner"
      className="relative w-full h-screen min-h-screen overflow-hidden bg-[#112544] select-none border-b border-black/[0.06]"
      dir={isPersian ? 'rtl' : 'ltr'}
    >
      {/* 1. Sleek Top Toolbar */}
      <header 
        className="absolute top-0 inset-x-0 h-11 sm:h-12 bg-white text-slate-700 z-30 px-5 sm:px-8 md:px-12 flex items-center justify-between border-b border-black/[0.06] shadow-none select-none transition-colors"
        dir="rtl"
      >
        {/* Right side: Clean Navigation Links - darker and one weight thicker (font-semibold) */}
        <div className="flex items-center gap-5 sm:gap-7 md:gap-8 pr-8 sm:pr-9 md:pr-10 text-slate-700 text-xs sm:text-[12.5px] font-semibold overflow-x-auto no-scrollbar">
          <button
            onClick={() => onSelectSystem?.('lms')}
            className="text-slate-700 hover:text-slate-950 transition-colors cursor-pointer focus:outline-none whitespace-nowrap"
            title={isPersian ? 'سامانه یادگیری الکترونیکی خرد' : 'LMS Portal'}
          >
            <span>{isPersian ? 'سامانه مدیریت یادگیری' : 'Learning Management System'}</span>
          </button>

          <button
            onClick={() => onSelectSystem?.('services')}
            className="text-slate-700 hover:text-slate-950 transition-colors cursor-pointer focus:outline-none whitespace-nowrap"
            title={isPersian ? 'سامانه خدمات سازمانی خرد' : 'Services'}
          >
            <span>{isPersian ? 'سامانه خدمات سازمانی' : 'Organizational Services'}</span>
          </button>
        </div>

        {/* Left side: Icons Suite (Search + Mail + Socials) */}
        <div className="flex items-center gap-3.5 sm:gap-4 md:gap-4.5 text-slate-700" dir="ltr">
          {/* 1. Search Icon */}
          <button
            type="button"
            onClick={onOpenSearch || onOpenMenu}
            className="p-1 hover:text-slate-950 transition-colors cursor-pointer flex items-center justify-center shrink-0"
            title={isPersian ? 'جستجو در سایت' : 'Search site'}
            aria-label="Search"
          >
            <Search className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[1.85]" />
          </button>

          {/* 2. Email Icon */}
          <a
            href="mailto:info@kheradedu.ir"
            className="p-1 hover:text-slate-950 transition-colors cursor-pointer flex items-center justify-center shrink-0"
            title={isPersian ? 'ارسال ایمیل (info@kheradedu.ir)' : 'Send Email'}
            aria-label="Email"
          >
            <Mail className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[1.85]" />
          </a>

          {/* 3. Instagram Icon */}
          <a
            href="https://www.instagram.com/kheradedu"
            target="_blank"
            rel="noopener noreferrer"
            className="p-1 hover:text-slate-950 transition-colors cursor-pointer flex items-center justify-center shrink-0"
            title={isPersian ? 'اینستاگرام خرد' : 'Instagram'}
            aria-label="Instagram"
          >
            <Instagram className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[1.85]" />
          </a>

          {/* 4. Telegram Icon */}
          <a
            href="https://t.me/kheradedu"
            target="_blank"
            rel="noopener noreferrer"
            className="p-1 hover:text-slate-950 transition-colors cursor-pointer flex items-center justify-center shrink-0 hidden sm:flex"
            title={isPersian ? 'کانال تلگرام خرد' : 'Telegram'}
            aria-label="Telegram"
          >
            <svg
              className="w-3.5 h-3.5 sm:w-4 sm:h-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.85"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m22 2-7 20-4-9-9-4 20-7z" />
              <path d="M22 2 11 13" />
            </svg>
          </a>

          {/* 5. LinkedIn Icon */}
          <a
            href="https://www.linkedin.com/company/kheradedu"
            target="_blank"
            rel="noopener noreferrer"
            className="p-1 hover:text-slate-950 transition-colors cursor-pointer flex items-center justify-center shrink-0 hidden sm:flex"
            title={isPersian ? 'صفحه لینکدین خرد' : 'LinkedIn'}
            aria-label="LinkedIn"
          >
            <Linkedin className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[1.85]" />
          </a>
        </div>
      </header>

      {/* 2. Logo Sitting Underneath Toolbar Directly on the Photo - Left aligned with icons */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="absolute top-14 sm:top-16 md:top-18 left-5 sm:left-8 md:left-12 z-20 pointer-events-auto"
      >
        <button 
          onClick={onLogoClick}
          className="focus:outline-none cursor-pointer block hover:opacity-95 transition-all p-0 m-0 bg-transparent border-0"
          aria-label={isPersian ? 'لوگوی رسمی مجتمع آموزشی منظومه خرد' : 'Kherad Official Logo'}
        >
          <img
            src="/assets/logo.svg"
            alt={isPersian ? 'مجتمع آموزشی و فرهنگی دخترانه منظومه خرد' : 'Kherad Educational & Cultural Complex'}
            className="h-16 sm:h-20 md:h-[84px] lg:h-[92px] w-auto object-contain transition-transform duration-200 brightness-0 invert drop-shadow-[0_3px_10px_rgba(0,0,0,0.75)]"
          />
        </button>
      </motion.div>

      {/* 3. Full-bleed authentic Kherad campus architectural photograph */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/kherad-brand/photos/21.webp"
          alt={isPersian ? 'مجتمع آموزشی خرد' : 'Kherad Educational Complex Campus'}
          className="w-full h-full object-cover object-top"
          loading="eager"
        />
      </div>
    </section>
  );
};
