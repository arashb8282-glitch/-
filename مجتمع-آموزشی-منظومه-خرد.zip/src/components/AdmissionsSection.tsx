import React from 'react';
import { Language } from '../types';
import { 
  GraduationCap, 
  Calendar, 
  FileCheck, 
  Coins, 
  UserPlus, 
  CheckCircle2, 
  ArrowRight,
  ShieldAlert,
  HeartHandshake
} from 'lucide-react';

interface AdmissionsSectionProps {
  lang: Language;
  onOpenBookVisit: () => void;
}

export const AdmissionsSection: React.FC<AdmissionsSectionProps> = ({
  lang,
  onOpenBookVisit
}) => {
  const isPersian = lang === 'fa';

  const steps = [
    {
      step: '01',
      titleEn: 'Explore & Visit',
      titleFa: 'آشنایی و بازدید',
      descEn: 'Attend an Open Morning or experience a personalized campus tour with our Admissions team.',
      descFa: 'شرکت در روزهای درهای باز (Open Morning) یا بازدید اختصاصی از پردیس به همراه کارشناسان پذیرش.'
    },
    {
      step: '02',
      titleEn: 'Submit Online Application',
      titleFa: 'ثبت‌نام آنلاین',
      descEn: 'Complete the admissions form and upload official academic transcripts and confidential references.',
      descFa: 'تکمیل فرم آنلاین، بارگذاری ریزنمرات رسمی، مدارک هویتی و توصیه‌نامه‌های معتبر مدرسه قبلی.'
    },
    {
      step: '03',
      titleEn: 'Review & Assessment',
      titleFa: 'بررسی و مصاحبه',
      descEn: 'Age-appropriate assessment or interview to ensure alignment with our curriculum and community.',
      descFa: 'انجام ارزیابی متناسب با سن دانش‌آموز یا مصاحبه حضوری/آنلاین جهت اطمینان از آمادگی تحصیلی.'
    },
    {
      step: '04',
      titleEn: 'Offer & Welcome',
      titleFa: 'پذیرش قطعی و آغاز تحصیل',
      descEn: 'Receive your formal offer letter and join our comprehensive onboarding and buddy programme.',
      descFa: 'دریافت نامه پذیرش رسمی و عضویت در برنامه استقبال و آماده‌سازی ورود به جامعه تانگلین.'
    },
  ];

  return (
    <section id="admissions-section" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0F2537]/5 text-[#0F2537] text-xs font-bold uppercase tracking-widest mb-3">
            <GraduationCap className="w-3.5 h-3.5 text-[#C5A85C]" />
            <span>{isPersian ? 'پذیرش و پیوستن به تانگلین' : 'Admissions & Joining Tanglin'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-serif-heading text-[#0F2537]">
            {isPersian ? 'مراحل ثبت‌نام و پذیرش دانش‌آموزان' : 'Your Journey to Tanglin'}
          </h2>
          <div className="w-16 h-1 bg-[#C5A85C] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            {isPersian
              ? 'تیم پذیرش تانگلین در تمام مراحل انتخاب مقطع، سنجش و ثبت‌نام همراه خانواده‌های گرامی از سراسر جهان خواهد بود.'
              : 'Our dedicated admissions team guides families through every stage of application, from Nursery entry through to Sixth Form.'}
          </p>
        </div>

        {/* 4 Step Process Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {steps.map((st, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-[#C5A85C] hover:bg-white shadow-sm hover:shadow-lg transition-all relative flex flex-col justify-between"
            >
              <div>
                <span className="text-3xl font-extrabold text-[#C5A85C] font-serif-heading">
                  {st.step}
                </span>
                <h3 className="text-lg font-bold font-serif-heading text-[#0F2537] mt-3">
                  {isPersian ? st.titleFa : st.titleEn}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  {isPersian ? st.descFa : st.descEn}
                </p>
              </div>

              <div className="mt-6 pt-3 border-t border-slate-200 flex items-center gap-1.5 text-xs text-[#0F2537] font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#C5A85C]" />
                <span>{isPersian ? 'گام رسمی پذیرش' : 'Admissions Milestone'}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Not-for-Profit Commitment Banner */}
        <div className="rounded-2xl bg-[#0F2537] text-white p-8 sm:p-12 border border-[#C5A85C]/30 shadow-2xl relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A85C]/20 text-[#E5C97A] text-xs font-bold uppercase tracking-wider">
                <HeartHandshake className="w-4 h-4 text-[#C5A85C]" />
                <span>100% Not-for-Profit Educational Trust</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-bold font-serif-heading text-white">
                {isPersian
                  ? 'تعهد کامل به موسسه آموزشی غیرانتفاعی و سرمایه‌گذاری تمام شهریه‌ها'
                  : 'All Revenue Reinvested for Student Excellence'}
              </h3>

              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed max-w-2xl">
                {isPersian
                  ? 'مدرسه تانگلین تراست یک نهاد خیریه و عام‌المنفعه است و هیچ سهام‌دار یا مالکی از فعالیت‌های آن سود مالی دریافت نمی‌کند. تمام وجوه دریافتی از شهریه‌ها، صرف استخدام اساتید ممتاز بین‌المللی و توسعه پردیس می‌شود.'
                  : 'As an established not-for-profit educational foundation, Tanglin operates solely for the benefit of its students. Every dollar is directed into world-class faculty, pastoral programmes, and cutting-edge facilities.'}
              </p>
            </div>

            <div className="lg:col-span-4 flex flex-col gap-3 justify-center items-center lg:items-end">
              <button
                onClick={onOpenBookVisit}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-lg bg-[#C5A85C] hover:bg-[#D4B76B] text-[#0F2537] font-bold text-sm transition-all shadow-lg text-center"
              >
                <Calendar className="w-4 h-4" />
                <span>{isPersian ? 'رزرو تور حضوری پردیس' : 'Book a Campus Visit'}</span>
              </button>

              <button
                onClick={onOpenBookVisit}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-semibold text-sm border border-white/20 transition-all text-center"
              >
                <UserPlus className="w-4 h-4 text-[#C5A85C]" />
                <span>{isPersian ? 'آغاز پیش‌ثبت‌نام آنلاین' : 'Start Application Online'}</span>
              </button>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
