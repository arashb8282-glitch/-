import React from 'react';
import { X, CheckCircle, ArrowLeft, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { sitemapData } from '../data/kheradSitemap';
import { KheradValuesSection } from './KheradValuesSection';
import { useLanguage } from '../context/LanguageContext';

interface KheradSubPageModalProps {
  categoryId: string | null;
  subItemId?: string | null;
  onClose: () => void;
  onOpenApply: () => void;
}

export const KheradSubPageModal: React.FC<KheradSubPageModalProps> = ({
  categoryId,
  subItemId,
  onClose,
  onOpenApply
}) => {
  const { isPersian } = useLanguage();

  if (!categoryId) return null;

  const category = sitemapData.find((c) => c.id === categoryId) || sitemapData[0];
  const activeSubItem = subItemId 
    ? category.subItems.find((s) => s.id === subItemId) || category.subItems[0]
    : category.subItems[0];

  // Pick authentic repository photo based on category
  const getCategoryPhoto = (catId: string, subId?: string) => {
    if (catId.includes('preschool')) return '/assets/photos/infant-school.jpg';
    if (catId.includes('primary') || catId.includes('elementary')) return '/assets/photos/junior-school.jpg';
    if (catId.includes('middle') || catId.includes('high') || catId.includes('vocational')) return '/assets/photos/sixth-form.jpg';
    if (catId.includes('campus')) return '/assets/photos/campus-map.jpg';
    if (subId?.includes('results') || subId?.includes('awards') || catId.includes('honors')) return '/assets/photos/inspections-awards.jpg';
    if (subId?.includes('history')) return '/assets/photos/history.jpg';
    if (subId?.includes('management') || subId?.includes('leadership')) return '/assets/photos/governance.jpg';
    return '/assets/photos/history.jpg';
  };

  const photoUrl = getCategoryPhoto(category.id, activeSubItem?.id);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-6 font-persian" dir={isPersian ? 'rtl' : 'ltr'}>
        {/* Dimmed backdrop with Apple-style soft blur */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 bg-black/40 backdrop-blur-md"
          onClick={onClose}
        />

        {/* Modal Window with Apple continuous curves and hairline stroke */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.96, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 16 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-4xl bg-white rounded-3xl shadow-[0_24px_80px_rgba(0,0,0,0.18)] overflow-hidden flex flex-col max-h-[90vh] border border-black/[0.08] z-10"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Modal Header */}
          <div className="bg-white/90 backdrop-blur-2xl text-slate-900 px-6 sm:px-8 py-5 flex items-center justify-between border-b border-black/[0.06]">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2A6AB2]" />
              <div>
                <span className="text-[10px] text-slate-400 font-mono tracking-wider block">
                  {isPersian ? `منظومه خرد • ${category.englishTitle}` : `Kherad Complex • ${category.englishTitle}`}
                </span>
                <h2 className="text-base sm:text-lg font-bold text-slate-900 font-serif-heading">
                  {isPersian 
                    ? `${category.title} ${activeSubItem ? `— ${activeSubItem.title}` : ''}`
                    : `${category.englishTitle} ${activeSubItem ? `— ${activeSubItem.title}` : ''}`}
                </h2>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-[#F5F5F7] hover:bg-[#EBECEF] text-slate-700 flex items-center justify-center transition-all border border-black/[0.05] cursor-pointer active:scale-95"
              aria-label={isPersian ? 'بستن' : 'Close'}
            >
              <X className="w-4.5 h-4.5 stroke-[1.5]" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6">
            {/* Sub-item Header Banner */}
            <div className="bg-[#F5F5F7] p-6 rounded-3xl border border-black/[0.05] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <span className="text-xs font-semibold text-[#2A6AB2]">
                  {isPersian ? (activeSubItem.category || category.title) : category.englishTitle}
                </span>
                <h3 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif-heading">
                  {activeSubItem.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 font-light">
                  {activeSubItem.description || category.summary}
                </p>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  onClose();
                  onOpenApply();
                }}
                className="bg-[#2A6AB2] hover:bg-[#1976D2] text-white text-xs font-semibold px-5 py-2.5 rounded-full shadow-[0_2px_12px_rgba(42,106,178,0.3)] shrink-0 transition-all cursor-pointer"
              >
                {isPersian ? 'ثبت درخواست و پذیرش' : 'Apply for Admission'}
              </motion.button>
            </div>

            {/* Conditional Display: If Mission & Vision, Render Interactive Kherad Values Section */}
            {(activeSubItem.id === 'mission-vision' || activeSubItem.id === 'mission') ? (
              <div className="rounded-3xl overflow-hidden border border-slate-200">
                <KheradValuesSection showMissionVisionBanner={true} />
              </div>
            ) : (
              <>
                {/* Authentic Campus Photograph from Repository */}
                <div className="rounded-none overflow-hidden bg-slate-900 border border-black/[0.05] relative aspect-video shadow-md">
                  <img
                    src={photoUrl}
                    alt={activeSubItem.title}
                    className="w-full h-full object-cover object-center"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-5">
                    <span className="text-white text-xs sm:text-sm font-medium">
                      {isPersian 
                        ? `مستندات تصویری مجتمع آموزشی خرد: ${category.title} - ${activeSubItem.title}` 
                        : `Campus & Educational Environment: ${category.englishTitle} - ${activeSubItem.title}`}
                    </span>
                  </div>
                </div>

                {/* Detailed Informational Paragraphs */}
                <div className="space-y-4 text-xs sm:text-sm text-slate-600 leading-relaxed font-light">
                  <h4 className="font-bold text-base text-slate-900 border-r-3 border-[#2A6AB2] pr-3 font-serif-heading">
                    {isPersian ? 'شرح اهداف، ساختار و برنامه‌ها در منظومه خرد' : 'Aims, Curriculum & Educational Structure'}
                  </h4>

                  <p>
                    {isPersian 
                      ? `مجتمع آموزشی و فرهنگی منظومه خرد با تکیه بر ۲۵ سال تجربه نوآورانه در مجتمع آموزشی خرد (ولنجک)، فضایی پویا برای رشد همه‌جانبه دانش‌آموزان فراهم آورده است. در بخش ${activeSubItem.title}، هدف اصلی ارتقای سطح خودراهبری، تفکر نقادانه و توانمندسازی افراد بر اساس توان بالقوه فردی است.`
                      : `Kherad Educational Complex, built on 25 years of educational distinction in Velenjak, Tehran, fosters holistic growth for all learners. In ${activeSubItem.title}, our primary aim is cultivating self-direction, inquiry-based thinking, and purposeful personal impact.`}
                  </p>

                  <p>
                    {isPersian 
                      ? 'تمامی فرآیندهای آموزشی این مقطع زیر نظر کارشناسان ارشد روانشناسی تربیتی و اساتید برجسته برنامه‌ریزی درسی بازنگری می‌شوند تا پیوستگی میان سرفصل‌های تئوریک، پژوهش‌های آزمایشگاهی، مهارت‌های زیست‌محیطی و فعالیت‌های هنری به دقیق‌ترین شکل ممکن حفظ گردد.'
                      : 'All learning processes are overseen by educational psychologists and curriculum specialists to ensure deep integration between conceptual theory, laboratory research, environmental awareness, and artistic expression.'}
                  </p>
                </div>
              </>
            )}

            {/* Key Checklist Points in Apple Card */}
            <div className="bg-[#F5F5F7] p-6 rounded-3xl border border-black/[0.05] space-y-3">
              <span className="text-xs font-bold text-slate-900 block mb-1">
                {isPersian ? 'ویژگی‌های شاخص این بخش در منظومه خرد:' : 'Key Hallmarks of this Stage in Kherad:'}
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs text-slate-600 font-light">
                <div className="flex items-start gap-2.5">
                  <CheckCircle className="w-4 h-4 stroke-[1.5] text-[#2A6AB2] shrink-0 mt-0.5" />
                  <span>
                    {isPersian 
                      ? 'بهره‌مندی از اساتید و مربیان دارای صلاحیت‌های تخصصی کشوری' 
                      : 'Distinguished educators with national and international qualifications'}
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle className="w-4 h-4 stroke-[1.5] text-[#2A6AB2] shrink-0 mt-0.5" />
                  <span>
                    {isPersian 
                      ? 'دسترسی به آزمایشگاه‌ها، کتابخانه‌ها و امکانات تخصصی مجتمع آموزشی خرد' 
                      : 'Access to modern STEM labs, ateliers, and central Velenjak facilities'}
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle className="w-4 h-4 stroke-[1.5] text-[#2A6AB2] shrink-0 mt-0.5" />
                  <span>
                    {isPersian 
                      ? 'سنجش مستمر فرآیندی و گزارش‌های مشاوره‌ای تفصیلی برای والدین' 
                      : 'Formative assessment framework with in-depth developmental feedback for parents'}
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle className="w-4 h-4 stroke-[1.5] text-[#2A6AB2] shrink-0 mt-0.5" />
                  <span>
                    {isPersian 
                      ? 'پایبندی کامل به اصول مدرسه سبز و مسئولیت‌پذیری اجتماعی' 
                      : 'Deep commitment to Green School principles and ecological responsibility'}
                  </span>
                </div>
              </div>
            </div>

            {/* Related Items in this Category from Sitemap */}
            <div className="space-y-2 pt-2 border-t border-black/[0.05]">
              <span className="text-xs font-medium text-slate-500 block">
                {isPersian ? `سایر موضوعات مرتبط با ${category.title}:` : `Related Topics in ${category.englishTitle}:`}
              </span>
              <div className="inline-flex flex-wrap gap-1 p-1 sm:p-1.5 bg-[#EBEDF0] rounded-full border border-black/[0.04]">
                {category.subItems.map((sub) => (
                  <span
                    key={sub.id}
                    className={`text-xs px-3.5 py-1.5 rounded-full transition-all ${
                      sub.id === activeSubItem.id
                        ? 'bg-[#1D1D1F] text-white shadow-xs font-medium'
                        : 'text-[#48484A] hover:text-[#1D1D1F]'
                    }`}
                  >
                    {sub.title}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="bg-[#EDEDF0]/70 px-6 sm:px-8 py-4 border-t border-black/[0.06] flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs text-slate-400 font-light">
              {isPersian ? 'پورتال اطلاع‌رسانی مجتمع آموزشی و فرهنگی منظومه خرد' : 'Kherad Educational & Cultural Complex Information Portal'}
            </span>

            <div className="flex items-center gap-2.5">
              <button
                onClick={onClose}
                className="bg-white hover:bg-white/80 text-slate-700 border border-black/[0.06] text-xs font-semibold px-4 py-2 rounded-full transition-colors cursor-pointer"
              >
                {isPersian ? 'بستن' : 'Close'}
              </button>
              <button
                onClick={() => {
                  onClose();
                  onOpenApply();
                }}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-5 py-2 rounded-full transition-all shadow-2xs cursor-pointer"
              >
                {isPersian ? 'درخواست مشاوره و ثبت‌نام' : 'Consultation & Admissions'}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
