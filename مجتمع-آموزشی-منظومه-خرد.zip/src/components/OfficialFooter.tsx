import React from 'react';
import { MapPin, Phone, Mail, ExternalLink, ShieldCheck, ChevronUp } from 'lucide-react';
import { Language } from '../types';

interface OfficialFooterProps {
  lang: Language;
  onOpenEnquiry: () => void;
  onOpenBookVisit: () => void;
}

const accreditationsList = [
  { name: 'Cambridge Assessment International Education', file: '/assets/accreditations/cambridge.png' },
  { name: 'Council of International Schools (CIS)', file: '/assets/accreditations/cis.png' },
  { name: 'Pearson Edexcel', file: '/assets/accreditations/edexcel.png' },
  { name: 'FOBISIA', file: '/assets/accreditations/fobisia.png' },
  { name: 'The Good Schools Guide', file: '/assets/accreditations/goodschoolsguide.jpg' },
  { name: 'HMC', file: '/assets/accreditations/hmc.png' },
  { name: 'International Baccalaureate (IB)', file: '/assets/accreditations/ib.png' },
  { name: 'British Kitemark', file: '/assets/accreditations/kitemark.png' },
  { name: 'COBIS Accredited Member', file: '/assets/accreditations/cobis.jpg' },
  { name: 'British Schools Overseas (BSO)', file: '/assets/accreditations/bso.png' },
  { name: 'Generations of Excellence', file: '/assets/accreditations/goe.svg' }
];

export const OfficialFooter: React.FC<OfficialFooterProps> = ({
  lang,
  onOpenEnquiry,
  onOpenBookVisit
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#001744] text-white">
      {/* 1. Accreditations & Memberships Ribbon */}
      <div className="bg-white py-6 px-4 sm:px-8 border-b border-gray-200">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-4">
            <span className="text-[11px] font-bold uppercase tracking-widest text-gray-500">
              {lang === 'fa' ? 'اعتبارنامه‌ها و عضویت‌های رسمی بین‌المللی' : 'Accreditations, Inspections & Educational Memberships'}
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-8 opacity-90 hover:opacity-100 transition-opacity">
            {accreditationsList.map((acc, idx) => (
              <div key={idx} className="flex items-center justify-center p-1" title={acc.name}>
                <img
                  src={acc.file}
                  alt={acc.name}
                  className="max-h-10 sm:max-h-12 w-auto object-contain grayscale hover:grayscale-0 transition-all duration-200 hover:scale-105"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Main Footer Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Column 1: Brand Logo & Heritage (4 cols on lg) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="space-y-3">
              <img
                src="/assets/logo-white.svg"
                alt="Tanglin Trust School"
                className="h-14 sm:h-16 w-auto object-contain"
                referrerPolicy="no-referrer"
              />
              <p className="text-xs text-slate-300 leading-relaxed pt-2">
                {lang === 'fa'
                  ? 'مدرسه تانگلین تراست، تاسیس شده در ۱۹۲۵، با یک قرن تجربه درخشان در ارائه آموزش با کیفیت بین‌المللی بریتانیایی در سنگاپور.'
                  : 'Tanglin Trust School, established in 1925, is Southeast Asia’s oldest British international school, offering dual pathway A Level & IB Diploma.'}
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <img
                src="/assets/accreditations/goe.svg"
                alt="Generations of Excellence 1925-2025"
                className="h-10 w-auto object-contain opacity-90"
                referrerPolicy="no-referrer"
              />
              <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                100 Years of Heritage
              </span>
            </div>
          </div>

          {/* Column 2: Contact Details (4 cols on lg) */}
          <div className="lg:col-span-4 space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-[#002169] pb-2">
              {lang === 'fa' ? 'اطلاعات تماس و نشانی' : 'Campus Location & Contact'}
            </h3>

            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#CE0E2D] shrink-0 mt-0.5" />
                <span>
                  <strong>Tanglin Trust School</strong><br />
                  95 Portsdown Road, Singapore 139299
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#CE0E2D] shrink-0" />
                <span>Main Reception: +65 6778 0771</span>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#CE0E2D] shrink-0" />
                <span>Admissions: +65 6770 3583 / 3480 / 3535</span>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#CE0E2D] shrink-0" />
                <span>admissions@tts.edu.sg</span>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={onOpenBookVisit}
                className="text-xs font-bold text-white bg-[#002169] hover:bg-[#002d8a] px-3 py-1.5 rounded transition-colors"
              >
                {lang === 'fa' ? 'رزرو تور پردیس' : 'Book a Campus Visit'}
              </button>
              <button
                onClick={onOpenEnquiry}
                className="text-xs font-bold text-white bg-[#CE0E2D] hover:bg-[#b00b25] px-3 py-1.5 rounded transition-colors"
              >
                {lang === 'fa' ? 'فرم استعلام' : 'Make an Enquiry'}
              </button>
            </div>
          </div>

          {/* Column 3: Quick Portal Links (4 cols on lg) */}
          <div className="lg:col-span-4 space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-[#002169] pb-2">
              {lang === 'fa' ? 'پیوندهای سازمانی و پرتال‌ها' : 'School Policies & Portals'}
            </h3>

            <ul className="space-y-1.5 text-xs text-slate-300">
              <li>
                <a href="https://alumni.tts.edu.sg/" target="_blank" rel="noreferrer" className="hover:text-[#CE0E2D] transition-colors inline-flex items-center gap-1">
                  <span>{lang === 'fa' ? 'شبکه فارغ‌التحصیلان تانگلین' : 'Tanglin Alumni Network'}</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </li>
              <li>
                <a href="https://directory.tts.edu.sg/" target="_blank" rel="noreferrer" className="hover:text-[#CE0E2D] transition-colors inline-flex items-center gap-1">
                  <span>{lang === 'fa' ? 'راهنمای همکاران و اساتید' : 'Staff Directory'}</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </li>
              <li>
                <a href="#policies" onClick={(e) => { e.preventDefault(); onOpenEnquiry(); }} className="hover:text-white transition-colors">
                  {lang === 'fa' ? 'قوانین و استانداردهای حفاظتی مدرسه' : 'School Policies & Safeguarding'}
                </a>
              </li>
              <li>
                <a href="#fees" onClick={(e) => { e.preventDefault(); onOpenEnquiry(); }} className="hover:text-white transition-colors">
                  {lang === 'fa' ? 'جدول شهریه و هزینه‌های تحصیلی' : 'School Fees & Transparent Structure'}
                </a>
              </li>
              <li>
                <a href="#termdates" onClick={(e) => { e.preventDefault(); onOpenEnquiry(); }} className="hover:text-white transition-colors">
                  {lang === 'fa' ? 'تقویم ترم‌ها و روزهای تحصیلی' : 'Term Dates & Academic Calendar'}
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* 3. Bottom Legal & Copyright Bar */}
      <div className="bg-[#000e2b] py-4 px-4 sm:px-8 border-t border-[#001744] text-[11px] text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <span>© Tanglin Trust School. All Rights Reserved. CPE Registration No. 196100114C (Period: 7 June 2023 to 6 June 2029)</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="hidden sm:inline">Tanglin Trust Ltd is a registered charity in Singapore</span>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1 text-slate-300 hover:text-white transition-colors p-1"
              title="بازگشت به ابتدای صفحه / Back to top"
            >
              <span>{lang === 'fa' ? 'بالای صفحه' : 'Back to Top'}</span>
              <ChevronUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
