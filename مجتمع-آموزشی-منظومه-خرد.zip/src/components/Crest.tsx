import React from 'react';

interface CrestProps {
  className?: string;
  variant?: 'light' | 'dark' | 'gold';
  showText?: boolean;
  lang?: 'en' | 'fa';
}

export const Crest: React.FC<CrestProps> = ({
  className = 'w-12 h-12',
  variant = 'dark',
  showText = true,
  lang = 'en'
}) => {
  const primaryColor = variant === 'light' ? '#FFFFFF' : variant === 'gold' ? '#D4AF37' : '#0F2537';
  const accentColor = variant === 'light' ? '#E2E8F0' : '#C5A85C';
  const textColor = variant === 'light' ? 'text-white' : 'text-[#0F2537]';
  const subTextColor = variant === 'light' ? 'text-slate-300' : 'text-[#C5A85C]';

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* SVG Crest */}
      <svg
        viewBox="0 0 100 110"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-12 h-14 shrink-0 transition-transform duration-300 hover:scale-105"
        aria-label="Tanglin Trust School Crest"
      >
        {/* Shield Outer Border */}
        <path
          d="M50 4C75 4 94 15 94 36C94 74 50 104 50 104C50 104 6 74 6 36C6 15 25 4 50 4Z"
          fill={variant === 'light' ? '#0F2537' : '#FFFFFF'}
          stroke={accentColor}
          strokeWidth="3.5"
          strokeLinejoin="round"
        />

        {/* Shield Inner Inset */}
        <path
          d="M50 10C70 10 88 19 88 36C88 69 50 96 50 96C50 96 12 69 12 36C12 19 30 10 50 10Z"
          fill={variant === 'light' ? '#162E4A' : '#0F2537'}
        />

        {/* Shield Cross / Quarter Divisions */}
        <line x1="50" y1="12" x2="50" y2="92" stroke={accentColor} strokeWidth="2.5" opacity="0.8" />
        <line x1="14" y1="46" x2="86" y2="46" stroke={accentColor} strokeWidth="2.5" opacity="0.8" />

        {/* Top-Left: Heraldic Lion */}
        <path
          d="M26 26C28 23 33 23 35 26C37 28 35 32 37 36C35 37 32 38 30 36C29 39 25 39 25 36C27 34 24 30 26 26Z"
          fill={accentColor}
        />
        <circle cx="31" cy="27" r="1.5" fill="#0F2537" />

        {/* Top-Right: Open Academic Book */}
        <path
          d="M62 26C66 24 73 24 77 26V36C73 34 66 34 62 36V26Z"
          stroke={accentColor}
          strokeWidth="1.5"
          fill="none"
        />
        <line x1="70" y1="26" x2="70" y2="36" stroke={accentColor} strokeWidth="1.2" />

        {/* Bottom-Left: Palm / Southern Star */}
        <path
          d="M31 58L33 65L40 65L34 69L36 76L31 72L26 76L28 69L22 65L29 65Z"
          fill={accentColor}
        />

        {/* Bottom-Right: Torch of Wisdom */}
        <path
          d="M66 76L74 76L71 66L69 66Z"
          fill={accentColor}
        />
        <path
          d="M70 58C67 61 73 63 70 66C72 63 68 60 70 58Z"
          fill="#E2B755"
        />

        {/* Central Escutcheon / Centenary Star */}
        <circle cx="50" cy="46" r="6" fill={variant === 'light' ? '#FFFFFF' : '#0F2537'} stroke={accentColor} strokeWidth="2" />
        <circle cx="50" cy="46" r="2.5" fill={accentColor} />
      </svg>

      {/* School Name & Motto */}
      {showText && (
        <div className="flex flex-col justify-center text-left">
          <div className="flex items-center gap-2">
            <span className={`text-base sm:text-lg font-extrabold tracking-wider uppercase font-serif-heading leading-tight ${textColor}`}>
              TANGLIN TRUST
            </span>
            <span className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-bold tracking-widest uppercase rounded bg-[#C5A85C]/20 text-[#C5A85C] border border-[#C5A85C]/40">
              EST. 1925
            </span>
          </div>
          <span className={`text-xs font-semibold tracking-widest uppercase ${textColor}`}>
            SCHOOL • SINGAPORE
          </span>
          <span className={`text-[10px] font-medium tracking-wider uppercase ${subTextColor}`}>
            {lang === 'fa' ? 'یک قرن تعالی آموزشی (۱۹۲۵–۲۰۲۵)' : 'Generations of Excellence • Centenary'}
          </span>
        </div>
      )}
    </div>
  );
};
