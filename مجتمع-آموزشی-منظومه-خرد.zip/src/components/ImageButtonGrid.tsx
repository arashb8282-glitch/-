import React from 'react';
import { ArrowRight } from 'lucide-react';
import { featureCardsData } from '../data/tanglinMainPageData';
import { Language } from '../types';

interface ImageButtonGridProps {
  lang: Language;
  onSelectCard: (id: string) => void;
}

export const ImageButtonGrid: React.FC<ImageButtonGridProps> = ({ lang, onSelectCard }) => {
  return (
    <section className="w-full bg-[#001744] py-12 md:py-16 px-4 sm:px-8 border-b border-slate-800">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-8 md:mb-12 text-center max-w-3xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-widest text-[#f0b0bd] bg-white/10 px-3 py-1 rounded inline-block mb-3">
            {lang === 'fa' ? 'کاوش در ارکان تانگلین' : 'Key Pillars of Tanglin Trust School'}
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif-heading font-bold text-white tracking-tight">
            {lang === 'fa' ? 'شناخت عمیق‌تر مدرسه تانگلین' : 'Explore About Tanglin'}
          </h2>
          <p className="mt-2 text-slate-300 text-sm sm:text-base">
            {lang === 'fa' 
              ? 'برای مشاهده جزئیات ماموریت، تاریخچه، نتایج آزمون‌ها، ارزیابی‌ها، نقشه پردیس و ارکان مدیریتی بر روی هر بخش کلیک کنید.' 
              : 'Discover our century of heritage, holistic values, world-beating exam achievements, campus architecture and governance.'}
          </p>
        </div>

        {/* 6 Cards Grid (Exact 3-column / 2-column layout on desktop) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {featureCardsData.map((card) => (
            <div
              key={card.id}
              onClick={() => onSelectCard(card.id)}
              className="group relative h-[360px] sm:h-[390px] rounded-lg overflow-hidden cursor-pointer shadow-xl transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl border border-white/10 flex flex-col justify-end p-6 sm:p-7 text-white"
            >
              {/* Background Photo */}
              <img
                src={card.image}
                alt={card.titleEn}
                className="absolute inset-0 w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-108"
                referrerPolicy="no-referrer"
                loading="lazy"
              />

              {/* Multi-layered dark overlay for high contrast and readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#001744] via-[#001744]/75 to-black/35 transition-opacity group-hover:opacity-90" />

              {/* Tanglin Crimson Accent Top Strip on Hover */}
              <div className="absolute top-0 inset-x-0 h-1.5 bg-[#CE0E2D] opacity-0 group-hover:opacity-100 transition-opacity" />

              {/* Card Content */}
              <div className="relative z-10 space-y-3">
                <h3 className="text-lg sm:text-xl font-bold tracking-tight text-white group-hover:text-[#f8b4c0] transition-colors leading-snug">
                  {lang === 'fa' ? card.titleFa : card.titleEn}
                </h3>

                <p className="text-slate-200 text-xs sm:text-[13px] leading-relaxed line-clamp-3">
                  {lang === 'fa' ? card.summaryFa : card.summaryEn}
                </p>

                <div className="pt-2">
                  <span className="inline-flex items-center gap-2 bg-[#CE0E2D] group-hover:bg-[#b00b25] text-white text-[12px] font-bold px-4 py-2 rounded transition-all duration-200 shadow-md">
                    <span>{lang === 'fa' ? card.buttonTextFa : card.buttonTextEn}</span>
                    <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
