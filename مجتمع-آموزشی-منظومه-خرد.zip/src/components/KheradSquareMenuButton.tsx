import React from 'react';
import { motion } from 'motion/react';
import { X } from 'lucide-react';

interface KheradSquareMenuButtonProps {
  onClick: () => void;
  isOpen?: boolean;
}

export const KheradSquareMenuButton: React.FC<KheradSquareMenuButtonProps> = ({
  onClick,
  isOpen = false
}) => {
  return (
    <motion.button
      initial="initial"
      whileHover="hover"
      whileTap={{ scale: 0.92 }}
      onClick={onClick}
      aria-label={isOpen ? "بستن منوی کامل سایت" : "باز کردن منوی کامل سایت"}
      title={isOpen ? "بستن منو" : "منوی ناوبری و نقشه سایت"}
      className="fixed top-0 right-0 z-40 w-12 sm:w-14 h-11 sm:h-12 flex flex-col items-center justify-center cursor-pointer select-none rounded-none focus:outline-none bg-slate-900/5 hover:bg-slate-900/10 text-slate-800 border-none shadow-none group transition-colors"
    >
      {/* If open, show close icon with 90deg spring rotation on hover */}
      {isOpen ? (
        <motion.div
          variants={{
            hover: { rotate: 90, scale: 1.15 }
          }}
          transition={{ type: 'spring', stiffness: 360, damping: 20 }}
          className="text-slate-900"
        >
          <X className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.4]" />
        </motion.div>
      ) : (
        /* 3-line hamburger menu - All 3 lines strictly equal width, motion ONLY on hover */
        <div className="flex flex-col items-center justify-center gap-1.5 w-6 sm:w-7">
          {/* Top Line */}
          <motion.span 
            variants={{
              initial: { x: 0 },
              hover: { x: -2.5 }
            }}
            transition={{ type: 'spring', stiffness: 380, damping: 22 }}
            className="w-full h-[2.5px] sm:h-[3px] bg-slate-800 rounded-full block group-hover:bg-[#0b82c6] transition-colors" 
          />
          {/* Middle Line - Exactly equal width */}
          <motion.span 
            variants={{
              initial: { x: 0 },
              hover: { x: 2 }
            }}
            transition={{ type: 'spring', stiffness: 380, damping: 22 }}
            className="w-full h-[2.5px] sm:h-[3px] bg-slate-800 rounded-full block group-hover:bg-[#0b82c6] transition-colors" 
          />
          {/* Bottom Line - Exactly equal width */}
          <motion.span 
            variants={{
              initial: { x: 0 },
              hover: { x: -2.5 }
            }}
            transition={{ type: 'spring', stiffness: 380, damping: 22 }}
            className="w-full h-[2.5px] sm:h-[3px] bg-slate-800 rounded-full block group-hover:bg-[#0b82c6] transition-colors" 
          />
        </div>
      )}
    </motion.button>
  );
};
