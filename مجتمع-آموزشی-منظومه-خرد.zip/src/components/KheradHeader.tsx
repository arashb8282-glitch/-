import React from 'react';
import { useLanguage } from '../context/LanguageContext';

interface KheradHeaderProps {
  onOpenRightDrawer: () => void;
  onOpenSearch: () => void;
  onOpenApply: () => void;
  onOpenTour: () => void;
  onSelectCategory: (categoryId: string, subItemId?: string) => void;
}

export const KheradHeader: React.FC<KheradHeaderProps> = ({
  onOpenApply,
  onOpenTour,
  onSelectCategory
}) => {
  const { lang, toggleLanguage, t } = useLanguage();
  const isPersian = lang === 'fa';

  return (
    <header className="relative z-30 font-persian select-none" dir={isPersian ? 'rtl' : 'ltr'}>
      {/* 
        Sticky Quick Action Column on left screen edge:
        Light gray background (#f5f5f7), black icons turning into corporate blue (#0b82c6) on hover,
        without stroke and without shadow.
      */}
      <div 
        id="kherad-floating-actions"
        className="fixed left-0 top-1/2 -translate-y-1/2 z-40 flex flex-col shadow-none rounded-none bg-[#f5f5f7] border-none select-none"
      >
        {/* Button 1: Info */}
        <button
          onClick={() => onSelectCategory('about', 'about-kherad')}
          className="relative group w-14 h-14 sm:w-16 sm:h-16 bg-[#f5f5f7] hover:bg-[#ebecee] text-slate-800 hover:text-[#0b82c6] flex items-center justify-center transition-colors duration-200 cursor-pointer focus:outline-none rounded-none border-none shadow-none"
          aria-label={t.nav.about}
          title={t.nav.about}
        >
          <svg 
            className="w-5.5 h-5.5 sm:w-6 sm:h-6 text-current group-hover:scale-105 transition-all duration-200" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="1.3" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <circle cx="12" cy="12" r="9.5" />
            <circle cx="12" cy="7.75" r="0.8" fill="currentColor" stroke="none" />
            <line x1="12" y1="11.2" x2="12" y2="16.5" />
          </svg>
        </button>

        {/* Button 2: 360° Virtual Campus Tour */}
        <button
          onClick={onOpenTour}
          className="relative group w-14 h-14 sm:w-16 sm:h-16 bg-[#f5f5f7] hover:bg-[#ebecee] text-slate-800 hover:text-[#0b82c6] flex items-center justify-center transition-colors duration-200 cursor-pointer focus:outline-none rounded-none border-none shadow-none"
          aria-label={t.nav.campusTour}
          title={t.nav.campusTour}
        >
          <svg 
            className="w-5.5 h-5.5 sm:w-6 sm:h-6 text-current group-hover:scale-105 transition-all duration-200" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="1.4" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            {/* Simple clean circular arrow */}
            <path d="M21 12A9 9 0 1 1 18.2 5.5L21 8" />
            <polyline points="21 3 21 8 16 8" />
            {/* Simple clear 360 label */}
            <text 
              x="11.5" 
              y="13" 
              textAnchor="middle" 
              dominantBaseline="middle" 
              fontSize="5" 
              fontWeight="700" 
              fill="currentColor" 
              stroke="none" 
              fontFamily="sans-serif"
              letterSpacing="-0.2"
            >
              360
            </text>
          </svg>
        </button>

        {/* Button 3: Online Admissions */}
        <button
          onClick={onOpenApply}
          className="relative group w-14 h-14 sm:w-16 sm:h-16 bg-[#f5f5f7] hover:bg-[#ebecee] text-slate-800 hover:text-[#0b82c6] flex items-center justify-center transition-colors duration-200 cursor-pointer focus:outline-none rounded-none border-none shadow-none"
          aria-label={t.nav.admissions}
          title={t.nav.admissions}
        >
          <svg 
            className="w-5.5 h-5.5 sm:w-6 sm:h-6 text-current group-hover:scale-105 transition-all duration-200" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="1.3" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" />
            <line x1="8" y1="13" x2="16" y2="13" strokeWidth="1.2" />
            <line x1="8" y1="17" x2="12.5" y2="17" strokeWidth="1.2" />
          </svg>
        </button>

        {/* Button 4: Language Switcher */}
        <button
          onClick={toggleLanguage}
          className="relative group w-14 h-14 sm:w-16 sm:h-16 bg-[#f5f5f7] hover:bg-[#ebecee] text-slate-800 hover:text-[#0b82c6] flex items-center justify-center transition-colors duration-200 cursor-pointer focus:outline-none rounded-none border-none shadow-none"
          aria-label={isPersian ? 'Switch to English' : 'تغییر به زبان فارسی'}
          title={isPersian ? 'English Version' : 'نسخه فارسی'}
        >
          <span className="text-[13px] sm:text-[14px] font-bold font-sans tracking-wider text-current group-hover:scale-105 transition-all duration-200 select-none">
            {isPersian ? 'EN' : 'فا'}
          </span>
        </button>
      </div>
    </header>
  );
};
