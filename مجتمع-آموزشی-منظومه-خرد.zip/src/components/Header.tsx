import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Menu, 
  X, 
  ChevronDown, 
  Globe, 
  ExternalLink,
  ChevronRight,
  Mail,
  Users
} from 'lucide-react';
import { Language } from '../types';

interface HeaderProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenSearch: () => void;
  onOpenTour: () => void;
  onOpenBookVisit: () => void;
  onOpenEnquiry: () => void;
  onOpenApply: () => void;
  onSelectSection: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onLanguageChange,
  onOpenSearch,
  onOpenTour,
  onOpenBookVisit,
  onOpenEnquiry,
  onOpenApply,
  onSelectSection
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.dropdown-container')) {
        setActiveDropdown(null);
      }
    };
    document.addEventListener('click', handleOutsideClick);
    return () => document.removeEventListener('click', handleOutsideClick);
  }, []);

  const navMenuItems = [
    {
      id: 'about',
      labelEn: 'ABOUT TANGLIN',
      labelFa: 'درباره تانگلین',
      isCurrent: true,
      subLinks: [
        { id: 'about-main', titleEn: 'About Tanglin', titleFa: 'درباره تانگلین (صفحه اصلی)' },
        { id: 'mission', titleEn: 'Mission & Vision', titleFa: 'ماموریت و چشم‌انداز' },
        { id: 'history', titleEn: 'History of the School', titleFa: 'تاریخچه مدرسه' },
        { id: 'academics', titleEn: 'Academic Results', titleFa: 'نتایج تحصیلی' },
        { id: 'inspections', titleEn: 'Inspections & Awards', titleFa: 'ارزیابی‌ها و افتخارات' },
        { id: 'campus', titleEn: 'Interactive Campus Map', titleFa: 'نقشه تعاملی پردیس' },
        { id: 'governance', titleEn: 'Governance', titleFa: 'ارکان مدیریت و امنا' }
      ]
    },
    {
      id: 'admissions',
      labelEn: 'ADMISSIONS',
      labelFa: 'پذیرش و ثبت‌نام',
      isCurrent: false,
      subLinks: [
        { id: 'apply', titleEn: 'How to Apply', titleFa: 'مراحل ثبت‌نام' },
        { id: 'visit', titleEn: 'Visit Tanglin', titleFa: 'بازدید از تانگلین' },
        { id: 'enquiry', titleEn: 'Admissions Enquiry', titleFa: 'پرسش و مشاوره پذیرش' },
        { id: 'fees', titleEn: 'School Fees', titleFa: 'شهریه و هزینه‌ها' }
      ]
    },
    {
      id: 'infant',
      labelEn: 'INFANT (AGE 3-7)',
      labelFa: 'خردسالان (۳ تا ۷ سال)',
      isCurrent: false,
      subLinks: [
        { id: 'infant', titleEn: 'Infant School Overview', titleFa: 'معرفی مدرسه خردسال' },
        { id: 'infant-curriculum', titleEn: 'Early Years Curriculum', titleFa: 'برنامه درسی پیش‌دبستانی' }
      ]
    },
    {
      id: 'junior',
      labelEn: 'JUNIOR (AGE 7-11)',
      labelFa: 'دبستان (۷ تا ۱۱ سال)',
      isCurrent: false,
      subLinks: [
        { id: 'junior', titleEn: 'Junior School Overview', titleFa: 'معرفی دوره دبستان' },
        { id: 'junior-arts', titleEn: 'Junior Arts Centre', titleFa: 'مرکز تخصصی هنر کودک' }
      ]
    },
    {
      id: 'middle',
      labelEn: 'MIDDLE (AGE 11-14)',
      labelFa: 'متوسطه اول (۱۱ تا ۱۴ سال)',
      isCurrent: false,
      subLinks: [
        { id: 'middle-curriculum', titleEn: 'Key Stage 3 Curriculum', titleFa: 'برنامه درسی مقطع سوم' },
        { id: 'highlands', titleEn: 'The Highlands Programme', titleFa: 'برنامه پژوهشی هایلندز' }
      ]
    },
    {
      id: 'upper',
      labelEn: 'UPPER (AGE 14-16)',
      labelFa: 'متوسطه دوم (۱۴ تا ۱۶ سال)',
      isCurrent: false,
      subLinks: [
        { id: 'igcse', titleEn: '(I)GCSE Curriculum', titleFa: 'دوره بین‌المللی GCSE' },
        { id: 'careers', titleEn: 'Careers & Counselling', titleFa: 'مشاوره شغلی و تحصیلی' }
      ]
    },
    {
      id: 'sixth-form',
      labelEn: '6TH FORM (AGE 16-18)',
      labelFa: 'سال ششم و کالج (۱۶ تا ۱۸ سال)',
      isCurrent: false,
      subLinks: [
        { id: 'sixth-form', titleEn: 'Sixth Form Overview', titleFa: 'معرفی دوره سال ششم' },
        { id: 'dual-pathway', titleEn: 'Dual Pathway (A Level & IB)', titleFa: 'مسیر دوگانه A-Level و دیپلم IB' }
      ]
    },
    {
      id: 'school-life',
      labelEn: 'SCHOOL LIFE',
      labelFa: 'زندگی در مدرسه',
      isCurrent: false,
      subLinks: [
        { id: 'term-dates', titleEn: 'Term Dates & Calendar', titleFa: 'تقویم ترم‌های تحصیلی' },
        { id: 'co-curricular', titleEn: 'Sports & Arts Co-curriculum', titleFa: 'ورزش و هنر فوق برنامه' }
      ]
    },
    {
      id: 'news-events',
      labelEn: 'NEWS & EVENTS',
      labelFa: 'اخبار و رویدادها',
      isCurrent: false,
      subLinks: [
        { id: 'latest-news', titleEn: 'Centenary News', titleFa: 'اخبار صدمین سالگرد' },
        { id: 'the-voice', titleEn: 'The Voice Magazine', titleFa: 'مجله اختصاصی دِ وویس' }
      ]
    }
  ];

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-white shadow-sm transition-all duration-200">
        {/* Top Dark Utility Bar (Authentic Tanglin Navy) */}
        <div className="bg-[#001744] text-white py-1.5 px-4 sm:px-8 text-xs font-normal border-b border-[#002169]">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4 sm:gap-6 text-slate-300">
              <a 
                href="https://alumni.tts.edu.sg/" 
                target="_blank" 
                rel="noreferrer" 
                className="hover:text-white transition-colors flex items-center gap-1 font-medium"
              >
                <span>{lang === 'fa' ? 'فارغ‌التحصیلان تانگلین' : 'Alumni'}</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>
              <span className="text-slate-600 hidden sm:inline">|</span>
              <a 
                href="https://directory.tts.edu.sg/" 
                target="_blank" 
                rel="noreferrer" 
                className="hover:text-white transition-colors hidden sm:flex items-center gap-1 font-medium"
              >
                <Users className="w-3 h-3 text-[#CE0E2D]" />
                <span>{lang === 'fa' ? 'راهنمای کادر و اساتید' : 'Staff Directory'}</span>
              </a>
              <span className="text-slate-600 hidden md:inline">|</span>
              <a 
                href="https://outlook.office365.com/mail/" 
                target="_blank" 
                rel="noreferrer" 
                className="hover:text-white transition-colors hidden md:flex items-center gap-1 font-medium"
              >
                <Mail className="w-3 h-3 text-[#CE0E2D]" />
                <span>{lang === 'fa' ? 'ایمیل دانش‌آموزان و اساتید' : 'Staff & Student Email'}</span>
              </a>
            </div>

            <div className="flex items-center gap-4">
              {/* Language Switcher */}
              <button
                onClick={() => onLanguageChange(lang === 'en' ? 'fa' : 'en')}
                className="flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition-colors border border-white/15"
                title="تغییر زبان به فارسی / Switch to English"
              >
                <Globe className="w-3.5 h-3.5 text-[#CE0E2D]" />
                <span>{lang === 'en' ? 'فارسی' : 'English'}</span>
              </button>

              {/* Search Trigger */}
              <button
                onClick={onOpenSearch}
                className="p-1 hover:text-[#CE0E2D] transition-colors"
                title={lang === 'fa' ? 'جستجو در سایت' : 'Search Website'}
              >
                <Search className="w-4 h-4" />
              </button>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-1 text-white hover:text-[#CE0E2D] transition-colors"
                aria-label="Toggle Menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Main Brand Bar */}
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3.5 flex items-center justify-between">
            {/* Authentic Kherad Official Vector Logo */}
            <a 
              href="#top" 
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center p-0 m-0 bg-transparent shrink-0 group focus:outline-none"
              title={lang === 'fa' ? 'مجتمع آموزشی و فرهنگی دخترانه منظومه خرد' : 'Manzoomeh Kherad Educational Complex'}
            >
              <img 
                src="/assets/logo.svg" 
                alt={lang === 'fa' ? 'مجتمع آموزشی و فرهنگی دخترانه منظومه خرد' : 'Manzoomeh Kherad Educational Complex'} 
                className="h-12 sm:h-16 md:h-20 w-auto object-contain p-0 m-0 bg-transparent transform scale-110 sm:scale-125 md:scale-135 origin-left transition-transform duration-200 group-hover:opacity-95"
                referrerPolicy="no-referrer"
              />
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
              {navMenuItems.map((item) => (
                <div key={item.id} className="relative dropdown-container group">
                  <button
                    onClick={() => {
                      if (item.isCurrent) {
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      } else {
                        setActiveDropdown(activeDropdown === item.id ? null : item.id);
                      }
                    }}
                    className={`px-2.5 py-2 text-[13px] font-bold tracking-tight transition-all duration-150 inline-flex items-center gap-1 rounded-sm ${
                      item.isCurrent
                        ? 'text-[#002169] border-b-2 border-[#CE0E2D] pb-1.5'
                        : 'text-gray-800 hover:text-[#002169] hover:bg-gray-50'
                    }`}
                  >
                    <span>{lang === 'fa' ? item.labelFa : item.labelEn}</span>
                    {item.subLinks.length > 0 && (
                      <ChevronDown className="w-3 h-3 opacity-60 transition-transform group-hover:rotate-180" />
                    )}
                  </button>

                  {/* Dropdown Menu on Hover / Click */}
                  {item.subLinks.length > 0 && (
                    <div className="absolute left-0 top-full hidden group-hover:block pt-1 z-50 min-w-[240px]">
                      <div className="bg-white rounded shadow-xl border border-gray-100 py-2">
                        {item.subLinks.map((sub) => (
                          <button
                            key={sub.id}
                            onClick={() => {
                              if (sub.id === 'about-main') {
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                              } else if (sub.id === 'apply') {
                                onOpenApply();
                              } else if (sub.id === 'visit') {
                                onOpenBookVisit();
                              } else if (sub.id === 'enquiry') {
                                onOpenEnquiry();
                              } else {
                                onSelectSection(sub.id);
                              }
                            }}
                            className="w-full text-left px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-[#F4F6F8] hover:text-[#CE0E2D] transition-colors flex items-center justify-between"
                          >
                            <span>{lang === 'fa' ? sub.titleFa : sub.titleEn}</span>
                            <ChevronRight className="w-3 h-3 opacity-40" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </nav>
          </div>
        </div>

        {/* Authentic Breadcrumb Bar */}
        <div className="bg-[#F8F9FA] border-b border-gray-200 py-2 px-4 sm:px-8 text-xs text-gray-600">
          <div className="max-w-7xl mx-auto flex items-center gap-2">
            <a href="#top" className="hover:text-[#002169] transition-colors font-medium">
              {lang === 'fa' ? 'خانه' : 'Home'}
            </a>
            <span className="text-gray-400">&gt;</span>
            <span className="font-semibold text-gray-800">
              {lang === 'fa' ? 'درباره تانگلین' : 'ABOUT TANGLIN'}
            </span>
            <span className="text-gray-400">&gt;</span>
            <span className="text-[#CE0E2D] font-bold">
              {lang === 'fa' ? 'درباره تانگلین (معرفی اصلی)' : 'About Tanglin'}
            </span>
          </div>
        </div>

        {/* Mobile Dropdown Menu Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-b border-gray-200 px-4 py-4 max-h-[80vh] overflow-y-auto shadow-2xl">
            <div className="space-y-3">
              {navMenuItems.map((item) => (
                <div key={item.id} className="border-b border-gray-100 pb-2">
                  <div className="flex items-center justify-between py-1">
                    <span className={`text-sm font-bold ${item.isCurrent ? 'text-[#002169]' : 'text-gray-800'}`}>
                      {lang === 'fa' ? item.labelFa : item.labelEn}
                    </span>
                  </div>
                  <div className="pl-3 mt-1 space-y-1">
                    {item.subLinks.map((sub) => (
                      <button
                        key={sub.id}
                        onClick={() => {
                          setMobileMenuOpen(false);
                          if (sub.id === 'about-main') {
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          } else if (sub.id === 'apply') {
                            onOpenApply();
                          } else if (sub.id === 'visit') {
                            onOpenBookVisit();
                          } else if (sub.id === 'enquiry') {
                            onOpenEnquiry();
                          } else {
                            onSelectSection(sub.id);
                          }
                        }}
                        className="block w-full text-left py-1 text-xs text-gray-600 hover:text-[#CE0E2D]"
                      >
                        {lang === 'fa' ? sub.titleFa : sub.titleEn}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Floating Sticky CTA Buttons (Right Side of Viewport - As on official tts.edu.sg) */}
      <aside 
        className="fixed right-0 top-1/2 -translate-y-1/2 z-30 flex flex-col items-end gap-1 pointer-events-auto"
        aria-label="Quick Actions"
      >
        <button
          onClick={onOpenEnquiry}
          className="group flex items-center bg-[#CE0E2D] hover:bg-[#b00b25] text-white px-3 py-2.5 rounded-l shadow-md transition-all duration-200 text-xs font-bold tracking-wider uppercase hover:pr-4"
          title={lang === 'fa' ? 'فرم درخواست اطلاعات و مشاوره' : 'Make an Admissions Enquiry'}
        >
          <span>{lang === 'fa' ? 'مشاوره' : 'Enquiry'}</span>
        </button>

        <button
          onClick={onOpenBookVisit}
          className="group flex items-center bg-[#002169] hover:bg-[#001744] text-white px-3 py-2.5 rounded-l shadow-md transition-all duration-200 text-xs font-bold tracking-wider uppercase hover:pr-4"
          title={lang === 'fa' ? 'رزرو تور حضوری پردیس' : 'Book a Campus Visit'}
        >
          <span>{lang === 'fa' ? 'بازدید' : 'Visit'}</span>
        </button>

        <button
          onClick={onOpenApply}
          className="group flex items-center bg-[#001744] hover:bg-[#000e2b] text-white px-3 py-2.5 rounded-l shadow-md transition-all duration-200 text-xs font-bold tracking-wider uppercase hover:pr-4"
          title={lang === 'fa' ? 'ثبت‌نام آنلاین در تانگلین' : 'Apply for Admission'}
        >
          <span>{lang === 'fa' ? 'ثبت‌نام' : 'Apply'}</span>
        </button>
      </aside>
    </>
  );
};
