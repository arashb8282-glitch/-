import React, { useState } from 'react';
import { campusFacilities } from '../data/tanglinData';
import { Language, CampusFacility } from '../types';
import { 
  Compass, 
  MapPin, 
  Check, 
  Sparkles, 
  Layers, 
  ExternalLink,
  Waves,
  Building2,
  Tv,
  Microscope,
  Dumbbell
} from 'lucide-react';

interface CampusTourProps {
  lang: Language;
  onOpenVirtualTour: () => void;
  onOpenBookVisit: () => void;
}

export const CampusTour: React.FC<CampusTourProps> = ({
  lang,
  onOpenVirtualTour,
  onOpenBookVisit
}) => {
  const isPersian = lang === 'fa';
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeFacility, setActiveFacility] = useState<CampusFacility>(campusFacilities[0]);

  const categories = ['All', 'Sports', 'Arts', 'Academic'];

  const filteredFacilities = selectedCategory === 'All'
    ? campusFacilities
    : campusFacilities.filter(f => f.category === selectedCategory);

  return (
    <section id="campus" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0F2537]/5 text-[#0F2537] text-xs font-bold uppercase tracking-widest mb-3">
              <MapPin className="w-3.5 h-3.5 text-[#C5A85C]" />
              <span>Portsdown Road, One-North, Singapore</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold font-serif-heading text-[#0F2537]">
              {isPersian ? 'پردیس و امکانات کلاس جهانی تانگلین' : 'Campus & World-Class Facilities'}
            </h2>
            <p className="mt-2 text-slate-600 text-sm sm:text-base max-w-2xl">
              {isPersian
                ? 'پردیسی سرسبز در منطقه نوآوری سنگاپور شامل ساختمان ۱۱ طبقه صدمین سالگرد، استخر المپیک ۵۰ متری، تالار تئاتر ۴۰۰ نفره و بیست آزمایشگاه فوق‌پیشرفته.'
                : 'Set in Singapore’s vibrant One-North knowledge district, our campus combines lush natural spaces with cutting-edge academic, athletic, and performing arts centers.'}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenVirtualTour}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#0F2537] text-white hover:bg-[#162E4A] font-bold text-xs sm:text-sm shadow-md transition-all"
            >
              <Compass className="w-4 h-4 text-[#C5A85C]" />
              <span>{isPersian ? 'ورود به تور مجازی ۳۶۰°' : '360° Virtual Tour'}</span>
            </button>
            <button
              onClick={onOpenBookVisit}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-800 font-semibold text-xs sm:text-sm transition-all"
            >
              <span>{isPersian ? 'بازدید حضوری' : 'Book a Tour'}</span>
            </button>
          </div>
        </div>

        {/* Category Filters (Apple segmented control pill matching uploaded reference) */}
        <div className="flex mb-8 overflow-x-auto pb-2 scrollbar-none">
          <div className="inline-flex items-center p-1.5 bg-[#EBEDF0] rounded-full border border-black/[0.04] shadow-xs">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2 rounded-full text-xs font-semibold transition-all shrink-0 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#1D1D1F] text-white shadow-sm'
                    : 'text-[#1D1D1F]/80 hover:text-[#1D1D1F] hover:bg-black/[0.03]'
                }`}
              >
                {cat === 'All' ? (isPersian ? 'همه امکانات' : 'All Facilities') : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Main Facility Showcase Spotlight */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-xl border border-slate-200 mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            
            {/* Image Preview */}
            <div className="lg:col-span-7 relative min-h-[350px] lg:min-h-[480px]">
              <img
                src={activeFacility.image}
                alt={activeFacility.nameEn}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#0F2537]/90 text-[#C5A85C] border border-[#C5A85C]/40 backdrop-blur-sm">
                  {activeFacility.category}
                </span>
              </div>
              <div className="absolute bottom-4 left-4 right-4 bg-[#0F2537]/80 backdrop-blur-md p-4 rounded-xl text-white border border-white/10">
                <div className="text-xs text-[#C5A85C] font-semibold uppercase tracking-wider">
                  {isPersian ? 'فضای منتخب در نقشه پردیس' : 'Featured Campus Facility'}
                </div>
                <div className="text-lg font-bold font-serif-heading">
                  {isPersian ? activeFacility.nameFa : activeFacility.nameEn}
                </div>
              </div>
            </div>

            {/* Info & Specifications */}
            <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#C5A85C]">
                  {isPersian ? 'مشخصات و استانداردها' : 'Specification & Equipment'}
                </span>
                <h3 className="text-2xl font-bold font-serif-heading text-[#0F2537] mt-1">
                  {isPersian ? activeFacility.nameFa : activeFacility.nameEn}
                </h3>
                <p className="mt-3 text-slate-600 text-xs sm:text-sm leading-relaxed">
                  {isPersian ? activeFacility.descriptionFa : activeFacility.descriptionEn}
                </p>

                <div className="mt-6 space-y-3">
                  <div className="text-xs font-bold uppercase tracking-wider text-[#0F2537]">
                    {isPersian ? 'امکانات شاخص:' : 'Key Amenities:'}
                  </div>
                  {(isPersian ? activeFacility.featuresFa : activeFacility.featuresEn).map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                      <div className="w-5 h-5 rounded-full bg-[#C5A85C]/20 text-[#0F2537] flex items-center justify-center shrink-0 mt-0.5 font-bold">
                        ✓
                      </div>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  {isPersian ? 'مکان: پردیس پورتزداون' : 'Location: Portsdown Campus'}
                </span>
                <button
                  onClick={onOpenVirtualTour}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0F2537] hover:text-[#C5A85C] transition-colors"
                >
                  <span>{isPersian ? 'مشاهده نمای ۳۶۰' : 'View 360° Node'}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Facility Selector Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredFacilities.map((fac) => {
            const isSelected = activeFacility.id === fac.id;
            return (
              <button
                key={fac.id}
                onClick={() => setActiveFacility(fac)}
                className={`text-left rounded-xl overflow-hidden border transition-all ${
                  isSelected
                    ? 'border-[#0F2537] ring-2 ring-[#0F2537] shadow-lg'
                    : 'border-slate-200 bg-white hover:shadow-md'
                }`}
              >
                <div className="h-32 relative">
                  <img
                    src={fac.image}
                    alt={fac.nameEn}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0F2537]/80 to-transparent" />
                  <span className="absolute bottom-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded bg-black/50 text-white backdrop-blur-sm">
                    {fac.category}
                  </span>
                </div>
                <div className="p-3">
                  <div className="text-xs sm:text-sm font-bold font-serif-heading text-[#0F2537] line-clamp-1">
                    {isPersian ? fac.nameFa : fac.nameEn}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                    {isPersian ? fac.descriptionFa : fac.descriptionEn}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

      </div>
    </section>
  );
};
