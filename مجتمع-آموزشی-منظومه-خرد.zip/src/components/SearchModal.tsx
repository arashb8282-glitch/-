import React, { useState, useMemo } from 'react';
import { Search, X, ChevronRight, FileText, Sparkles, School } from 'lucide-react';
import { Language } from '../types';
import { schoolStages, campusFacilities, timelineMilestones } from '../data/tanglinData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, lang }) => {
  if (!isOpen) return null;

  const isPersian = lang === 'fa';
  const [query, setQuery] = useState('');

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const results: { title: string; subtitle: string; href: string; type: string }[] = [];

    // Search schools
    schoolStages.forEach(s => {
      if (
        s.nameEn.toLowerCase().includes(q) || 
        s.nameFa.toLowerCase().includes(q) || 
        s.descriptionEn.toLowerCase().includes(q) ||
        s.descriptionFa.toLowerCase().includes(q)
      ) {
        results.push({
          title: isPersian ? s.nameFa : s.nameEn,
          subtitle: `${s.ageRange} • ${isPersian ? s.yearGroupsFa : s.yearGroupsEn}`,
          href: '#schools',
          type: 'School Level'
        });
      }
    });

    // Search facilities
    campusFacilities.forEach(f => {
      if (
        f.nameEn.toLowerCase().includes(q) ||
        f.nameFa.toLowerCase().includes(q) ||
        f.descriptionEn.toLowerCase().includes(q)
      ) {
        results.push({
          title: isPersian ? f.nameFa : f.nameEn,
          subtitle: `${f.category} • ${isPersian ? f.descriptionFa.slice(0, 70) : f.descriptionEn.slice(0, 70)}...`,
          href: '#campus',
          type: 'Campus Facility'
        });
      }
    });

    // Search milestones
    timelineMilestones.forEach(m => {
      if (
        m.year.includes(q) ||
        m.titleEn.toLowerCase().includes(q) ||
        m.titleFa.toLowerCase().includes(q)
      ) {
        results.push({
          title: `${m.year}: ${isPersian ? m.titleFa : m.titleEn}`,
          subtitle: isPersian ? m.descriptionFa.slice(0, 70) + '...' : m.descriptionEn.slice(0, 70) + '...',
          href: '#centenary',
          type: 'Centenary History'
        });
      }
    });

    return results;
  }, [query, isPersian]);

  const quickSearches = [
    { labelEn: 'IB Diploma', labelFa: 'دیپلم IB', query: 'IB' },
    { labelEn: 'A-Levels', labelFa: 'دوره‌های A-Level', query: 'A-Level' },
    { labelEn: 'Centenary 1925', labelFa: 'صد سالگی', query: '1925' },
    { labelEn: '50m Pool', labelFa: 'استخر ۵۰ متری', query: 'Pool' },
    { labelEn: 'Infant School', labelFa: 'مدرسه خردسالان', query: 'Infant' },
    { labelEn: 'Admissions Fees', labelFa: 'شهریه و پذیرش', query: 'Admissions' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        
        {/* Search Input Header */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3 bg-slate-50">
          <Search className="w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder={isPersian ? 'جستجو در برنامه‌ها، مقاطع تحصیلی، امکانات و اخبار تانگلین...' : 'Search Tanglin programs, facilities, centenary history, admissions...'}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full bg-transparent text-slate-800 text-sm sm:text-base focus:outline-none placeholder:text-slate-400 font-medium"
          />
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Search Chips */}
        <div className="p-3 bg-slate-100/70 border-b border-slate-200 flex items-center gap-2 overflow-x-auto text-xs scrollbar-none">
          <span className="text-slate-400 shrink-0 font-semibold uppercase text-[10px]">
            {isPersian ? 'جستجوهای سریع:' : 'Quick:'}
          </span>
          {quickSearches.map((item, idx) => (
            <button
              key={idx}
              onClick={() => setQuery(item.query)}
              className="shrink-0 px-2.5 py-1 rounded-full bg-white hover:bg-[#0F2537] hover:text-white text-slate-700 border border-slate-200 transition-colors font-medium text-xs"
            >
              {isPersian ? item.labelFa : item.labelEn}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-4">
          {query.trim() === '' ? (
            <div className="py-8 text-center text-slate-400 text-xs sm:text-sm">
              <School className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              {isPersian ? 'عبارتی را برای جستجو وارد نمایید' : 'Type to search across Tanglin Trust School portal'}
            </div>
          ) : searchResults.length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs sm:text-sm">
              {isPersian ? 'موردی یافت نشد. کلمات دیگری را امتحان کنید.' : `No matching results for "${query}". Try searching for IB, Centenary, or Infant.`}
            </div>
          ) : (
            <div className="space-y-2">
              {searchResults.map((res, idx) => (
                <a
                  key={idx}
                  href={res.href}
                  onClick={onClose}
                  className="block p-3 rounded-xl hover:bg-slate-50 border border-transparent hover:border-slate-200 transition-colors group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#C5A85C]">
                      {res.type}
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-[#0F2537]" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-[#0F2537] mt-0.5">
                    {res.title}
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                    {res.subtitle}
                  </p>
                </a>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
