import React from 'react';
import { Award, CheckCircle2 } from 'lucide-react';
import { Language } from '../types';

interface PanelWhiteAwardsProps {
  lang: Language;
  onOpenInspections: () => void;
}

export const PanelWhiteAwards: React.FC<PanelWhiteAwardsProps> = ({ lang, onOpenInspections }) => {
  return (
    <section className="w-full bg-white py-10 md:py-14 px-4 sm:px-8 border-b border-gray-200">
      <div className="max-w-7xl mx-auto">
        <div className="bg-[#FAFBFD] rounded-xl border border-gray-200/80 p-6 sm:p-8 lg:p-10 shadow-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left side: Awards statement */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center gap-2 text-[#CE0E2D]">
                <Award className="w-5 h-5 shrink-0" />
                <span className="text-xs font-bold uppercase tracking-wider">
                  {lang === 'fa' ? 'جوایز آموزش سنگاپور ۲۰۲۵' : 'Singapore Education Awards 2025'}
                </span>
              </div>

              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-[#002169] leading-snug">
                {lang === 'fa' 
                  ? 'تانگلین برای دومین سال پیاپی برنده سه مدال طلای جوایز آموزش سنگاپور شد:'
                  : 'Tanglin won three Golds in the Singapore Education Awards for the second year running in the following categories:'}
              </h2>

              <ul className="space-y-2.5 pt-1 text-gray-700 text-sm sm:text-base font-medium">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-[#CE0E2D] shrink-0 mt-0.5" />
                  <span>
                    <strong>{lang === 'fa' ? 'مدرسه بین‌المللی برگزیده سال در سنگاپور' : 'Singapore International School of the Year'}</strong>
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-[#CE0E2D] shrink-0 mt-0.5" />
                  <span>
                    <strong>{lang === 'fa' ? 'آماده‌ترین مدرسه بین‌المللی برای آینده دانش‌آموزان' : 'International School with the Most Future-Ready Students'}</strong>
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-[#CE0E2D] shrink-0 mt-0.5" />
                  <span>
                    <strong>{lang === 'fa' ? 'جایزه طلای برنامه درسی بریتانیا' : 'The Curriculum Awards (British)'}</strong>
                  </span>
                </li>
              </ul>

              <div className="pt-2">
                <button
                  onClick={onOpenInspections}
                  className="text-xs sm:text-sm font-bold text-[#002169] hover:text-[#CE0E2D] inline-flex items-center gap-1.5 transition-colors group underline underline-offset-4"
                >
                  <span>{lang === 'fa' ? 'مشاهده جزئیات جوایز و استانداردهای BSO' : 'Read more about our awards & accreditations'}</span>
                  <span className="group-hover:translate-x-1 transition-transform">→</span>
                </button>
              </div>
            </div>

            {/* Right side: The 3 Gold Award badges */}
            <div className="lg:col-span-5 flex items-center justify-center gap-4 sm:gap-6 flex-wrap sm:flex-nowrap">
              <div className="flex flex-col items-center text-center group">
                <img
                  src="/assets/award-internationalschool-2025.png"
                  alt="Singapore International School of the Year 2025 Gold Winner"
                  className="w-24 sm:w-28 md:w-32 h-auto object-contain transition-transform duration-300 group-hover:scale-105 filter drop-shadow-md"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <span className="mt-2 text-[11px] font-bold text-gray-700 max-w-[110px] leading-tight">
                  {lang === 'fa' ? 'مدرسه بین‌المللی سال' : 'International School of the Year'}
                </span>
              </div>

              <div className="flex flex-col items-center text-center group">
                <img
                  src="/assets/award-futureready-2025.png"
                  alt="International School with Most Future-Ready Students 2025 Gold Winner"
                  className="w-24 sm:w-28 md:w-32 h-auto object-contain transition-transform duration-300 group-hover:scale-105 filter drop-shadow-md"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <span className="mt-2 text-[11px] font-bold text-gray-700 max-w-[110px] leading-tight">
                  {lang === 'fa' ? 'آماده‌ترین برای آینده' : 'Most Future-Ready Students'}
                </span>
              </div>

              <div className="flex flex-col items-center text-center group">
                <img
                  src="/assets/award-curriculum-2025.png"
                  alt="The Curriculum Awards (British) 2025 Gold Winner"
                  className="w-24 sm:w-28 md:w-32 h-auto object-contain transition-transform duration-300 group-hover:scale-105 filter drop-shadow-md"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <span className="mt-2 text-[11px] font-bold text-gray-700 max-w-[110px] leading-tight">
                  {lang === 'fa' ? 'برنامه درسی بریتانیا' : 'British Curriculum Award'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
