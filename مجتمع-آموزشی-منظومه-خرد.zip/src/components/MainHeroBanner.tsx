import React from 'react';

interface MainHeroBannerProps {
  lang: 'en' | 'fa';
}

export const MainHeroBanner: React.FC<MainHeroBannerProps> = ({ lang }) => {
  return (
    <section className="relative w-full overflow-hidden bg-slate-900 border-b border-gray-200">
      <div className="w-full max-w-7xl mx-auto">
        <div className="relative aspect-[21/9] sm:aspect-[24/9] md:aspect-[3/1] max-h-[480px] w-full overflow-hidden">
          <img
            src="/assets/photos/hero-centenary.jpg"
            alt="Tanglin Trust School Centenary Building - Portsdown Road Singapore"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
            loading="eager"
          />
          {/* Subtle gradient scrim */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
          
          <div className="absolute bottom-3 left-4 sm:bottom-6 sm:left-8 bg-black/50 backdrop-blur-xs text-white px-3 py-1.5 rounded text-xs sm:text-sm font-medium">
            <span>
              {lang === 'fa' 
                ? 'پردیس وان-نورث، ساختمان صدمین سالگرد تانگلین (۱۹۲۵–۲۰۲۵)' 
                : 'One-North Campus, Tanglin Centenary Building (1925–2025)'}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
