import React from 'react';

interface KheradLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

/**
 * Official Kherad Logo from the repository:
 * File: kherad/logo.svg -> /assets/logo.svg
 * 
 * Requirements:
 * - Preserve original proportions.
 * - Preserve original colors (#007ec2 and #231f20).
 * - Preserve original SVG structure.
 * - Do not redraw, simplify, or modify.
 */
export const KheradLogo: React.FC<KheradLogoProps> = ({
  className = '',
  size = 'md',
  showText = true
}) => {
  const getHeightClass = () => {
    switch (size) {
      case 'sm':
        return 'h-10 sm:h-12';
      case 'lg':
        return 'h-18 sm:h-22';
      case 'xl':
        return 'h-24 sm:h-28';
      case 'md':
      default:
        return 'h-14 sm:h-18';
    }
  };

  return (
    <div className={`inline-flex items-center p-0 m-0 bg-transparent select-none ${className}`}>
      <img
        src="/assets/logo.svg"
        alt="مجتمع آموزشی و فرهنگی دخترانه منظومه خرد - Manzoomeh Kherad Institute"
        className={`${getHeightClass()} w-auto max-w-full object-contain p-0 m-0 bg-transparent transform scale-125 origin-center transition-transform`}
        loading="eager"
      />
    </div>
  );
};
