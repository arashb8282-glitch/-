import React from 'react';
import { 
  ChevronRight, 
  Compass, 
  Calendar, 
  Download, 
  Award, 
  Sparkles,
  ArrowDown
} from 'lucide-react';
import { Language } from '../types';

interface HeroProps {
  lang: Language;
  onOpenTour: () => void;
  onOpenBookVisit: () => void;
}

export const Hero: React.FC<HeroProps> = ({ lang, onOpenTour, onOpenBookVisit }) => {
  const isPersian = lang === 'fa';

  const quickJumpLinks = [
    { labelEn: "CEO's Welcome", labelFa: 'پیام مدیرعامل', href: '#ceo-welcome' },
    { labelEn: 'Our Centenary', labelFa: 'صد سالگی تانگلین', href: '#centenary' },
    { labelEn: 'The 4 Schools', labelFa: 'چهار مقطع تحصیلی', href: '#schools' },
    { labelEn: 'Dual Pathway', labelFa: 'مسیر دوگانه Sixth Form', href: '#dual-pathway' },
    { labelEn: 'Campus & Facilities', labelFa: 'پردیس و امکانات', href: '#campus' },
    { labelEn: 'Academic Results', labelFa: 'نتایج تحصیلی و دانشگاه‌ها', href: '#academics' },
    { labelEn: 'Admissions', labelFa: 'پذیرش و بازدید', href: '#admissions-section' },
  ];

  return (
    <section className="relative w-full overflow-hidden bg-[#0B1B2B]">
      {/* Background Image with Cinematic British Navy Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=2000&q=85"
          alt="Tanglin Trust School Campus"
          className="w-full h-full object-cover object-center opacity-30 transform scale-105 filter saturate-90"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#08131F]/95 via-[#0F2537]/85 to-[#0B1B2B]/75" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B1B2B] via-transparent to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-16 lg:pt-14 lg:pb-24">
        
        {/* Breadcrumb Navigation */}
        <nav className="flex items-center gap-2 text-xs font-medium text-slate-400 mb-6">
          <a href="#" className="hover:text-white transition-colors">
            {isPersian ? 'صفحه نخست' : 'Home'}
          </a>
          <ChevronRight className="w-3.5 h-3.5 text-[#C5A85C]" />
          <span className="text-[#C5A85C] font-semibold">
            {isPersian ? 'درباره تانگلین' : 'About Tanglin'}
          </span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Main Hero Copy */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Centenary Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#C5A85C]/15 border border-[#C5A85C]/40 text-[#E5C97A] text-xs font-semibold backdrop-blur-sm">
              <Sparkles className="w-4 h-4 text-[#C5A85C]" />
              <span className="tracking-widest uppercase">
                {isPersian ? 'یک قرن اصالت و افتخار • ۱۹۲۵ تا ۲۰۲۵' : 'Centenary 1925–2025 • 100 Years of Excellence'}
              </span>
            </div>

            {/* Page Title */}
            <div>
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white font-serif-heading leading-tight">
                {isPersian ? 'درباره تانگلین' : 'About Tanglin'}
              </h1>
              <p className="mt-2 text-xl sm:text-2xl text-[#C5A85C] font-light italic tracking-wide">
                {isPersian ? 'نسل‌ها در مسیر تعالی و شکوفایی' : 'Generations of Excellence'}
              </p>
            </div>

            {/* Intro Lead */}
            <p className="text-slate-300 text-base sm:text-lg max-w-3xl leading-relaxed">
              {isPersian
                ? 'مدرسه تانگلین تراست سنگاپور که در سال ۱۹۲۵ تاسیس شد، کهن‌ترین مدرسه بین‌المللی با نظام آموزشی بریتانیایی در جنوب شرق آسیا است. ما محیطی الهام‌بخش، پویا و بین‌المللی را برای بیش از ۲۸۰۰ دانش‌آموز از ۵۵ ملیت فراهم می‌آوریم تا با هویت چندفرهنگی و تعهد اخلاقی به برترین دانشگاه‌های جهان راه یابند.'
                : 'Established in 1925, Tanglin Trust School is the oldest British international school in Southeast Asia. We provide an extraordinary British-based education with an international perspective to over 2,800 students from more than 50 nationalities, combining a rich 100-year heritage with pioneering 21st-century academic pathways.'}
            </p>

            {/* Call to Actions */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                id="hero-virtual-tour-btn"
                onClick={onOpenTour}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-[#C5A85C] hover:bg-[#D4B76B] text-[#0F2537] font-bold text-sm transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-102"
              >
                <Compass className="w-4 h-4" />
                <span>{isPersian ? 'کاوش در تور مجازی پردیس' : 'Explore 360° Virtual Tour'}</span>
              </button>

              <button
                id="hero-book-visit-btn"
                onClick={onOpenBookVisit}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/30 font-semibold text-sm transition-all duration-200 backdrop-blur-sm"
              >
                <Calendar className="w-4 h-4 text-[#C5A85C]" />
                <span>{isPersian ? 'رزرو تور حضوری و بازدید' : 'Book a Campus Visit'}</span>
              </button>

              <a
                href="#admissions-section"
                className="inline-flex items-center gap-1.5 px-4 py-3.5 text-xs text-slate-300 hover:text-white transition-colors"
              >
                <Download className="w-4 h-4 text-[#C5A85C]" />
                <span>{isPersian ? 'دریافت بروشور و دفترچه راهنما' : 'School Prospectus (PDF)'}</span>
              </a>
            </div>
          </div>

          {/* Centenary Crest Shield Graphic */}
          <div className="lg:col-span-4 flex justify-center lg:justify-end">
            <div className="relative p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-white/10 to-white/5 border border-white/15 backdrop-blur-md text-center max-w-xs shadow-2xl">
              <div className="w-20 h-20 mx-auto rounded-full bg-[#0F2537] border-2 border-[#C5A85C] flex items-center justify-center shadow-inner">
                <Award className="w-10 h-10 text-[#C5A85C]" />
              </div>
              <h2 className="mt-4 text-xl font-bold font-serif-heading text-white tracking-wide">
                {isPersian ? 'یک قرن تعالی' : '100th Centenary'}
              </h2>
              <div className="text-xs text-[#C5A85C] font-semibold tracking-widest mt-1 uppercase">
                1925 – 2025
              </div>
              <p className="mt-3 text-xs text-slate-300 leading-relaxed">
                {isPersian
                  ? 'یک سده الهام‌بخشی، تربیت نسل‌های درخشان و آموزش اصیل بریتانیایی در قلب سنگاپور.'
                  : 'A century of pioneering British education, fostering curiosity, integrity, and global citizenship.'}
              </p>
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-around text-center">
                <div>
                  <div className="text-lg font-bold text-white">#1</div>
                  <div className="text-[10px] text-slate-400">{isPersian ? 'کهن‌ترین در SEA' : 'Oldest in SEA'}</div>
                </div>
                <div className="w-px h-6 bg-white/20" />
                <div>
                  <div className="text-lg font-bold text-[#C5A85C]">BSO</div>
                  <div className="text-[10px] text-slate-400">{isPersian ? 'رتبه ممتاز' : 'Outstanding'}</div>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Quick Jump In-Page Sub-navigation Bar */}
      <div className="border-t border-slate-800 bg-[#08131F]/95 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 overflow-x-auto py-3 text-xs font-semibold scrollbar-none">
            <span className="shrink-0 text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <ArrowDown className="w-3.5 h-3.5 text-[#C5A85C]" />
              {isPersian ? 'دسترسی سریع به بخش‌ها:' : 'In This Section:'}
            </span>
            {quickJumpLinks.map((link, idx) => (
              <a
                key={idx}
                href={link.href}
                className="shrink-0 px-3 py-1.5 rounded-full bg-white/5 hover:bg-[#C5A85C]/20 text-slate-300 hover:text-white transition-all border border-white/10 hover:border-[#C5A85C]/50 whitespace-nowrap"
              >
                {isPersian ? link.labelFa : link.labelEn}
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
