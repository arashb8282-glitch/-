import React, { useState } from 'react';
import { X, CheckCircle, ArrowLeft, ArrowRight, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface KheradAdmissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const KheradAdmissionsModal: React.FC<KheradAdmissionsModalProps> = ({ isOpen, onClose }) => {
  const { isPersian, t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'apply' | 'track' | 'criteria'>('apply');
  const [trackingCode, setTrackingCode] = useState('');
  const [trackingResult, setTrackingResult] = useState<string | null>(null);

  // Form State
  const [grade, setGrade] = useState('پیش‌دبستانی (۴ تا ۵ سال)');
  const [studentName, setStudentName] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [parentName, setParentName] = useState('');
  const [phone, setPhone] = useState('');
  const [submittedCode, setSubmittedCode] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedCode = 'KHR-' + Math.floor(100000 + Math.random() * 900000);
    setSubmittedCode(generatedCode);
  };

  const handleTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackingCode.trim()) return;
    setTrackingResult(
      isPersian
        ? `درخواست با کد پیگیری ${trackingCode} در حال بررسی توسط واحد پذیرش مقطع می‌باشد. کارشناسان ما جهت هماهنگی جلسه معارفه با شماره ثبت‌شده تماس خواهند گرفت.`
        : `Application with tracking code ${trackingCode} is currently under review by the admissions committee. Our staff will contact your registered phone number to schedule the introductory session.`
    );
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-6 font-persian" dir={isPersian ? 'rtl' : 'ltr'}>
        {/* Apple dimmed backdrop */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 bg-black/40 backdrop-blur-md"
          onClick={onClose}
        />

        {/* Modal Window */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.96, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 16 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-3xl bg-white rounded-3xl shadow-[0_24px_80px_rgba(0,0,0,0.18)] overflow-hidden flex flex-col max-h-[90vh] border border-black/[0.08] z-10"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="bg-white/95 backdrop-blur-2xl text-slate-900 px-6 sm:px-8 py-5 flex items-center justify-between border-b border-black/[0.06]">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2A6AB2]" />
              <div>
                <span className="text-[10px] text-slate-400 font-mono tracking-wider block">
                  {isPersian ? 'پورتال خدمات الکترونیک منظومه خرد' : 'Kherad Online Services Portal'}
                </span>
                <h2 className="text-base sm:text-lg font-bold text-slate-900 font-serif-heading">
                  {isPersian 
                    ? 'سامانه پذیرش و پیش‌ثبت‌نام دانش‌آموز (سال تحصیلی ۱۴۰۴-۱۴۰۵)' 
                    : 'Student Admissions & Pre-Registration Portal (2025–2026)'}
                </h2>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-[#F5F5F7] hover:bg-[#EBECEF] text-slate-700 flex items-center justify-center transition-all border border-black/[0.05] cursor-pointer active:scale-95"
              aria-label={isPersian ? 'بستن' : 'Close'}
            >
              <X className="w-4.5 h-4.5 stroke-[1.5]" />
            </button>
          </div>

          {/* Tab Selection */}
          <div className="bg-white px-6 sm:px-8 py-3.5 border-b border-black/[0.05] flex justify-center">
            <div className="inline-flex items-center gap-1.5 p-1.5 bg-[#EBEDF0] rounded-full border border-black/[0.04] shadow-xs">
              <button
                onClick={() => { setActiveTab('apply'); setSubmittedCode(null); }}
                className={`text-xs sm:text-[13px] font-medium px-5 sm:px-6 py-2 rounded-full transition-all duration-200 cursor-pointer ${
                  activeTab === 'apply'
                    ? 'bg-[#1D1D1F] text-white shadow-sm'
                    : 'text-[#1D1D1F]/80 hover:text-[#1D1D1F] hover:bg-black/[0.03]'
                }`}
              >
                {isPersian ? 'فرم پیش‌ثبت‌نام اینترنتی' : 'Online Application Form'}
              </button>
              <button
                onClick={() => setActiveTab('track')}
                className={`text-xs sm:text-[13px] font-medium px-5 sm:px-6 py-2 rounded-full transition-all duration-200 cursor-pointer ${
                  activeTab === 'track'
                    ? 'bg-[#1D1D1F] text-white shadow-sm'
                    : 'text-[#1D1D1F]/80 hover:text-[#1D1D1F] hover:bg-black/[0.03]'
                }`}
              >
                {isPersian ? 'پیگیری پرونده با کد رهگیری' : 'Track Application Status'}
              </button>
              <button
                onClick={() => setActiveTab('criteria')}
                className={`text-xs sm:text-[13px] font-medium px-5 sm:px-6 py-2 rounded-full transition-all duration-200 cursor-pointer ${
                  activeTab === 'criteria'
                    ? 'bg-[#1D1D1F] text-white shadow-sm'
                    : 'text-[#1D1D1F]/80 hover:text-[#1D1D1F] hover:bg-black/[0.03]'
                }`}
              >
                {isPersian ? 'شرایط سنی و مقاطع' : 'Age & Grade Criteria'}
              </button>
            </div>
          </div>

          {/* Content Area */}
          <div className="p-6 sm:p-8 overflow-y-auto flex-1">
            {activeTab === 'apply' && (
              <div>
                {submittedCode ? (
                  <div className="text-center py-8 space-y-4">
                    <div className="w-16 h-16 bg-[#0b82c6]/10 text-[#0b82c6] border border-[#0b82c6]/20 rounded-full flex items-center justify-center mx-auto shadow-inner">
                      <CheckCircle className="w-9 h-9 stroke-[1.4]" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 font-serif-heading">
                      {isPersian ? 'پیش‌ثبت‌نام با موفقیت ثبت شد' : 'Pre-Registration Submitted Successfully'}
                    </h3>
                    <p className="text-sm text-slate-500 max-w-md mx-auto font-light">
                      {isPersian 
                        ? 'اطلاعات متقاضی در پایگاه داده پذیرش منظومه خرد ثبت گردید. لطفاً کد رهگیری زیر را جهت پیگیری‌های بعدی یادداشت فرمایید.'
                        : 'Applicant data has been recorded in Kherad Admissions Database. Please keep this tracking code for future reference.'}
                    </p>
                    <div className="p-4 bg-[#F5F5F7] rounded-2xl max-w-xs mx-auto border border-black/[0.06]">
                      <span className="text-xs text-slate-400 block mb-1">
                        {isPersian ? 'کد رهگیری اختصاصی:' : 'Your Tracking Code:'}
                      </span>
                      <span className="text-2xl font-mono font-extrabold text-[#2A6AB2] tracking-widest">
                        {submittedCode}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 pt-2 font-light">
                      {isPersian 
                        ? 'پیامک تایید حاوی اطلاعات مصاحبه و تکمیل مدارک به شماره تلفن همراه شما ارسال خواهد شد.'
                        : 'Confirmation SMS with interview and document details will be sent to your mobile.'}
                    </div>
                    <button
                      onClick={() => { setSubmittedCode(null); }}
                      className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-6 py-2.5 rounded-full shadow-xs transition-colors cursor-pointer"
                    >
                      {isPersian ? 'ثبت متقاضی جدید' : 'New Application'}
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="bg-[#F5F5F7] p-4 rounded-2xl border border-black/[0.05] flex items-start gap-3 text-xs text-slate-700">
                      <AlertCircle className="w-4 h-4 text-[#2A6AB2] stroke-[1.5] shrink-0 mt-0.5" />
                      <span className="font-light leading-relaxed">
                        {isPersian 
                          ? 'ظرفیت پذیرش پایه‌های مختلف بر اساس استانداردهای آموزشی محدود بوده و اولویت ارزیابی با متقاضیانی است که فرآیند پیش‌ثبت‌نام را زودتر تکمیل نمایند.'
                          : 'Class capacity across all levels adheres to progressive quality standards. Priority is given to early applicants.'}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          {isPersian ? 'پایه و مقطع تحصیلی مورد تقاضا *' : 'Desired Grade & Stage *'}
                        </label>
                        <select
                          value={grade}
                          onChange={(e) => setGrade(e.target.value)}
                          className="w-full text-xs font-medium border border-black/[0.08] bg-[#F5F5F7] rounded-full px-5 py-3 focus:bg-white focus:ring-2 focus:ring-[#2A6AB2] focus:outline-none transition-all cursor-pointer"
                        >
                          <option>{isPersian ? 'پیش‌دبستانی ۱ (۳ تا ۴ سال)' : 'Preschool 1 (Ages 3–4)'}</option>
                          <option>{isPersian ? 'پیش‌دبستانی ۲ (۴ تا ۵ سال)' : 'Preschool 2 (Ages 4–5)'}</option>
                          <option>{isPersian ? 'آمادگی (۵ تا ۶ سال)' : 'Kindergarten (Ages 5–6)'}</option>
                          <option>{isPersian ? 'دبستان - پایه اول' : 'Elementary School - Grade 1'}</option>
                          <option>{isPersian ? 'دبستان - پایه‌های دوم تا ششم' : 'Elementary School - Grades 2–6'}</option>
                          <option>{isPersian ? 'متوسطه دوره اول (پایه‌های هفتم تا نهم)' : 'Middle School (Grades 7–9)'}</option>
                          <option>{isPersian ? 'متوسطه دوره دوم - ریاضی و تجربی (دهم تا دوازدهم)' : 'High School - STEM (Grades 10–12)'}</option>
                          <option>{isPersian ? 'هنرستان دخترانه خرد - گرافیک و انیمیشن' : 'Kherad Vocational & Arts School (Graphics & Animation)'}</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          {isPersian ? 'نام و نام خانوادگی دانش‌آموز *' : "Student's Full Name *"}
                        </label>
                        <input
                          type="text"
                          required
                          value={studentName}
                          onChange={(e) => setStudentName(e.target.value)}
                          placeholder={isPersian ? 'مثال: سارا محمدی' : 'e.g. Sara Mohammadi'}
                          className="w-full text-xs border border-black/[0.08] bg-[#F5F5F7] rounded-full px-5 py-3 focus:bg-white focus:ring-2 focus:ring-[#2A6AB2] focus:outline-none transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          {isPersian ? 'کد ملی دانش‌آموز (۱۰ رقم) *' : 'National ID / Passport No. *'}
                        </label>
                        <input
                          type="text"
                          required
                          maxLength={10}
                          value={nationalId}
                          onChange={(e) => setNationalId(e.target.value)}
                          placeholder="0012345678"
                          className="w-full text-xs border border-black/[0.08] bg-[#F5F5F7] rounded-full px-5 py-3 focus:bg-white focus:ring-2 focus:ring-[#2A6AB2] focus:outline-none transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          {isPersian ? 'نام و نام خانوادگی والد / ولی دانش‌آموز *' : "Parent / Guardian Name *"}
                        </label>
                        <input
                          type="text"
                          required
                          value={parentName}
                          onChange={(e) => setParentName(e.target.value)}
                          placeholder={isPersian ? 'نام پدر یا مادر' : "Father's or Mother's Name"}
                          className="w-full text-xs border border-black/[0.08] bg-[#F5F5F7] rounded-full px-5 py-3 focus:bg-white focus:ring-2 focus:ring-[#2A6AB2] focus:outline-none transition-all"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          {isPersian ? 'شماره تلفن همراه جهت دریافت پیامک و هماهنگی جلسه معارفه *' : 'Mobile Phone for SMS & Scheduling *'}
                        </label>
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="0912XXXXXXX"
                          className="w-full text-xs border border-black/[0.08] bg-[#F5F5F7] rounded-full px-5 py-3 focus:bg-white focus:ring-2 focus:ring-[#2A6AB2] focus:outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="pt-4 border-t border-black/[0.06] flex items-center justify-between">
                      <span className="text-xs text-slate-500 font-light">
                        {isPersian ? 'واحد پذیرش: ۰۲۱-۲۲۱۷۰۰۰۱' : 'Admissions Tel: +98-21-22170001'}
                      </span>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        type="submit"
                        className="bg-[#2A6AB2] hover:bg-[#1976D2] text-white text-xs sm:text-sm font-semibold px-6 py-2.5 rounded-full shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
                      >
                        <span>{isPersian ? 'تایید و ارسال نهایی پیش‌ثبت‌نام' : 'Submit Pre-Registration'}</span>
                        {isPersian ? <ArrowLeft className="w-4 h-4 stroke-[1.5]" /> : <ArrowRight className="w-4 h-4 stroke-[1.5]" />}
                      </motion.button>
                    </div>
                  </form>
                )}
              </div>
            )}

            {activeTab === 'track' && (
              <div className="space-y-5">
                <p className="text-xs sm:text-sm text-slate-600 font-light">
                  {isPersian 
                    ? 'اولیا محترم؛ در صورتی که پیش از این فرم پیش‌ثبت‌نام را تکمیل نموده‌اید، می‌توانید با وارد کردن کد رهگیری اختصاصی یا کد ملی دانش‌آموز، وضعیت پرونده خود را استعلام نمایید.'
                    : 'Dear parents: If you have already submitted the pre-registration form, you can check the progress of your application using your tracking code or student ID.'}
                </p>

                <form onSubmit={handleTrackSubmit} className="flex gap-2">
                  <input
                    type="text"
                    value={trackingCode}
                    onChange={(e) => setTrackingCode(e.target.value)}
                    placeholder={isPersian ? 'کد رهگیری (مثال: KHR-123456) یا کد ملی' : 'Tracking Code (e.g. KHR-123456) or National ID'}
                    className="flex-1 text-xs border border-black/[0.08] bg-[#F5F5F7] rounded-full px-5 py-3 focus:bg-white focus:ring-2 focus:ring-[#2A6AB2] focus:outline-none transition-all"
                  />
                  <button
                    type="submit"
                    className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-6 py-3 rounded-full shadow-xs transition-colors shrink-0 cursor-pointer"
                  >
                    {isPersian ? 'استعلام پرونده' : 'Check Status'}
                  </button>
                </form>

                {trackingResult && (
                  <div className="bg-[#F5F5F7] border border-black/[0.06] p-4 rounded-2xl space-y-2">
                    <span className="text-xs font-semibold text-slate-900 block">
                      {isPersian ? 'نتیجه استعلام وضعیت:' : 'Inquiry Result:'}
                    </span>
                    <p className="text-xs text-slate-600 leading-relaxed font-light">
                      {trackingResult}
                    </p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'criteria' && (
              <div className="space-y-4 text-xs text-slate-700">
                <h4 className="font-bold text-sm text-slate-900 border-r-3 border-[#2A6AB2] pr-3 font-serif-heading">
                  {isPersian ? 'جدول انطباق سن و شرایط ورود به پایه‌های منظومه خرد' : 'Age Criteria & Entry Prerequisites'}
                </h4>

                <div className="overflow-x-auto rounded-2xl border border-black/[0.06]">
                  <table className="w-full text-right border-collapse text-xs">
                    <thead className="bg-[#F5F5F7] text-slate-800">
                      <tr>
                        <th className="p-3 font-semibold border-b border-black/[0.06]">{isPersian ? 'مقطع / دوره' : 'Stage'}</th>
                        <th className="p-3 font-semibold border-b border-black/[0.06]">{isPersian ? 'پایه تحصیلی' : 'Grade'}</th>
                        <th className="p-3 font-semibold border-b border-black/[0.06]">{isPersian ? 'شرایط سنی و تاریخ تولد' : 'Birth Period / Age'}</th>
                        <th className="p-3 font-semibold border-b border-black/[0.06]">{isPersian ? 'نوع ارزیابی' : 'Assessment Type'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-black/[0.04]">
                      <tr>
                        <td className="p-3 font-medium">{isPersian ? 'پیش‌دبستانی' : 'Preschool'}</td>
                        <td className="p-3">{isPersian ? '۳ تا ۵ سال' : 'Ages 3–5'}</td>
                        <td className="p-3">{isPersian ? 'متولدین ۱۳۹۸ تا ۱۴۰۰' : '2019–2021'}</td>
                        <td className="p-3">{isPersian ? 'مشاهده رفتاری و بازی گروهی' : 'Behavioral Observation & Play'}</td>
                      </tr>
                      <tr className="bg-[#F5F5F7]/40">
                        <td className="p-3 font-medium">{isPersian ? 'دبستان' : 'Elementary School'}</td>
                        <td className="p-3">{isPersian ? 'اول تا ششم' : 'Grades 1–6'}</td>
                        <td className="p-3">{isPersian ? 'متولدین ۱۳۹۲ تا ۱۳۹۷' : '2013–2018'}</td>
                        <td className="p-3">{isPersian ? 'سنجش آمادگی تحصیلی و مصاحبه' : 'School Readiness & Interview'}</td>
                      </tr>
                      <tr>
                        <td className="p-3 font-medium">{isPersian ? 'متوسطه اول' : 'Middle School'}</td>
                        <td className="p-3">{isPersian ? 'هفتم، هشتم، نهم' : 'Grades 7, 8, 9'}</td>
                        <td className="p-3">{isPersian ? 'اتمام دوره ششم با کارنامه خیلی‌خوب' : 'Elementary Completion'}</td>
                        <td className="p-3">{isPersian ? 'آزمون مفهومی علوم و ریاضی' : 'Conceptual Math & Science Exam'}</td>
                      </tr>
                      <tr className="bg-[#F5F5F7]/40">
                        <td className="p-3 font-medium">{isPersian ? 'متوسطه دوم و هنرستان' : 'High School & Vocational'}</td>
                        <td className="p-3">{isPersian ? 'دهم تا دوازدهم' : 'Grades 10–12'}</td>
                        <td className="p-3">{isPersian ? 'هدایت تحصیلی مجاز و معدل بالا' : 'Academic Standing'}</td>
                        <td className="p-3">{isPersian ? 'آزمون ورودی و ارائه پورتفولیو (هنرستان)' : 'Entrance Exam & Art Portfolio'}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
