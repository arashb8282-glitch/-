import React from 'react';
import { ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface KheradAboutPanelProps {
  onOpenDetails: (id: string) => void;
  onOpenAdmissions?: () => void;
  onOpenCampus?: () => void;
}

export const KheradAboutPanel: React.FC<KheradAboutPanelProps> = ({
  onOpenDetails,
  onOpenAdmissions,
  onOpenCampus,
}) => {
  const { lang, t, isPersian } = useLanguage();

  return (
    <section 
      id="about-tanglin-section"
      className="relative w-full bg-[#ffffff] text-[#ffffff] py-14 sm:py-20 lg:py-24 px-4 sm:px-8 lg:px-12 border-none select-none overflow-hidden"
      style={{ backgroundColor: '#ffffff', color: '#ffffff' }}
      dir={isPersian ? 'rtl' : 'ltr'}
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-14 items-center">
          
          {/* Column 1: Narrative Content (Breadcrumb, Title, Lead & Body Paragraphs) */}
          <motion.div 
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="w-full flex flex-col justify-center space-y-6"
          >
            {/* Top Breadcrumb matching uploaded design: خانه ، درباره خرد ، ماموریت و چشم‌انداز */}
            <div className="flex items-center">
              <nav 
                className="flex items-center flex-wrap gap-x-2 gap-y-1 text-xs sm:text-[13px] md:text-sm font-medium tracking-normal text-slate-600 select-text"
                aria-label="Breadcrumb"
              >
                <span 
                  className="hover:text-slate-900 transition-colors cursor-pointer"
                  onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                >
                  {isPersian ? 'خانه' : 'Home'}
                </span>

                <span className="text-slate-400 font-light select-none px-0.5">
                  {isPersian ? '،' : ','}
                </span>

                <span 
                  className="hover:text-slate-900 transition-colors cursor-pointer"
                  onClick={() => onOpenDetails('history')}
                >
                  {isPersian ? 'درباره خرد' : 'About Kherad'}
                </span>

                <span className="text-slate-400 font-light select-none px-0.5">
                  {isPersian ? '،' : ','}
                </span>

                <span className="text-[#0b82c6] font-medium">
                  {isPersian ? 'ماموریت و چشم‌انداز' : 'Mission & Vision'}
                </span>
              </nav>
            </div>

            {/* Main Title Heading - #414141 */}
            <h1 
              className="text-xl sm:text-2xl lg:text-3xl font-serif-heading font-extrabold text-[#414141] tracking-tight leading-tight"
              style={{ color: '#414141' }}
            >
              {t.aboutPanel.title}
            </h1>

            {/* Paragraph 1: Prominent Lead Introduction - #414141 */}
            <p 
              className="text-sm sm:text-base lg:text-[16px] text-[#414141] leading-relaxed font-normal text-justify"
              style={{ color: '#414141' }}
            >
              {t.aboutPanel.lead}
            </p>

            {/* Paragraph 2: Rich Institutional Details - #414141 */}
            <p 
              className="text-xs sm:text-sm lg:text-[14.5px] text-[#414141] leading-relaxed font-normal text-justify"
              style={{ color: '#414141' }}
            >
              {t.aboutPanel.bodyPart1}
              <button 
                onClick={() => onOpenDetails('results')}
                className="underline underline-offset-4 decoration-[#0b82c6]/40 font-semibold text-[#0b82c6] hover:text-[#08669c] hover:decoration-[#08669c] transition-all cursor-pointer inline-flex items-center gap-1 mx-1"
              >
                <span>{t.aboutPanel.resultsLink}</span>
                <ExternalLink className="w-3 h-3 inline stroke-[2]" />
              </button>
              {t.aboutPanel.bodyPart2}
            </p>
          </motion.div>

          {/* Column 2: Frameless Photographic Showcase */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.96 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.85, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="w-full flex flex-col justify-center"
          >
            {/* Clean Frameless Image Showcase with straight sharp edges (no curve) & reduced height */}
            <div className="relative overflow-hidden aspect-[16/10] rounded-none shadow-lg bg-slate-200 dark:bg-slate-800 group">
              <img
                src="/assets/kherad-brand/photos/9.webp"
                alt={t.aboutPanel.imgAlt}
                className="w-full h-full object-cover object-center rounded-none transition-transform duration-700 group-hover:scale-103"
                loading="lazy"
              />

              {/* Subtle gradient vignette at bottom */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent pointer-events-none" />
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
