import React from 'react';
import { Quote, Heart, Shield, Sparkles, CheckCircle2 } from 'lucide-react';
import { values } from '../data/tanglinData';
import { Language } from '../types';

interface CeoWelcomeProps {
  lang: Language;
}

export const CeoWelcome: React.FC<CeoWelcomeProps> = ({ lang }) => {
  const isPersian = lang === 'fa';

  return (
    <section id="ceo-welcome" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0F2537]/5 text-[#0F2537] text-xs font-bold uppercase tracking-widest mb-3">
            <Quote className="w-3.5 h-3.5 text-[#C5A85C]" />
            {isPersian ? 'پیام مدیریت ارشد' : 'Leadership & Vision'}
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0F2537] font-serif-heading">
            {isPersian ? 'پیام خوش‌آمدگویی مدیرعامل مدرسه' : 'Welcome to Tanglin Trust School'}
          </h2>
          <div className="w-16 h-1 bg-[#C5A85C] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            {isPersian
              ? 'روایت یک قرن تعهد به شکوفایی استعدادهای فردی در جامعه‌ای صمیمی و بین‌المللی'
              : 'A personal message from Craig Considine, Chief Executive Officer, on our community and core ethos.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* CEO Photo & Profile Card */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md">
              <div className="absolute -inset-4 bg-gradient-to-tr from-[#C5A85C]/20 to-[#0F2537]/10 rounded-2xl filter blur-xl opacity-70" />
              
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white bg-slate-100">
                <img
                  src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&q=80"
                  alt="Craig Considine, CEO Tanglin Trust School"
                  className="w-full h-[450px] object-cover object-top"
                />
                
                {/* Photo Badge */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#0B1B2B] via-[#0F2537]/90 to-transparent p-6 text-white">
                  <h3 className="text-xl font-bold font-serif-heading text-white">
                    Craig Considine
                  </h3>
                  <p className="text-xs font-semibold text-[#C5A85C] tracking-wide mt-0.5">
                    {isPersian ? 'مدیرعامل و سرپرست مدرسه تانگلین' : 'Chief Executive Officer (CEO)'}
                  </p>
                  <p className="text-[11px] text-slate-300 mt-1">
                    {isPersian ? 'مدرسه تانگلین تراست، سنگاپور' : 'Tanglin Trust School, Singapore'}
                  </p>
                </div>
              </div>

              {/* Decorative Centenary Stamp */}
              <div className="absolute -top-4 -right-4 bg-[#C5A85C] text-[#0F2537] p-3 rounded-full shadow-lg border-2 border-white flex flex-col items-center justify-center w-16 h-16 text-center">
                <span className="text-[10px] font-bold uppercase leading-none">EST.</span>
                <span className="text-base font-extrabold leading-none">1925</span>
              </div>
            </div>
          </div>

          {/* Letter & Philosophy */}
          <div className="lg:col-span-7 space-y-6">
            <div className="relative pl-6 border-l-4 border-[#C5A85C] italic text-slate-800 text-lg font-serif-heading font-medium leading-relaxed">
              {isPersian
                ? '«در تانگلین، آموزش تنها کسب رتبه‌های درخشان در آزمون‌ها نیست؛ بلکه پرورش شخصیت‌های مستقل، اندیشمندان نقاد و انسان‌های باوجدانی است که به بهبود جهان متعهدند.»'
                : '“At Tanglin, education is not merely about outstanding examination certificates; it is about cultivating compassionate character, agile intellect, and inspiring young minds to lead with integrity.”'}
            </div>

            <div className="space-y-4 text-slate-600 text-sm sm:text-base leading-relaxed">
              <p>
                {isPersian
                  ? 'افتخار بزرگی است که به مدرسه تانگلین تراست خوش‌آمد می‌گویم؛ مدرسه‌ای پرجنب‌وجوش، پویا و منحصربه‌فرد که به مدت یک قرن است بستری امن و بالنده برای پرورش کودکان و نوجوانان در سنگاپور فراهم ساخته است.'
                  : 'It is my tremendous privilege to welcome you to Tanglin Trust School. As we celebrate our Centenary (1925–2025), we reflect on a remarkable heritage while continuing to innovate boldly for our students’ future.'}
              </p>

              <p>
                {isPersian
                  ? 'ما به عنوان تنها مدرسه در سنگاپور که هر دو مسیر تحصیلی دیپلم IB و آزمون‌های تخصصی A-Level را به دانش‌آموزان سال‌های پایانی ارائه می‌دهد، این آزادی را به فرزندانمان می‌دهیم تا مسیری را انتخاب نمایند که بهترین تطابق را با اهداف شغلی و دانشگاهی آنان در سراسر جهان دارد.'
                  : 'As the only school in Singapore offering a choice of both A-Levels and the IB Diploma in our Sixth Form, we empower each student to tailor their pre-university pathway to their unique passions and global university aspirations.'}
              </p>

              <p>
                {isPersian
                  ? 'محیط پردیس ما با افتتاح ساختمان مدرن ۱۱ طبقه صدمین سالگرد، استخر المپیک ۵۰ متری، دیواره صخره‌نوردی و سالن‌های پژوهش و هنر، تجربه‌ای بی‌مانند از زیست در یک آکادمی طراز اول جهانی را به تصویر می‌کشد.'
                  : 'Our teachers are world-class, our pastoral care is second to none, and our not-for-profit foundation guarantees that every ounce of tuition is reinvested directly into outstanding facilities and faculty.'}
              </p>
            </div>

            {/* CEO Signature Simulation */}
            <div className="pt-2 flex items-center justify-between border-t border-slate-200">
              <div>
                <div className="font-serif-heading font-bold text-base text-[#0F2537]">
                  Craig Considine
                </div>
                <div className="text-xs text-slate-500">
                  {isPersian ? 'مدیرعامل تانگلین تراست' : 'Chief Executive Officer'}
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold text-[#C5A85C] uppercase tracking-wider">
                  BSO Outstanding Accredited
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* Mission, Vision & Core Values Strip */}
        <div id="mission-values" className="mt-20 pt-12 border-t border-slate-200">
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-bold font-serif-heading text-[#0F2537]">
              {isPersian ? 'ارزش‌های بنیادین مدرسه تانگلین' : 'Our Core Values: Respect, Responsibility & Purpose'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              {isPersian
                ? 'سه اصل راهنما که هویت فرهنگی و اخلاقی جامعه ما را در قرن بیست‌ویکم شکل می‌دهند'
                : 'The foundational principles guiding every student, teacher, and leader at Tanglin'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {values.map((v, i) => (
              <div
                key={v.id}
                className="p-6 rounded-xl bg-slate-50 hover:bg-white hover:shadow-lg transition-all border border-slate-200 group"
              >
                <div className="w-12 h-12 rounded-lg bg-[#0F2537] text-[#C5A85C] flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  {i === 0 && <Heart className="w-6 h-6" />}
                  {i === 1 && <Shield className="w-6 h-6" />}
                  {i === 2 && <Sparkles className="w-6 h-6" />}
                </div>
                <h4 className="text-lg font-bold font-serif-heading text-[#0F2537]">
                  {isPersian ? v.titleFa : v.titleEn}
                </h4>
                <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {isPersian ? v.descriptionFa : v.descriptionEn}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
