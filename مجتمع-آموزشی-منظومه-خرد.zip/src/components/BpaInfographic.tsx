import React from 'react';
import { 
  Building2, 
  Globe2, 
  Briefcase, 
  GraduationCap, 
  Smile, 
  BookOpen, 
  Layers, 
  Award 
} from 'lucide-react';
import { statisticsData } from '../data/tanglinMainPageData';
import { Language } from '../types';

interface BpaInfographicProps {
  lang: Language;
}

export const BpaInfographic: React.FC<BpaInfographicProps> = ({ lang }) => {
  const getIcon = (iconType: string) => {
    switch (iconType) {
      case 'college':
        return <Building2 className="w-6 h-6 text-[#CE0E2D]" />;
      case 'globe':
        return <Globe2 className="w-6 h-6 text-[#CE0E2D]" />;
      case 'briefcase':
        return <Briefcase className="w-6 h-6 text-[#CE0E2D]" />;
      case 'apple':
        return <Award className="w-6 h-6 text-[#CE0E2D]" />;
      case 'backpack':
        return <Smile className="w-6 h-6 text-[#CE0E2D]" />;
      case 'bus':
        return <BookOpen className="w-6 h-6 text-[#CE0E2D]" />;
      case 'settings':
        return <Layers className="w-6 h-6 text-[#CE0E2D]" />;
      case 'grad':
      default:
        return <GraduationCap className="w-6 h-6 text-[#CE0E2D]" />;
    }
  };

  return (
    <section className="w-full bg-[#16216a] py-14 md:py-18 px-4 sm:px-8 border-b border-[#001744]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-[#f0b0bd] bg-white/10 px-3 py-1 rounded inline-block mb-3">
            {lang === 'fa' ? 'آمار کلیدی جامعه مدرسه' : 'Tanglin by the Numbers'}
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif-heading font-bold text-white tracking-tight">
            {lang === 'fa' ? 'تانگلین در یک نگاه' : 'Tanglin Key Facts & Statistics'}
          </h2>
          <p className="mt-2 text-slate-300 text-xs sm:text-sm">
            {lang === 'fa' 
              ? 'جامعه‌ای پویا از ۲٬۸۵۰ دانش‌آموز بین‌المللی با ۱۰۰ سال تجربه درخشان آموزش بریتانیایی در سنگاپور' 
              : 'A vibrant international community of 2,850 students with a century of academic distinction'}
          </p>
        </div>

        {/* The 8 Statistical Blocks (White cards with Crimson Numbers) */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {statisticsData.map((stat, idx) => (
            <div
              key={idx}
              className="bg-white rounded-lg p-5 sm:p-6 shadow-md border-t-4 border-[#CE0E2D] flex flex-col items-center text-center transition-transform hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="mb-2 p-2 rounded-full bg-[#fdf2f4]">
                {getIcon(stat.icon)}
              </div>
              <span className="text-3xl sm:text-4xl font-extrabold text-[#CE0E2D] tracking-tight font-sans">
                {stat.number}
              </span>
              <p className="mt-2 text-xs sm:text-sm font-bold text-[#002169] leading-snug">
                {lang === 'fa' ? stat.labelFa : stat.labelEn}
              </p>
            </div>
          ))}
        </div>

        {/* Footnote */}
        <div className="mt-6 text-center text-slate-300 text-xs italic">
          <span>{lang === 'fa' ? '(آمار مستند بر پایه سال تحصیلی ۲۰۲۳-۲۴)' : '(Numbers based on 2023-24 Academic Year)'}</span>
        </div>
      </div>
    </section>
  );
};
