import React from 'react';
import { Crest } from './Crest';
import { Language } from '../types';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Award, 
  ShieldCheck, 
  Globe2,
  ExternalLink,
  Heart
} from 'lucide-react';

interface FooterProps {
  lang: Language;
}

export const Footer: React.FC<FooterProps> = ({ lang }) => {
  const isPersian = lang === 'fa';

  const accreditations = [
    'British Schools Overseas (BSO) Outstanding',
    'PENTA International Verified',
    'IB World School Authorized',
    'Apple Distinguished School',
    'Cambridge Assessment International',
    'FOBISIA Member School',
    'HMC Accredited'
  ];

  return (
    <footer className="bg-[#08131F] text-slate-300 border-t-2 border-[#C5A85C]">
      {/* Upper Footer with Accreditation Badges */}
      <div className="border-b border-slate-800/80 py-8 bg-[#0B1B2B]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-xs font-bold text-[#C5A85C] uppercase tracking-widest mb-4">
            {isPersian ? 'استانداردها و اعتبارسنجی‌های بین‌المللی تانگلین' : 'Accreditations & Global Memberships'}
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-6 text-xs text-slate-400">
            {accreditations.map((acc, idx) => (
              <div
                key={idx}
                className="flex items-center gap-1.5 px-3 py-1 rounded bg-white/5 border border-white/10 hover:border-[#C5A85C]/50 transition-colors"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#C5A85C]" />
                <span>{acc}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          
          {/* Col 1: Crest & About */}
          <div className="lg:col-span-4 space-y-4">
            <Crest variant="light" lang={lang} />
            
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm pt-2">
              {isPersian
                ? 'مدرسه تانگلین تراست، کهن‌ترین مدرسه بین‌المللی با نظام آموزشی بریتانیا در جنوب شرق آسیا، از سال ۱۹۲۵ نسلی از دانش‌آموزان بااخلاق، اندیشمند و پیشگام را در سنگاپور تربیت می‌نماید.'
                : 'Established in 1925, Tanglin Trust School is the oldest British international school in Southeast Asia, cultivating compassionate learners, innovative minds, and future global leaders.'}
            </p>

            <div className="pt-2 text-xs text-slate-400 space-y-1.5">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#C5A85C] shrink-0" />
                <span>95 Portsdown Road, Singapore 139294</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#C5A85C] shrink-0" />
                <span>General: +65 6778 0044</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#C5A85C] shrink-0" />
                <span>admissions@tts.edu.sg</span>
              </div>
            </div>
          </div>

          {/* Col 2: The 4 Schools */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white font-serif-heading border-b border-slate-800 pb-2">
              {isPersian ? 'مقاطع تحصیلی' : 'Our Schools'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#schools" className="hover:text-[#C5A85C] transition-colors flex items-center justify-between">
                  <span>{isPersian ? 'مدرسه خردسالان (۳ تا ۷ سال)' : 'Infant School (Ages 3–7)'}</span>
                  <span className="text-[10px] text-slate-500">Nursery–Y2</span>
                </a>
              </li>
              <li>
                <a href="#schools" className="hover:text-[#C5A85C] transition-colors flex items-center justify-between">
                  <span>{isPersian ? 'مدرسه ابتدایی (۷ تا ۱۱ سال)' : 'Junior School (Ages 7–11)'}</span>
                  <span className="text-[10px] text-slate-500">Years 3–6</span>
                </a>
              </li>
              <li>
                <a href="#schools" className="hover:text-[#C5A85C] transition-colors flex items-center justify-between">
                  <span>{isPersian ? 'دبیرستان دوره اول (۱۱ تا ۱۶ سال)' : 'Senior School (Ages 11–16)'}</span>
                  <span className="text-[10px] text-slate-500">(I)GCSE</span>
                </a>
              </li>
              <li>
                <a href="#dual-pathway" className="hover:text-[#C5A85C] transition-colors flex items-center justify-between">
                  <span className="text-[#C5A85C] font-semibold">{isPersian ? 'کالج پیش‌دانشگاهی Sixth Form' : 'Sixth Form Dual Pathway'}</span>
                  <span className="text-[10px] text-slate-500">IB / A-Level</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: About & Admissions */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white font-serif-heading border-b border-slate-800 pb-2">
              {isPersian ? 'اطلاعات و پذیرش' : 'About & Admissions'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li><a href="#ceo-welcome" className="hover:text-white transition-colors">{isPersian ? 'پیام مدیرعامل و چشم‌انداز' : "Welcome from the CEO"}</a></li>
              <li><a href="#centenary" className="hover:text-white transition-colors">{isPersian ? 'جشن صد سالگی (۱۹۲۵–۲۰۲۵)' : 'Centenary Celebrations'}</a></li>
              <li><a href="#academics" className="hover:text-white transition-colors">{isPersian ? 'نتایج آزمون‌های نهایی و BSO' : 'Academic Results & BSO Report'}</a></li>
              <li><a href="#campus" className="hover:text-white transition-colors">{isPersian ? 'امکانات و ساختمان صدمین سالگرد' : 'Centenary Building & 50m Pool'}</a></li>
              <li><a href="#admissions-section" className="hover:text-white transition-colors">{isPersian ? 'مراحل ثبت‌نام و جدول شهریه‌ها' : 'Fees & Admissions Guidelines'}</a></li>
              <li><a href="#safeguarding" className="hover:text-white transition-colors">{isPersian ? 'حفاظت از کودکان و سلامت روان' : 'Safeguarding & Wellbeing'}</a></li>
            </ul>
          </div>

          {/* Col 4: Community & Portals */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white font-serif-heading border-b border-slate-800 pb-2">
              {isPersian ? 'پورتال‌ها و اعضا' : 'Community'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li><a href="#parent-portal" className="hover:text-white transition-colors">{isPersian ? 'پورتال اولیا' : 'Parent Portal'}</a></li>
              <li><a href="#student-portal" className="hover:text-white transition-colors">{isPersian ? 'پورتال دانش‌آموزان' : 'Student Portal'}</a></li>
              <li><a href="#staff-portal" className="hover:text-white transition-colors">{isPersian ? 'پورتال کارکنان' : 'Staff Portal'}</a></li>
              <li><a href="#alumni" className="hover:text-white transition-colors">{isPersian ? 'شبکه فارغ‌التحصیلان' : 'Tanglin Alumni'}</a></li>
              <li><a href="#careers" className="hover:text-white transition-colors">{isPersian ? 'فرصت‌های شغلی و استخدام' : 'Work at Tanglin'}</a></li>
              <li><a href="#giving" className="hover:text-white transition-colors">{isPersian ? 'بنیاد خیریه و نیکوکاری' : 'Tanglin Foundation'}</a></li>
            </ul>
          </div>

        </div>
      </div>

      {/* Bottom Legal & Charity Registration Bar */}
      <div className="border-t border-slate-800/80 py-6 bg-[#061019] text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <div>
              © 1925–2025 Tanglin Trust School Ltd • CPE Registration No. 196100114C (Period: 7 June 2023 to 6 June 2029)
            </div>
            <div className="text-[11px] text-slate-600 mt-1">
              Registered Charity in Singapore • 95 Portsdown Road, Singapore 139294
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <a href="#privacy" className="hover:text-slate-300 transition-colors">{isPersian ? 'حریم خصوصی' : 'Privacy Policy'}</a>
            <span>•</span>
            <a href="#terms" className="hover:text-slate-300 transition-colors">{isPersian ? 'قوانین و مقررات' : 'Terms & Conditions'}</a>
            <span>•</span>
            <a href="#sitemap" className="hover:text-slate-300 transition-colors">{isPersian ? 'نقشه سایت' : 'Sitemap'}</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
