import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  MapPin, 
  Navigation, 
  Phone, 
  Mail, 
  Clock, 
  Copy, 
  Check, 
  ExternalLink, 
  Bus, 
  Car, 
  Maximize2,
  Sparkles
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface KheradLocationSectionProps {
  onOpenTour?: () => void;
  onOpenAdmissions?: () => void;
}

export const KheradLocationSection: React.FC<KheradLocationSectionProps> = ({
  onOpenTour,
}) => {
  const { isPersian } = useLanguage();
  const [copied, setCopied] = useState(false);
  const [mapType, setMapType] = useState<'standard' | 'satellite'>('standard');
  const [showDirectionsMenu, setShowDirectionsMenu] = useState(false);

  // Exact coordinates of Kherad Educational Complex, Velenjak, Tehran
  const latitude = 35.80815;
  const longitude = 51.40485;

  const addressPersian = 'تهران، منطقه ۱، ولنجک، بلوار دانشجو، بالاتر از میدان یاسمن، مجتمع آموزشی و فرهنگی منظومه خرد';
  const addressEnglish = 'Kherad Educational Complex, Daneshjou Blvd, Above Yasaman Sq, Velenjak, District 1, Tehran, Iran';

  const handleCopyAddress = () => {
    const textToCopy = isPersian ? addressPersian : addressEnglish;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2400);
  };

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`;
  const googleDirectionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}`;
  const neshanUrl = `https://neshan.org/maps/@${latitude},${longitude},17z`;
  const baladUrl = `https://balad.ir/location?latitude=${latitude}&longitude=${longitude}`;
  const wazeUrl = `https://waze.com/ul?ll=${latitude},${longitude}&navigate=yes`;

  return (
    <section 
      id="kherad-location"
      className="w-full bg-[#EDEDF0] py-10 sm:py-12 px-4 sm:px-8 border-none font-persian overflow-hidden select-none"
      dir={isPersian ? 'rtl' : 'ltr'}
    >
      <div className="max-w-7xl mx-auto">
        {/* Compact Minimal Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6 border-b border-black/[0.08] pb-3">
          <div>
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 uppercase tracking-wider mb-1">
              <span className="w-1.5 h-1.5 rounded-none bg-[#0B82C6]" />
              <span>{isPersian ? 'موقعیت جغرافیایی و دسترسی' : 'Location & Access'}</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight font-serif-heading">
              {isPersian ? 'مجتمع آموزشی خرد (ولنجک)' : 'Kherad Educational Complex (Velenjak)'}
            </h2>
          </div>
          <p className="text-xs text-slate-600 max-w-md font-light leading-relaxed">
            {isPersian 
              ? 'ولنجک، بلوار دانشجو، بالاتر از میدان یاسمن • ۱۲٬۰۰۰ مترمربع فضای آموزشی نوین در ۷ طبقه'
              : 'Daneshjou Blvd, Velenjak • 12,000 m² modern pedagogical spaces across 7 specialized levels'}
          </p>
        </div>

        {/* Compact Grid: Map on Left (7 cols), Contact & Info on Right (5 cols) - All Sharp Corners (rounded-none) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
          
          {/* Map Viewport - Sharp corners rounded-none, lower volume */}
          <div className="lg:col-span-7 flex flex-col">
            <div className="relative w-full h-[280px] sm:h-[320px] lg:h-full min-h-[280px] rounded-none overflow-hidden border border-black/[0.1] shadow-none bg-slate-200">
              
              {/* Interactive OpenStreetMap Embed */}
              <iframe
                title={isPersian ? 'نقشه مجتمع منظومه خرد' : 'Kherad Campus Map'}
                src={`https://www.openstreetmap.org/export/embed.html?bbox=51.3980%2C35.8030%2C51.4110%2C35.8130&layer=${mapType === 'satellite' ? 'hot' : 'mapnik'}&marker=${latitude}%2C${longitude}`}
                className="w-full h-full border-0 filter contrast-[1.03] brightness-[0.98]"
                loading="lazy"
              />

              {/* Map Floating Header Overlay - Sharp corners rounded-none */}
              <div className="absolute top-2.5 inset-x-2.5 flex items-center justify-between pointer-events-none z-10">
                <div className="bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-none border border-black/[0.1] shadow-none flex items-center gap-2 pointer-events-auto">
                  <div className="w-5 h-5 rounded-none bg-[#112544] flex items-center justify-center text-white shrink-0">
                    <MapPin className="w-3 h-3 text-[#aeca26]" />
                  </div>
                  <div>
                    <h3 className="text-[11px] font-bold text-slate-900 leading-tight">
                      {isPersian ? 'مجتمع خرد ولنجک' : 'Kherad Complex'}
                    </h3>
                    <p className="text-[9.5px] text-slate-500 font-mono">
                      35.8081° N, 51.4048° E
                    </p>
                  </div>
                </div>

                {/* Layer Toggle - Sharp corners */}
                <div className="bg-white/95 backdrop-blur-md p-0.5 rounded-none border border-black/[0.1] flex items-center gap-0.5 pointer-events-auto">
                  <button
                    onClick={() => setMapType('standard')}
                    className={`px-2 py-0.5 text-[10px] font-medium rounded-none transition-colors cursor-pointer ${
                      mapType === 'standard' 
                        ? 'bg-[#112544] text-white' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isPersian ? 'نقشه' : 'Map'}
                  </button>
                  <button
                    onClick={() => setMapType('satellite')}
                    className={`px-2 py-0.5 text-[10px] font-medium rounded-none transition-colors cursor-pointer ${
                      mapType === 'satellite' 
                        ? 'bg-[#112544] text-white' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isPersian ? 'توپوگرافی' : 'Terrain'}
                  </button>
                </div>
              </div>

              {/* Map Fullscreen Link */}
              <div className="absolute bottom-2.5 right-2.5 flex flex-col gap-1 z-10">
                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-none bg-white/95 text-slate-800 hover:bg-[#112544] hover:text-white backdrop-blur-md border border-black/[0.1] transition-colors cursor-pointer flex items-center justify-center"
                  title={isPersian ? 'مشاهده در گوگل‌مپ تمام‌صفحه' : 'Open in Google Maps'}
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </a>
              </div>

              {/* Directions Button on Map - Sharp corners */}
              <div className="absolute bottom-2.5 left-2.5 z-10">
                <div className="relative">
                  <button
                    onClick={() => setShowDirectionsMenu(!showDirectionsMenu)}
                    className="flex items-center gap-1.5 bg-[#112544] hover:bg-[#0C1E38] text-white px-3 py-1.5 rounded-none font-medium text-[11px] transition-colors cursor-pointer border border-white/10 select-none shadow-sm"
                  >
                    <Navigation className="w-3.5 h-3.5 text-[#aeca26]" />
                    <span>{isPersian ? 'مسیریابی' : 'Directions'}</span>
                  </button>

                  {/* Dropdown Menu for Navigation Apps - Sharp corners */}
                  {showDirectionsMenu && (
                    <div className="absolute bottom-9 left-0 w-44 bg-white rounded-none shadow-md border border-black/[0.1] p-1 z-30 font-sans space-y-0.5">
                      <a
                        href={googleDirectionsUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between px-2.5 py-1.5 text-[11px] text-slate-700 hover:bg-slate-100 rounded-none transition-colors"
                      >
                        <span className="font-medium">Google Maps</span>
                        <ExternalLink className="w-3 h-3 text-slate-400" />
                      </a>
                      <a
                        href={neshanUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between px-2.5 py-1.5 text-[11px] text-slate-700 hover:bg-slate-100 rounded-none transition-colors font-persian"
                      >
                        <span className="font-medium">نشان (Neshan)</span>
                        <ExternalLink className="w-3 h-3 text-slate-400" />
                      </a>
                      <a
                        href={baladUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between px-2.5 py-1.5 text-[11px] text-slate-700 hover:bg-slate-100 rounded-none transition-colors font-persian"
                      >
                        <span className="font-medium">بلد (Balad)</span>
                        <ExternalLink className="w-3 h-3 text-slate-400" />
                      </a>
                      <a
                        href={wazeUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between px-2.5 py-1.5 text-[11px] text-slate-700 hover:bg-slate-100 rounded-none transition-colors"
                      >
                        <span className="font-medium">Waze</span>
                        <ExternalLink className="w-3 h-3 text-slate-400" />
                      </a>
                    </div>
                  )}
                </div>
              </div>

            </div>
          </div>

          {/* Contact Details & Access Directory - All Sharp Corners (rounded-none) & Compact */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-2.5">
            {/* 1. Official Address Card */}
            <div className="bg-white rounded-none p-3.5 border border-black/[0.08]">
              <div className="flex items-start justify-between gap-2.5">
                <div className="flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-none bg-[#112544]/10 text-[#112544] flex items-center justify-center shrink-0 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-[#0B82C6]" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      {isPersian ? 'نشانی مجتمع آموزشی خرد (ولنجک)' : 'Central Kherad Complex Address'}
                    </h3>
                    <p className="mt-0.5 text-[11px] text-slate-600 leading-relaxed font-light">
                      {isPersian ? addressPersian : addressEnglish}
                    </p>
                    <p className="mt-1 text-[10px] text-slate-400">
                      {isPersian ? 'کد پستی: ۱۹۸۴۱-۳۳۴۵۱' : 'Postal Code: 19841-33451'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleCopyAddress}
                  className="p-1.5 rounded-none text-slate-500 hover:text-[#112544] hover:bg-slate-100 transition-colors shrink-0 cursor-pointer"
                  title={isPersian ? 'کپی آدرس' : 'Copy Address'}
                  aria-label={isPersian ? 'کپی آدرس' : 'Copy address'}
                >
                  {copied ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>

              {copied && (
                <div className="mt-1 text-[10px] text-emerald-600 font-medium">
                  {isPersian ? '✓ آدرس کپی شد.' : '✓ Address copied.'}
                </div>
              )}
            </div>

            {/* 2. Direct Telephone Lines & Admissions */}
            <div className="bg-white rounded-none p-3.5 border border-black/[0.08] space-y-2">
              <div className="flex items-center gap-2 border-b border-black/[0.05] pb-1.5">
                <Phone className="w-3.5 h-3.5 text-[#0B82C6] shrink-0" />
                <h3 className="text-xs font-bold text-slate-900">
                  {isPersian ? 'خطوط ارتباط تلفنی و پذیرش' : 'Telephone Lines & Admissions'}
                </h3>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <a
                  href="tel:+982122170000"
                  className="p-2 rounded-none bg-slate-50 hover:bg-slate-100 transition-colors flex flex-col border border-black/[0.04]"
                >
                  <span className="text-[9.5px] text-slate-500">
                    {isPersian ? 'تلفنخانه مرکزی:' : 'Central Line:'}
                  </span>
                  <span className="font-semibold text-slate-800 text-[11px] mt-0.5" dir={isPersian ? 'rtl' : 'ltr'}>
                    {isPersian ? '۰۲۱-۲۲۱۷۰۰۰۰' : '+98 (21) 2217-0000'}
                  </span>
                </a>

                <a
                  href="tel:+982122170001"
                  className="p-2 rounded-none bg-slate-50 hover:bg-slate-100 transition-colors flex flex-col border border-black/[0.04]"
                >
                  <span className="text-[9.5px] text-slate-500">
                    {isPersian ? 'دفتر ثبت‌نام و پذیرش:' : 'Admissions:'}
                  </span>
                  <span className="font-semibold text-[#0B82C6] text-[11px] mt-0.5" dir={isPersian ? 'rtl' : 'ltr'}>
                    {isPersian ? '۰۲۱-۲۲۱۷۰۰۰۱' : '+98 (21) 2217-0001'}
                  </span>
                </a>
              </div>

              <div className="flex items-center justify-between pt-0.5 text-[10.5px] text-slate-500">
                <span className="flex items-center gap-1.5">
                  <Mail className="w-3 h-3 text-[#0B82C6]" />
                  <a href="mailto:info@kheradedu.ir" className="hover:underline">info@kheradedu.ir</a>
                </span>
                <span>{isPersian ? 'سامانه پیامک: ۳۰۰۰۲۲۱۷' : 'SMS: 30002217'}</span>
              </div>
            </div>

            {/* 3. Working Hours & Transit */}
            <div className="bg-white rounded-none p-3.5 border border-black/[0.08] space-y-2">
              <div className="flex items-center justify-between border-b border-black/[0.05] pb-1.5">
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#0B82C6]" />
                  <h3 className="text-xs font-bold text-slate-900">
                    {isPersian ? 'ساعات اداری و پذیرش' : 'Working Hours'}
                  </h3>
                </div>
                <span className="text-[9.5px] font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded-none">
                  {isPersian ? 'شنبه تا پنج‌شنبه' : 'Sat – Thu'}
                </span>
              </div>

              <p className="text-[11px] text-slate-600 font-light leading-relaxed">
                {isPersian
                  ? 'شنبه تا چهارشنبه: ۷:۳۰ الی ۱۵:۳۰ | پنج‌شنبه‌ها: ۸:۰۰ الی ۱۲:۰۰'
                  : 'Saturday to Wednesday: 07:30 – 15:30 | Thursdays: 08:00 – 12:00'}
              </p>

              <div className="pt-1.5 border-t border-black/[0.04] flex items-center justify-between text-[10px] text-slate-500">
                <span className="flex items-center gap-1">
                  <Bus className="w-3 h-3 text-slate-400 shrink-0" />
                  <span>{isPersian ? 'تاکسی و اتوبوس پایانه تجریش' : 'Tajrish Terminal'}</span>
                </span>
                <span className="flex items-center gap-1">
                  <Car className="w-3 h-3 text-slate-400 shrink-0" />
                  <span>{isPersian ? 'پارکینگ اختصاصی مراجعین' : 'Visitor Parking'}</span>
                </span>
              </div>
            </div>

            {/* 4. Action Buttons - Sharp Corners (rounded-none) */}
            <div className="flex items-center gap-2 pt-0.5">
              <a
                href={googleDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 px-3 rounded-none bg-[#112544] hover:bg-[#0C1E38] text-white text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer select-none"
              >
                <Navigation className="w-3.5 h-3.5 text-[#aeca26]" />
                <span>{isPersian ? 'مسیریابی آنلاین' : 'Get Directions'}</span>
                <ExternalLink className="w-3 h-3 text-white/70" />
              </a>

              {onOpenTour && (
                <button
                  onClick={onOpenTour}
                  className="py-2 px-3 rounded-none bg-white hover:bg-slate-100 text-[#112544] text-[11px] font-medium border border-black/[0.1] flex items-center justify-center gap-1.5 transition-colors cursor-pointer select-none"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#0B82C6]" />
                  <span>{isPersian ? 'گشت ۳۶۰°' : '360° Tour'}</span>
                </button>
              )}
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
