import React from 'react';
import { latestNews } from '../data/tanglinData';
import { Language } from '../types';
import { Newspaper, Calendar, Clock, ArrowRight } from 'lucide-react';

interface NewsSectionProps {
  lang: Language;
}

export const NewsSection: React.FC<NewsSectionProps> = ({ lang }) => {
  const isPersian = lang === 'fa';

  return (
    <section className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0F2537]/5 text-[#0F2537] text-xs font-bold uppercase tracking-widest mb-3">
              <Newspaper className="w-3.5 h-3.5 text-[#C5A85C]" />
              <span>{isPersian ? 'اخبار و رویدادهای تانگلین' : 'Latest Stories & Centenary News'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold font-serif-heading text-[#0F2537]">
              {isPersian ? 'روایت‌های جاری از جامعه پویا تانگلین' : 'Stories from Our Community'}
            </h2>
          </div>

          <a
            href="#all-news"
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-[#0F2537] hover:text-[#C5A85C] transition-colors"
          >
            <span>{isPersian ? 'مشاهده تمام اخبار و مقالات' : 'View All School News'}</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {latestNews.map((news) => (
            <div
              key={news.id}
              className="bg-white rounded-xl overflow-hidden border border-slate-200 hover:border-[#C5A85C] shadow-sm hover:shadow-xl transition-all group flex flex-col justify-between"
            >
              <div>
                <div className="h-48 overflow-hidden relative">
                  <img
                    src={news.image}
                    alt={news.titleEn}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md text-[11px] font-bold bg-[#0F2537]/90 text-[#C5A85C] border border-[#C5A85C]/30 backdrop-blur-sm">
                    {news.category}
                  </span>
                </div>

                <div className="p-5">
                  <div className="flex items-center gap-3 text-xs text-slate-400 mb-2">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-[#C5A85C]" />
                      {news.date}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-[#C5A85C]" />
                      {news.readTime}
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-bold font-serif-heading text-[#0F2537] group-hover:text-[#C5A85C] transition-colors line-clamp-2">
                    {isPersian ? news.titleFa : news.titleEn}
                  </h3>

                  <p className="mt-2 text-xs sm:text-sm text-slate-600 line-clamp-3 leading-relaxed">
                    {isPersian ? news.summaryFa : news.summaryEn}
                  </p>
                </div>
              </div>

              <div className="p-5 pt-0">
                <span className="inline-flex items-center gap-1 text-xs font-bold text-[#0F2537] group-hover:text-[#C5A85C] transition-colors">
                  <span>{isPersian ? 'مطالعه متن کامل' : 'Read Story'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
