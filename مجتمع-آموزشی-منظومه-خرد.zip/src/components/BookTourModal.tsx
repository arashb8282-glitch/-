import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  CheckCircle2, 
  User, 
  Mail, 
  Phone, 
  GraduationCap, 
  Clock, 
  Building, 
  FileText,
  Sparkles
} from 'lucide-react';
import { Language } from '../types';

interface BookTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const BookTourModal: React.FC<BookTourModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  if (!isOpen) return null;

  const isPersian = lang === 'fa';
  const [submitted, setSubmitted] = useState(false);
  const [tourType, setTourType] = useState<'in-person' | 'virtual'>('in-person');
  const [schoolStage, setSchoolStage] = useState('senior');
  const [parentName, setParentName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [preferredDate, setPreferredDate] = useState('2025-04-15');
  const [timeSlot, setTimeSlot] = useState('09:30 AM');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!parentName || !email) return;
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="bg-[#0F2537] text-white p-5 flex items-center justify-between border-b border-[#C5A85C]/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#C5A85C] text-[#0F2537] flex items-center justify-center font-bold">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-bold text-[#C5A85C] uppercase tracking-wider">
                {isPersian ? 'پذیرش و بازدید از مدرسه' : 'Tanglin Admissions & Visits'}
              </div>
              <h3 className="text-lg font-bold font-serif-heading">
                {isPersian ? 'رزرو تور حضوری یا مشاوره تحصیلی' : 'Book a Campus Visit'}
              </h3>
            </div>
          </div>

          <button
            id="book-tour-close-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto">
          {submitted ? (
            <div className="py-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="text-2xl font-bold font-serif-heading text-[#0F2537]">
                {isPersian ? 'درخواست بازدید شما با موفقیت ثبت شد' : 'Visit Request Confirmed!'}
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
                {isPersian
                  ? `از ابراز علاقه شما سپاسگزاریم، جناب/سرکار خانم ${parentName}. جزئیات زمان‌بندی بازدید برای تاریخ ${preferredDate} در ساعت ${timeSlot} به ایمیل ${email} ارسال شد.`
                  : `Thank you, ${parentName}. Your visit request for ${preferredDate} at ${timeSlot} has been registered. An admissions officer has dispatched the confirmation package to ${email}.`}
              </p>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-left text-xs text-slate-700 space-y-1.5 max-w-sm mx-auto">
                <div className="flex justify-between">
                  <span className="text-slate-500">{isPersian ? 'کد رهگیری:' : 'Booking Reference:'}</span>
                  <span className="font-bold text-[#0F2537]">TTS-VISIT-2025-884</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{isPersian ? 'محل برگزاری:' : 'Location:'}</span>
                  <span className="font-semibold text-slate-800">Portsdown Road, Singapore</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{isPersian ? 'مقطع مورد نظر:' : 'School Stage:'}</span>
                  <span className="font-semibold text-[#C5A85C] uppercase">{schoolStage}</span>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleReset}
                  className="px-6 py-2.5 rounded-lg bg-[#0F2537] text-white font-bold text-xs sm:text-sm hover:bg-[#162E4A] transition-colors"
                >
                  {isPersian ? 'بستن پنجره' : 'Done & Return'}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Tour Format */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {isPersian ? 'نوع بازدید:' : 'Visit Format:'}
                </label>
                <div className="p-1 bg-[#EBEDF0] rounded-full border border-black/[0.04] inline-flex w-full">
                  <button
                    type="button"
                    onClick={() => setTourType('in-person')}
                    className={`flex-1 py-2 px-3 rounded-full text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      tourType === 'in-person'
                        ? 'bg-[#1D1D1F] text-white shadow-xs'
                        : 'text-[#1D1D1F]/80 hover:text-[#1D1D1F]'
                    }`}
                  >
                    <Building className="w-3.5 h-3.5 text-[#C5A85C]" />
                    <span>{isPersian ? 'تور حضوری در پردیس' : 'In-Person Campus Tour'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTourType('virtual')}
                    className={`flex-1 py-2 px-3 rounded-full text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      tourType === 'virtual'
                        ? 'bg-[#1D1D1F] text-white shadow-xs'
                        : 'text-[#1D1D1F]/80 hover:text-[#1D1D1F]'
                    }`}
                  >
                    <Clock className="w-3.5 h-3.5 text-[#C5A85C]" />
                    <span>{isPersian ? 'مشاوره آنلاین تصویری' : 'Online Video Consult'}</span>
                  </button>
                </div>
              </div>

              {/* School Stage */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {isPersian ? 'مقطع تحصیلی مد نظر:' : 'School Level of Interest:'}
                </label>
                <select
                  value={schoolStage}
                  onChange={(e) => setSchoolStage(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-full border border-slate-300 text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0F2537] bg-white cursor-pointer"
                >
                  <option value="infant">{isPersian ? 'مدرسه خردسالان (سنین ۳ تا ۷ سال)' : 'Infant School (Ages 3–7, Nursery to Year 2)'}</option>
                  <option value="junior">{isPersian ? 'مدرسه کودکان (سنین ۷ تا ۱۱ سال)' : 'Junior School (Ages 7–11, Years 3 to 6)'}</option>
                  <option value="senior">{isPersian ? 'دبیرستان دوره اول (سنین ۱۱ تا ۱۶ سال)' : 'Senior School (Ages 11–16, Years 7 to 11)'}</option>
                  <option value="sixth-form">{isPersian ? 'کالج پیش‌دانشگاهی Sixth Form (دوره‌های IB یا A-Level)' : 'Sixth Form (Ages 16–18, Dual Pathway IB/A-Level)'}</option>
                </select>
              </div>

              {/* Date & Time Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {isPersian ? 'تاریخ مورد نظر:' : 'Preferred Date:'}
                  </label>
                  <input
                    type="date"
                    value={preferredDate}
                    onChange={(e) => setPreferredDate(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-full border border-slate-300 text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-[#0F2537]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {isPersian ? 'ساعت بازدید:' : 'Preferred Time Slot:'}
                  </label>
                  <select
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-full border border-slate-300 text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-[#0F2537] bg-white cursor-pointer"
                  >
                    <option value="09:30 AM">09:30 AM (Morning Session)</option>
                    <option value="11:30 AM">11:30 AM (Mid-day Session)</option>
                    <option value="02:00 PM">02:00 PM (Afternoon Session)</option>
                  </select>
                </div>
              </div>

              {/* Parent Details */}
              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {isPersian ? 'نام و نام خانوادگی والد / سرپرست:' : 'Parent / Guardian Full Name:'}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      placeholder={isPersian ? 'مثال: علی احمدی' : 'e.g. Dr. Arthur Pendelton'}
                      value={parentName}
                      onChange={(e) => setParentName(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-full border border-slate-300 text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-[#0F2537]"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      {isPersian ? 'پست الکترونیکی:' : 'Email Address:'}
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="email"
                        placeholder="parent@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 rounded-full border border-slate-300 text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-[#0F2537]"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      {isPersian ? 'شماره تماس:' : 'Contact Phone Number:'}
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="tel"
                        placeholder="+65 9123 4567"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 rounded-full border border-slate-300 text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-[#0F2537]"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full py-3 rounded-lg bg-[#0F2537] hover:bg-[#162E4A] text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <Calendar className="w-4 h-4 text-[#C5A85C]" />
                  <span>{isPersian ? 'تایید و ثبت رزرو نهایی' : 'Confirm Tour Booking'}</span>
                </button>
              </div>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
