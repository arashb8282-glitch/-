import React from 'react';
import { keyStats } from '../data/tanglinData';
import { Language } from '../types';
import { Award, BookOpen, Users, Compass, Globe2, ShieldCheck } from 'lucide-react';

interface StatsBannerProps {
  lang: Language;
}

export const StatsBanner: React.FC<StatsBannerProps> = ({ lang }) => {
  const isPersian = lang === 'fa';

  const icons = [
    <Award className="w-6 h-6 text-[#C5A85C]" key="1" />,
    <Users className="w-6 h-6 text-[#C5A85C]" key="2" />,
    <BookOpen className="w-6 h-6 text-[#C5A85C]" key="3" />,
    <Compass className="w-6 h-6 text-[#C5A85C]" key="4" />,
    <ShieldCheck className="w-6 h-6 text-[#C5A85C]" key="5" />,
    <Globe2 className="w-6 h-6 text-[#C5A85C]" key="6" />,
  ];

  return (
    <section className="relative z-20 -mt-2 bg-gradient-to-b from-[#0F2537] to-[#162E4A] text-white py-12 border-b border-[#C5A85C]/20 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {keyStats.map((stat, idx) => (
            <div
              key={idx}
              className="flex flex-col items-center text-center p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-all border border-white/10 hover:border-[#C5A85C]/40 group"
            >
              <div className="p-2.5 rounded-full bg-white/5 mb-3 group-hover:scale-110 transition-transform">
                {icons[idx]}
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-[#C5A85C] font-serif-heading">
                {stat.value}
              </div>
              <div className="text-xs font-bold text-white mt-1 leading-tight">
                {isPersian ? stat.labelFa : stat.labelEn}
              </div>
              <div className="text-[11px] text-slate-300 mt-1.5 leading-snug font-light">
                {isPersian ? stat.detailFa : stat.detailEn}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
