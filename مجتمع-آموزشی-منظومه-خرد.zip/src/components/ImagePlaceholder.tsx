import React from 'react';
import { Image as ImageIcon, Building, GraduationCap, Palette, Trophy, BookOpen } from 'lucide-react';

interface ImagePlaceholderProps {
  label: string;
  category?: string;
  dimensionText?: string;
  aspectRatio?: '16/9' | '21/9' | '4/3' | '1/1' | '16/10';
  iconType?: 'campus' | 'education' | 'art' | 'award' | 'book' | 'general';
  className?: string;
}

export const ImagePlaceholder: React.FC<ImagePlaceholderProps> = ({
  label,
  category = 'تصویر مستند خرد',
  dimensionText = 'Placeholder',
  aspectRatio = '16/9',
  iconType = 'general',
  className = ''
}) => {
  const getAspectClass = () => {
    switch (aspectRatio) {
      case '21/9':
        return 'aspect-[21/9]';
      case '4/3':
        return 'aspect-[4/3]';
      case '1/1':
        return 'aspect-square';
      case '16/10':
        return 'aspect-[16/10]';
      case '16/9':
      default:
        return 'aspect-[16/9]';
    }
  };

  const renderIcon = () => {
    const props = { className: 'w-6 h-6 stroke-[1.4] text-slate-400 group-hover:text-[#2A6AB2] transition-colors' };
    switch (iconType) {
      case 'campus':
        return <Building {...props} />;
      case 'education':
        return <GraduationCap {...props} />;
      case 'art':
        return <Palette {...props} />;
      case 'award':
        return <Trophy {...props} />;
      case 'book':
        return <BookOpen {...props} />;
      default:
        return <ImageIcon {...props} />;
    }
  };

  return (
    <div
      className={`relative w-full ${getAspectClass()} bg-[#F5F5F7] rounded-2xl overflow-hidden border border-black/[0.05] flex flex-col items-center justify-center p-4 text-center select-none group ${className}`}
      dir="rtl"
    >
      {/* Subtle Apple-style dotted grid */}
      <div 
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#000000 1px, transparent 1px)`,
          backgroundSize: '16px 16px'
        }}
      />

      {/* Top corner category badge in Apple Pill */}
      <div className="absolute top-3 right-3 flex items-center gap-1.5 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[11px] font-semibold text-slate-700 shadow-2xs border border-black/[0.05]">
        <span className="w-1.5 h-1.5 rounded-full bg-[#2A6AB2]" />
        <span>{category}</span>
      </div>

      {/* Dimension text in corner */}
      {dimensionText && (
        <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md text-white/90 text-[10px] font-mono px-2.5 py-0.5 rounded-full shadow-2xs">
          {dimensionText}
        </div>
      )}

      {/* Center content */}
      <div className="relative z-10 flex flex-col items-center space-y-2 max-w-[85%]">
        <div className="p-3 bg-white rounded-full shadow-2xs border border-black/[0.05] group-hover:border-[#2A6AB2]/30 transition-colors">
          {renderIcon()}
        </div>
        <p className="text-xs sm:text-sm font-semibold text-slate-800 leading-snug font-persian">
          {label}
        </p>
        <span className="text-[10px] text-slate-400 font-light font-mono">
          [ تصویر جایگزین - Placeholder ]
        </span>
      </div>
    </div>
  );
};
