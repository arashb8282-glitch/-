import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUp } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const KheradScrollToTop: React.FC = () => {
  const { isPersian } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Appears when the user scrolls past the hero banner
      const heroThreshold = window.innerHeight * 0.85;
      if (window.scrollY > heroThreshold) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          key="scroll-to-top"
          initial={{ opacity: 0, scale: 0.8, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 12 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          onClick={scrollToTop}
          className="fixed bottom-6 left-6 sm:bottom-8 sm:left-8 z-30 w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-[#112544] hover:bg-[#0C1E38] active:bg-[#071426] text-white shadow-[0_6px_24px_rgba(17,37,68,0.4)] border border-white/20 flex items-center justify-center cursor-pointer transition-all duration-200 hover:scale-105 active:scale-95 group focus:outline-none"
          title={isPersian ? 'بازگشت به بالای صفحه' : 'Scroll to top'}
          aria-label={isPersian ? 'بازگشت به بالای صفحه' : 'Scroll to top'}
        >
          <ArrowUp className="w-5 h-5 sm:w-5.5 sm:h-5.5 stroke-[2] transition-transform duration-200 group-hover:-translate-y-0.5 text-white" />
        </motion.button>
      )}
    </AnimatePresence>
  );
};
