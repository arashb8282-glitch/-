import React from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface KheradPillarsGridProps {
  onSelectPillar: (id: string) => void;
}

export const KheradPillarsGrid: React.FC<KheradPillarsGridProps> = ({ onSelectPillar }) => {
  const { t, isPersian } = useLanguage();

  const pillarImages: Record<string, string> = {
    'mission-vision': '/assets/kherad-brand/photos/43.webp',
    'history': '/assets/kherad-brand/photos/44.webp',
    'results': '/assets/kherad-brand/photos/4.webp',
    'culture-art': '/assets/kherad-brand/photos/10.webp',
    'campus': '/assets/kherad-brand/photos/20.webp',
    'management': '/assets/kherad-brand/photos/6.webp',
  };

  const ArrowIcon = isPersian ? ArrowLeft : ArrowRight;

  return (
    <section id="pillars-section" className="w-full bg-white py-16 md:py-24 px-4 sm:px-8 border-b border-black/[0.05] font-persian overflow-hidden" dir={isPersian ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-3xl mx-auto mb-14"
        >
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif-heading font-bold text-slate-900 tracking-tight">
            {t.pillars.title}
          </h2>
          <p className="mt-3 text-slate-500 text-xs sm:text-sm leading-relaxed font-light">
            {t.pillars.subtitle}
          </p>
        </motion.div>

        {/* 6 Cards Grid with Repository Authentic Photos - Sharp architectural corners */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {t.pillars.items.map((pillar, index) => {
            const photoUrl = pillarImages[pillar.id] || '/assets/photos/mission-vision.jpg';
            return (
              <motion.div
                key={pillar.id}
                initial={{ opacity: 0, y: 32 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.75, delay: (index % 3) * 0.1, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{ y: -4, transition: { duration: 0.25, ease: 'easeOut' } }}
                className="bg-[#F5F5F7] rounded-none overflow-hidden shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_16px_40px_rgba(0,0,0,0.07)] transition-shadow flex flex-col border border-black/[0.06] group"
              >
                {/* Authentic Repository Photo */}
                <div className="p-3 bg-white/60 border-b border-black/[0.04]">
                  <div className="relative overflow-hidden aspect-[16/10] rounded-none bg-slate-200">
                    <img
                      src={photoUrl}
                      alt={pillar.title}
                      className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500 rounded-none"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent pointer-events-none" />
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <span className="text-[11px] font-semibold text-[#2A6AB2] block">
                      {pillar.subtitle}
                    </span>
                    <h3 className="text-lg sm:text-xl font-bold text-slate-900 group-hover:text-[#2A6AB2] transition-colors font-serif-heading">
                      {pillar.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-light">
                      {pillar.desc}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-black/[0.05]">
                    <motion.button
                      whileTap={{ scale: 0.98 }}
                      onClick={() => onSelectPillar(pillar.id)}
                      className="w-full inline-flex items-center justify-center gap-2 bg-[#282C34] hover:bg-[#1c1f26] text-white border border-transparent text-xs sm:text-sm font-semibold py-2.5 px-4 rounded-none transition-all duration-200 shadow-2xs hover:shadow-md cursor-pointer group"
                    >
                      <span className="text-white">{pillar.btnText}</span>
                      <ArrowIcon className={`w-4 h-4 stroke-[1.5] text-white transition-transform ${isPersian ? 'group-hover:-translate-x-1' : 'group-hover:translate-x-1'}`} />
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
