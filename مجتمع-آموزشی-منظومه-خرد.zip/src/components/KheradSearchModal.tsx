import React, { useState, useMemo } from 'react';
import { X, Search, ArrowLeft, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { sitemapData, topSystemLinks } from '../data/kheradSitemap';
import { useLanguage } from '../context/LanguageContext';

interface KheradSearchModalProps {
  isOpen: boolean;
  initialQuery?: string;
  onClose: () => void;
  onSelectResult: (categoryId: string, subItemId?: string) => void;
}

export const KheradSearchModal: React.FC<KheradSearchModalProps> = ({
  isOpen,
  initialQuery = '',
  onClose,
  onSelectResult
}) => {
  const { isPersian } = useLanguage();
  const [query, setQuery] = useState(initialQuery);

  // Flatten all items for search
  const allSearchableItems = useMemo(() => {
    const list: {
      categoryId: string;
      categoryTitle: string;
      categoryEnTitle: string;
      subItemId?: string;
      title: string;
      description?: string;
      type: string;
    }[] = [];

    // Add main categories
    sitemapData.forEach((cat) => {
      list.push({
        categoryId: cat.id,
        categoryTitle: cat.title,
        categoryEnTitle: cat.englishTitle,
        title: isPersian ? cat.title : cat.englishTitle,
        description: cat.summary,
        type: isPersian ? 'بخش اصلی' : 'Main Section'
      });

      // Add sub-items
      cat.subItems.forEach((sub) => {
        list.push({
          categoryId: cat.id,
          categoryTitle: cat.title,
          categoryEnTitle: cat.englishTitle,
          subItemId: sub.id,
          title: sub.title,
          description: sub.description || `${cat.title} - ${sub.category || ''}`,
          type: sub.category || (isPersian ? 'زیرمجموعه' : 'Sub-category')
        });
      });
    });

    return list;
  }, [isPersian]);

  const filteredResults = useMemo(() => {
    if (!query.trim()) return allSearchableItems.slice(0, 10);
    const q = query.trim().toLowerCase();
    return allSearchableItems.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.categoryTitle.toLowerCase().includes(q) ||
        item.categoryEnTitle.toLowerCase().includes(q) ||
        (item.description && item.description.toLowerCase().includes(q))
    );
  }, [query, allSearchableItems]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-start justify-center p-4 sm:p-8 pt-16 sm:pt-20 font-persian" dir={isPersian ? 'rtl' : 'ltr'}>
          {/* Backdrop with Apple-style soft blur */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Search Spotlight Modal */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.96, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -10 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-2xl bg-white/95 backdrop-blur-2xl rounded-3xl shadow-[0_24px_80px_rgba(0,0,0,0.18)] overflow-hidden flex flex-col border border-black/[0.08] z-10"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Search Input Bar */}
            <div className="flex items-center px-6 py-4.5 border-b border-black/[0.06] gap-3">
              <Search className="w-5 h-5 text-slate-400 stroke-[1.5]" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={isPersian ? 'جستجو در تمام بخش‌های منظومه خرد...' : 'Search across all sections of Kherad...'}
                className="w-full bg-transparent text-slate-900 placeholder-slate-400 text-sm sm:text-base font-medium focus:outline-none"
              />
              {query && (
                <button
                  onClick={() => setQuery('')}
                  className="text-xs text-slate-400 hover:text-slate-600 px-2.5 py-1 rounded-full bg-black/[0.04] hover:bg-black/[0.08] transition-colors cursor-pointer"
                >
                  {isPersian ? 'پاک کردن' : 'Clear'}
                </button>
              )}
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-[#F5F5F7] hover:bg-[#EBECEF] text-slate-700 flex items-center justify-center transition-colors shrink-0 cursor-pointer"
                aria-label={isPersian ? 'بستن' : 'Close'}
              >
                <X className="w-4 h-4 stroke-[1.5]" />
              </button>
            </div>

            {/* Quick Links Suggestions */}
            <div className="bg-[#F5F5F7]/80 px-6 py-2.5 border-b border-black/[0.04] flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
              <span className="font-semibold text-slate-700">
                {isPersian ? 'دسترسی سریع:' : 'Quick links:'}
              </span>
              {topSystemLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    onSelectResult(link.id);
                    onClose();
                  }}
                  className="hover:text-[#2A6AB2] px-2.5 py-0.5 rounded-full bg-white/80 border border-black/[0.04] transition-colors cursor-pointer"
                >
                  {link.title}
                </button>
              ))}
            </div>

            {/* Results List */}
            <div className="max-h-[60vh] overflow-y-auto p-4 sm:p-5 space-y-1.5">
              {filteredResults.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-sm">
                  {isPersian ? 'موردی مطابق با عبارت جستجوی شما یافت نشد.' : 'No results found matching your query.'}
                </div>
              ) : (
                filteredResults.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      onSelectResult(item.categoryId, item.subItemId);
                      onClose();
                    }}
                    className="w-full text-right p-3.5 rounded-2xl hover:bg-[#F5F5F7] border border-transparent hover:border-black/[0.05] transition-all flex items-center justify-between group cursor-pointer"
                  >
                    <div className="space-y-0.5 text-right">
                      <div className="flex items-center gap-2">
                        <span className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-[#2A6AB2] transition-colors">
                          {item.title}
                        </span>
                        <span className="text-[10px] bg-black/[0.04] text-slate-600 px-2 py-0.5 rounded-full">
                          {item.type}
                        </span>
                      </div>
                      {item.description && (
                        <p className="text-xs text-slate-500 line-clamp-1 font-light">
                          {item.description}
                        </p>
                      )}
                    </div>
                    {isPersian ? (
                      <ArrowLeft className="w-4 h-4 stroke-[1.5] text-slate-300 group-hover:text-[#2A6AB2] group-hover:-translate-x-1 transition-all" />
                    ) : (
                      <ArrowRight className="w-4 h-4 stroke-[1.5] text-slate-300 group-hover:text-[#2A6AB2] group-hover:translate-x-1 transition-all" />
                    )}
                  </button>
                ))
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
