import React, { useState } from 'react';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface KheradCampusModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const KheradCampusModal: React.FC<KheradCampusModalProps> = ({ isOpen, onClose }) => {
  const { isPersian } = useLanguage();
  const [activeFloor, setActiveFloor] = useState(4);

  if (!isOpen) return null;

  const floors = [
    {
      level: 7,
      nameFa: 'طبقه هفتم: تالار همایش‌ها و استودیوی تولید محتوا',
      nameEn: '7th Floor: Auditorium & Digital Media Studio',
      specsFa: 'سالن آمفی‌تئاتر ۳۵۰ نفره مجهز به سیستم صوت و نور حرفه‌ای، اتاق فرمان، استودیوی ضبط پادکست و تولید محتوای دیجیتال',
      specsEn: '350-seat amphitheater with professional acoustics and lighting, podcast recording studio, and digital media production lab',
      image: '/assets/photos/history.jpg',
      categoryFa: 'تالار همایش و رسانه',
      categoryEn: 'Auditorium & Media'
    },
    {
      level: 6,
      nameFa: 'طبقه ششم: مجتمع آموزشی خرد - هنرستان دخترانه',
      nameEn: '6th Floor: Kherad Vocational & Arts Campus',
      specsFa: 'آتلیه‌های طراحی نور طبیعی، کارگاه چاپ دستی، استودیوی عکاسی تاریک‌خانه و دیجیتال، آتلیه انیمیشن و کتابخانه تخصصی هنر',
      specsEn: 'Natural light design ateliers, printmaking studio, darkroom and digital photography studios, animation lab, and specialized art library',
      image: '/assets/photos/sixth-form.jpg',
      categoryFa: 'کارگاه‌های هنری',
      categoryEn: 'Art Studios'
    },
    {
      level: 5,
      nameFa: 'طبقه پنجم: متوسطه دوره دوم (پایه‌های ۱۰ تا ۱۲)',
      nameEn: '5th Floor: Senior High School (Grades 10–12)',
      specsFa: 'کلاس‌های مجهز به نمایشگرهای تعاملی، سالن مطالعه اختصاصی کنکور، آزمایشگاه‌های پیشرفته شیمی، سنتز نانو و زیست‌شناسی سلولی',
      specsEn: 'Interactive classrooms, dedicated study hall, and advanced biology, chemistry, and nano-synthesis laboratories',
      image: '/assets/photos/academic-results.jpg',
      categoryFa: 'فضای دبیرستان',
      categoryEn: 'High School Wing'
    },
    {
      level: 4,
      nameFa: 'طبقه چهارم: متوسطه دوره اول (پایه‌های ۷ تا ۹)',
      nameEn: '4th Floor: Middle School (Grades 7–9)',
      specsFa: 'آزمایشگاه علوم فیزیک و مکانیک، کارگاه رباتیک و هوش مصنوعی، کلاس‌های زبان تخصصی و اتاق مشاوره فردی و هدایت تحصیلی',
      specsEn: 'Physics and mechanics laboratory, robotics and AI workshops, specialized language classrooms, and student counseling rooms',
      image: '/assets/photos/inspections-awards.jpg',
      categoryFa: 'پژوهش و رباتیک',
      categoryEn: 'Robotics & Science'
    },
    {
      level: 3,
      nameFa: 'طبقه سوم: دبستان خرد - دوره دوم (پایه‌های ۴ تا ۶)',
      nameEn: '3rd Floor: Upper Elementary School (Grades 4–6)',
      specsFa: 'کلاس‌های موضوعی ریاضی و فارسی، آزمایشگاه علوم تجربی کودک، باشگاه کتابخوانی و اتاق پژوهش و انجمن‌های علمی دانش‌آموزی',
      specsEn: 'Subject-specific classrooms, child science lab, reading club and student research society spaces',
      image: '/assets/photos/junior-school.jpg',
      categoryFa: 'آموزش ابتدایی',
      categoryEn: 'Upper Elementary'
    },
    {
      level: 2,
      nameFa: 'طبقه دوم: دبستان خرد - دوره اول (پایه‌های ۱ تا ۳)',
      nameEn: '2nd Floor: Lower Elementary School (Grades 1–3)',
      specsFa: 'فضاهای یادگیری تعاملی، میزهای گروهی ارگونومیک، کارگاه دست‌ورزی و تقویت مهارت‌های حرکتی و زنگ علوم حسی',
      specsEn: 'Interactive learning spaces, ergonomic group tables, hands-on workshop for sensory development',
      image: '/assets/photos/junior-school.jpg',
      categoryFa: 'آموزش ابتدایی',
      categoryEn: 'Lower Elementary'
    },
    {
      level: 1,
      nameFa: 'طبقه اول: پیش‌دبستانی، حیاط اختصاصی و اداری',
      nameEn: '1st Floor: Preschool & Early Childhood Campus',
      specsFa: 'فضای آموزشی پیش‌دبستانی با کفپوش ضدضربه، فضای شن‌بازی، آتلیه سفال و رنگ، اتاق نمایش خلاق، دفتر مدیریت و پذیرش',
      specsEn: 'Shock-absorbent playgrounds, sandplay area, pottery atelier, creative drama room, and administrative offices',
      image: '/assets/photos/infant-school.jpg',
      categoryFa: 'پیش‌دبستانی',
      categoryEn: 'Preschool'
    },
    {
      level: 0,
      nameFa: 'طبقات منفی: مجموعه ورزشی و سالن غذاخوری ارگانیک',
      nameEn: 'Lower Ground: Sports Complex & Dining Hall',
      specsFa: 'استخر سرپوشیده با تصفیه ازن، سالن چندمنظوره بسکتبال/والیبال، سالن ژیمناستیک و پیلاتس و آشپزخانه صنعتی تهیه غذای سالم',
      specsEn: 'Indoor ozone-filtered swimming pool, multi-purpose sports hall, gymnastics studio, and organic dining hall',
      image: '/assets/photos/mission-vision.jpg',
      categoryFa: 'ورزش و تندرستی',
      categoryEn: 'Sports & Wellness'
    }
  ];

  const current = floors.find((f) => f.level === activeFloor) || floors[0];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-6 font-persian" dir={isPersian ? 'rtl' : 'ltr'}>
        {/* Dimmed backdrop */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 bg-black/40 backdrop-blur-md"
          onClick={onClose}
        />

        {/* Modal Window */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.96, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 16 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-4xl bg-white rounded-3xl shadow-[0_24px_80px_rgba(0,0,0,0.18)] overflow-hidden flex flex-col max-h-[90vh] border border-black/[0.08] z-10"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="bg-white/95 backdrop-blur-2xl text-slate-900 px-6 sm:px-8 py-5 flex items-center justify-between border-b border-black/[0.06]">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2A6AB2]" />
              <div>
                <span className="text-[10px] text-slate-400 font-mono tracking-wider block">
                  {isPersian ? 'مجتمع آموزشی خرد (ولنجک)' : 'Kherad Velenjak Campus'}
                </span>
                <h2 className="text-base sm:text-lg font-bold text-slate-900 font-serif-heading">
                  {isPersian 
                    ? 'نقشه تعاملی طبقات و فضاهای آموزشی (۱۲٬۰۰۰ متر مربع در ۷ طبقه)' 
                    : 'Interactive Campus Map (12,000 sqm across 7 levels)'}
                </h2>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-[#F5F5F7] hover:bg-[#EBECEF] text-slate-700 flex items-center justify-center transition-all border border-black/[0.05] cursor-pointer active:scale-95"
              aria-label={isPersian ? 'بستن' : 'Close'}
            >
              <X className="w-4.5 h-4.5 stroke-[1.5]" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6">
            {/* Floor Navigation Buttons */}
            <div className="flex justify-center">
              <div className="inline-flex flex-wrap gap-1 p-1 sm:p-1.5 bg-[#EBEDF0] rounded-full border border-black/[0.04] shadow-2xs justify-center">
                {floors.map((f) => (
                  <button
                    key={f.level}
                    onClick={() => setActiveFloor(f.level)}
                    className={`px-4 sm:px-5 py-2 text-xs sm:text-[13px] font-medium rounded-full transition-all cursor-pointer ${
                      activeFloor === f.level
                        ? 'bg-[#1D1D1F] text-white shadow-xs'
                        : 'text-[#48484A] hover:text-[#1D1D1F]'
                    }`}
                  >
                    {f.level === 0 
                      ? (isPersian ? 'طبقات منفی' : 'Basement') 
                      : (isPersian ? `طبقه ${f.level}` : `Level ${f.level}`)}
                  </button>
                ))}
              </div>
            </div>

            {/* Active Floor Details */}
            <div className="bg-[#F5F5F7] p-6 rounded-3xl border border-black/[0.05] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700 bg-white border border-black/[0.05] px-3 py-1 rounded-full shadow-2xs">
                  {isPersian ? current.categoryFa : current.categoryEn}
                </span>
                <span className="text-xs font-mono text-slate-400">
                  {isPersian ? 'مجتمع آموزشی خرد ولنجک' : 'Central Velenjak Campus'}
                </span>
              </div>

              <h3 className="text-lg sm:text-xl font-bold text-slate-900 font-serif-heading">
                {isPersian ? current.nameFa : current.nameEn}
              </h3>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-light">
                {isPersian ? current.specsFa : current.specsEn}
              </p>
            </div>

            {/* Authentic Photography from Repository */}
            <div className="rounded-none overflow-hidden bg-slate-900 shadow-md border border-black/[0.05] relative aspect-video">
              <img
                src={current.image}
                alt={isPersian ? current.nameFa : current.nameEn}
                className="w-full h-full object-cover object-center"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-5">
                <p className="text-white text-xs sm:text-sm font-medium">
                  {isPersian ? current.nameFa : current.nameEn}
                </p>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="bg-[#EDEDF0]/70 px-6 sm:px-8 py-4 border-t border-black/[0.06] flex items-center justify-between text-xs text-slate-500">
            <span className="font-light">
              {isPersian 
                ? 'آدرس: تهران، ولنجک، بلوار دانشجو، بالاتر از میدان یاسمن، خیابان عدالت، مجتمع آموزشی خرد' 
                : 'Address: Edalat St, Daneshjou Blvd, Velenjak, Tehran, Iran'}
            </span>
            <button
              onClick={onClose}
              className="bg-white hover:bg-white/80 text-slate-700 border border-black/[0.06] text-xs font-semibold px-5 py-2 rounded-full transition-colors cursor-pointer"
            >
              {isPersian ? 'بستن پنجره' : 'Close'}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
