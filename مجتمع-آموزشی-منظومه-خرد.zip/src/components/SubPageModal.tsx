import React from 'react';
import { X, CheckCircle2, ArrowRight, ExternalLink } from 'lucide-react';
import { subPagesDetails } from '../data/tanglinMainPageData';
import { Language } from '../types';

interface SubPageModalProps {
  modalId: string | null;
  lang: Language;
  onClose: () => void;
  onOpenBookVisit: () => void;
  onOpenEnquiry: () => void;
}

export const SubPageModal: React.FC<SubPageModalProps> = ({
  modalId,
  lang,
  onClose,
  onOpenBookVisit,
  onOpenEnquiry
}) => {
  if (!modalId) return null;

  const data = subPagesDetails[modalId] || subPagesDetails['mission'];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-xl shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col border border-gray-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Ribbon */}
        <div className="bg-[#001744] text-white px-6 py-4 flex items-center justify-between border-b border-[#002169] shrink-0">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-[#CE0E2D] block">
              {lang === 'fa' ? data.categoryFa : data.categoryEn}
            </span>
            <h2 className="text-lg sm:text-xl font-bold font-serif-heading text-white">
              {lang === 'fa' ? data.titleFa : data.titleEn}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-6 flex-1 text-gray-800">
          {/* Hero Banner inside modal */}
          <div className="relative aspect-[21/9] sm:aspect-[24/9] rounded-lg overflow-hidden shadow-md">
            <img
              src={data.heroImage}
              alt={data.titleEn}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex items-end p-4 sm:p-6">
              <p className="text-white text-xs sm:text-sm font-medium italic">
                "{lang === 'fa' ? data.summaryFa : data.summaryEn}"
              </p>
            </div>
          </div>

          {/* Body Paragraphs */}
          <div className="space-y-3.5 text-sm sm:text-base leading-relaxed text-gray-700">
            {(lang === 'fa' ? data.contentFa : data.contentEn).map((paragraph, idx) => (
              <p key={idx}>{paragraph}</p>
            ))}
          </div>

          {/* Key Highlights */}
          <div className="bg-[#FAFBFD] p-5 rounded-lg border border-gray-200 space-y-3">
            <h3 className="text-sm font-bold text-[#002169] uppercase tracking-wider">
              {lang === 'fa' ? 'نکات کلیدی و تمایزهای شاخص' : 'Key Highlights & Distinctions'}
            </h3>
            <ul className="space-y-2">
              {(lang === 'fa' ? data.keyHighlightsFa : data.keyHighlightsEn).map((hl, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-gray-700">
                  <CheckCircle2 className="w-4 h-4 text-[#CE0E2D] shrink-0 mt-0.5" />
                  <span>{hl}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <button
            onClick={onClose}
            className="text-xs sm:text-sm font-semibold text-gray-600 hover:text-gray-900 px-4 py-2 rounded"
          >
            {lang === 'fa' ? 'بستن پنجره' : 'Close'}
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                onClose();
                onOpenBookVisit();
              }}
              className="bg-[#002169] hover:bg-[#001744] text-white text-xs sm:text-sm font-bold px-4 py-2 rounded transition-colors"
            >
              {lang === 'fa' ? 'رزرو بازدید حضوری' : 'Book a Campus Visit'}
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenEnquiry();
              }}
              className="bg-[#CE0E2D] hover:bg-[#b00b25] text-white text-xs sm:text-sm font-bold px-4 py-2 rounded transition-colors"
            >
              {lang === 'fa' ? 'ارسال پرسش پذیرش' : 'Admissions Enquiry'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
