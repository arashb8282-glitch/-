import React, { useState } from 'react';
import { Search, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { sitemapData } from '../data/kheradSitemap';
import { useLanguage } from '../context/LanguageContext';

interface RightDrawerMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectItem: (categoryId: string, subItemId?: string) => void;
  onSearch: (query: string) => void;
}

export const RightDrawerMenu: React.FC<RightDrawerMenuProps> = ({
  isOpen,
  onClose,
  onSelectItem,
  onSearch
}) => {
  const { lang, toggleLanguage, t, isPersian } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Reset activeCategory to null when drawer closes
  React.useEffect(() => {
    if (!isOpen) {
      setActiveCategory(null);
    }
  }, [isOpen]);

  // Filter out systems from drawer menu as requested
  const drawerCategories = sitemapData.filter((c) => c.id !== 'systems');
  const currentCategoryData = activeCategory ? drawerCategories.find((c) => c.id === activeCategory) : null;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery.trim());
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[70] overflow-hidden font-persian" dir={isPersian ? 'rtl' : 'ltr'}>
          {/* Dimmed Architectural Backdrop */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-0 bg-black/45 backdrop-blur-[2px]"
            onClick={onClose}
          />

          {/* Architectural Luxury Drawer - White Background with Gray Typography */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.985, y: -8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.985, y: -6 }}
            transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
            className="absolute top-0 bottom-0 right-0 origin-top-right w-full sm:w-[385px] md:w-[420px] lg:w-[440px] max-w-full bg-white dark:bg-[#131d31] text-slate-700 dark:text-slate-200 shadow-2xl flex flex-col z-10 select-none overflow-hidden border-l border-slate-200 dark:border-slate-800"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Bar: Anchored Square Close Button + Search Bar aligned exactly with top header toolbar line */}
            <div className="relative bg-[#112544] shrink-0 h-11 sm:h-12 border-b border-white/10">
              <div className="flex items-stretch h-full" dir="ltr">
                {/* Search Bar Container - Vertically centered, sitting directly above the aligned bottom border */}
                <div className="flex-1 flex items-center pl-6 sm:pl-8 pr-3 sm:pr-4" dir={isPersian ? 'rtl' : 'ltr'}>
                  <motion.form 
                    initial={{ opacity: 0, y: -3 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                    onSubmit={handleSearchSubmit} 
                    className="relative flex items-center w-full focus-within:text-[#0b82c6] transition-colors"
                  >
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder={t.nav.searchPlaceholder}
                      className={`w-full bg-transparent text-white placeholder-slate-400 font-normal focus:outline-none tracking-normal py-1 ${
                        isPersian 
                          ? 'pr-0 pl-7 text-right text-xs sm:text-[13px]' 
                          : 'pl-0 pr-7 text-left text-[12.5px] sm:text-[13.5px]'
                      }`}
                      autoFocus
                    />
                    <button
                      type="submit"
                      className={`absolute ${isPersian ? 'left-0' : 'right-0'} top-1/2 -translate-y-1/2 text-slate-300 hover:text-[#0b82c6] transition-colors cursor-pointer p-0.5`}
                      title={isPersian ? 'جستجو' : 'Search'}
                      aria-label={isPersian ? 'جستجو' : 'Search'}
                    >
                      <Search className="w-4 h-4 sm:w-4.5 sm:h-4.5 stroke-[1.8]" />
                    </button>
                  </motion.form>
                </div>

                {/* Square Close Button - Matching exact h-11 sm:h-12 height */}
                <motion.button
                  id="drawer-close-button"
                  onClick={onClose}
                  whileHover="hover"
                  whileTap="tap"
                  className="w-12 sm:w-14 h-full shrink-0 bg-transparent text-white hover:text-[#0b82c6] flex items-center justify-center cursor-pointer shadow-none border-none focus:outline-none select-none border-l border-white/10"
                  title={t.nav.closeMenu}
                  aria-label={t.nav.closeMenu}
                >
                  <motion.div
                    variants={{
                      hover: { rotate: 90, scale: 1.15, color: '#0b82c6' },
                      tap: { rotate: 180, scale: 0.9 }
                    }}
                    transition={{ type: 'spring', stiffness: 360, damping: 20 }}
                  >
                    <X className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.4]" />
                  </motion.div>
                </motion.button>
              </div>
            </div>

            {/* Navigation Body */}
            <div className={`flex-1 flex flex-col md:flex-row overflow-y-auto pl-6 sm:pl-8 ${isPersian ? 'pr-5 sm:pr-7 md:pr-8' : 'pr-6 sm:pr-8'} pb-8 pt-6 sm:pt-8 bg-[#112544]`}>
              {/* Column 1: Main Category Titles */}
              <div className="w-full md:w-[48%] py-1 shrink-0 overflow-y-auto">
                <div className={`space-y-2.5 sm:space-y-3 ${isPersian ? 'md:border-l md:border-[#0b82c6]/40 pl-4 sm:pl-6' : 'md:border-r md:border-[#0b82c6]/40 pr-4 sm:pr-6'}`}>
                  {drawerCategories.map((category, index) => {
                    const isActive = activeCategory === category.id;
                    const catTitle = isPersian ? category.title : (category.englishTitle || category.title);
                    return (
                      <motion.div
                        key={category.id}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ 
                          delay: 0.06 + index * 0.025, 
                          duration: 0.32, 
                          ease: [0.16, 1, 0.3, 1] 
                        }}
                      >
                        <button
                          onClick={() => setActiveCategory(category.id)}
                          onMouseEnter={() => setActiveCategory(category.id)}
                          className={`relative ${isPersian ? 'text-right' : 'text-left'} transition-colors duration-200 cursor-pointer block w-full group py-0.5 ${
                            isPersian
                              ? (isActive ? 'text-[14.5px] sm:text-[15.5px] font-bold text-white' : 'text-[14.5px] sm:text-[15.5px] font-normal text-slate-300 hover:text-white group-hover:text-white')
                              : (isActive ? 'text-[14px] sm:text-[14.5px] font-medium text-white' : 'text-[14px] sm:text-[14.5px] font-normal text-slate-300 hover:text-white group-hover:text-white')
                          }`}
                        >
                          <span className={`kherad-underline-ltr pb-0.5 transition-transform duration-200 ease-out ${isPersian ? 'group-hover:translate-x-[-3px]' : 'group-hover:translate-x-[3px]'}`}>
                            {catTitle}
                            <span className={`kherad-underline-bar ${isActive ? 'is-active' : ''}`} />
                          </span>
                        </button>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Column 2: Sub-items in English when English selected */}
              <div className={`flex-1 py-1 ${isPersian ? 'pr-0 md:pr-6 sm:pr-8' : 'pl-0 md:pl-6 sm:pl-8'} overflow-y-auto`}>
                <AnimatePresence mode="wait">
                  {currentCategoryData ? (
                    <motion.div
                      key={currentCategoryData.id}
                      initial="hidden"
                      animate="visible"
                      exit="exit"
                      variants={{
                        hidden: { opacity: 0 },
                        visible: {
                          opacity: 1,
                          transition: {
                            staggerChildren: 0.032,
                            delayChildren: 0.02
                          }
                        },
                        exit: {
                          opacity: 0,
                          transition: { duration: 0.12, ease: "easeOut" }
                        }
                      }}
                      className="space-y-2.5 sm:space-y-3"
                    >
                      {currentCategoryData.subItems.map((item) => (
                        <motion.div
                          key={item.id}
                          variants={{
                            hidden: { opacity: 0, y: 4 },
                            visible: { 
                              opacity: 1, 
                              y: 0,
                              transition: { 
                              duration: 0.22, 
                              ease: [0.22, 1, 0.36, 1] 
                            } 
                          }
                        }}
                      >
                        {item.isHeader ? (
                          <div className="pt-2 pb-0.5 text-[13px] sm:text-[13.5px] font-bold text-white tracking-tight select-none">
                            {isPersian ? item.title : (item.englishTitle || item.title)}
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              onSelectItem(currentCategoryData.id, item.id);
                              onClose();
                            }}
                            className={`w-full ${isPersian ? 'text-right' : 'text-left'} transition-colors cursor-pointer py-0.5 block group ${
                              item.title.startsWith('-') ? (isPersian ? 'pr-2' : 'pl-2') : ''
                            } ${
                              isPersian
                                ? (item.title.startsWith('-') ? 'text-[12.5px] sm:text-[13.5px] text-slate-300 hover:text-white group-hover:text-white font-light' : 'text-[13px] sm:text-[14px] font-normal text-slate-300 hover:text-white group-hover:text-white')
                                : 'text-[12.5px] sm:text-[13px] font-normal text-slate-300 hover:text-white group-hover:text-white'
                            }`}
                          >
                            <span className={`kherad-underline-ltr pb-0.5 tracking-normal ${isPersian ? 'group-hover:translate-x-[-3px]' : 'group-hover:translate-x-[3px]'} transition-transform duration-200 ease-out`}>
                              {isPersian ? item.title : (item.englishTitle || item.title)}
                              <span className="kherad-underline-bar" />
                            </span>
                          </button>
                        )}
                      </motion.div>
                    ))}
                  </motion.div>
                ) : null}
              </AnimatePresence>
            </div>
          </div>

          {/* Bottom Footer: Copyright Text (Logo Removed) */}
          <div 
            className={`shrink-0 pt-3 pb-8 sm:pb-9 pl-6 sm:pl-8 ${isPersian ? 'pr-5 sm:pr-7 md:pr-8' : 'pr-6 sm:pr-8'} border-t border-white/10 bg-[#112544]`}
            dir={isPersian ? 'rtl' : 'ltr'}
          >
            <p className={`text-slate-400 tracking-normal ${isPersian ? 'text-[11.5px] sm:text-[12px] font-normal text-right' : 'text-[11.5px] sm:text-[12px] font-normal text-left'}`}>
              {t.nav.allRightsReserved}
            </p>
          </div>
        </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
