import React, { useState } from 'react';
import { Language } from '../types';
import { 
  Sparkles, 
  BookOpen, 
  GraduationCap, 
  CheckCircle, 
  Globe2, 
  TrendingUp,
  School,
  Compass
} from 'lucide-react';

interface DualPathwayProps {
  lang: Language;
}

export const DualPathway: React.FC<DualPathwayProps> = ({ lang }) => {
  const isPersian = lang === 'fa';
  const [selectedPathway, setSelectedPathway] = useState<'both' | 'ib' | 'alevel'>('both');

  const universities = [
    { name: 'University of Oxford', country: 'UK', flag: '🇬🇧' },
    { name: 'University of Cambridge', country: 'UK', flag: '🇬🇧' },
    { name: 'Imperial College London', country: 'UK', flag: '🇬🇧' },
    { name: 'Harvard University', country: 'USA', flag: '🇺🇸' },
    { name: 'Stanford University', country: 'USA', flag: '🇺🇸' },
    { name: 'National University of Singapore (NUS)', country: 'Singapore', flag: '🇸🇬' },
    { name: 'University of Melbourne', country: 'Australia', flag: '🇦🇺' },
    { name: 'University of Toronto', country: 'Canada', flag: '🇨🇦' },
  ];

  return (
    <section id="dual-pathway" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A85C]/15 text-[#0F2537] text-xs font-bold uppercase tracking-widest mb-3 border border-[#C5A85C]/30">
            <Sparkles className="w-3.5 h-3.5 text-[#C5A85C]" />
            {isPersian ? 'منحصربه‌فرد در سنگاپور' : 'Unique in Singapore'}
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-serif-heading text-[#0F2537]">
            {isPersian ? 'مسیر دوگانه Sixth Form: دیپلم IB و آزمون‌های A-Level' : 'Our Sixth Form Dual Pathway'}
          </h2>
          <div className="w-16 h-1 bg-[#C5A85C] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base leading-relaxed">
            {isPersian
              ? 'مدرسه تانگلین تنها موسسه در سنگاپور است که هر دو مسیر معتبر جهانی را در بالاترین سطح ارائه می‌دهد تا هر دانش‌آموز بر اساس نقاط قوت و علایق دانشگاهی خود تصمیم بگیرد.'
              : 'Tanglin Trust School is the only school in Singapore offering Sixth Form students the choice of either A-Levels or the International Baccalaureate (IB) Diploma Programme.'}
          </p>

          {/* Filter Pills (Apple segmented control capsule matching uploaded reference) */}
          <div className="inline-flex items-center p-1.5 bg-[#EBEDF0] rounded-full border border-black/[0.04] shadow-xs mt-6">
            <button
              onClick={() => setSelectedPathway('both')}
              className={`px-5 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                selectedPathway === 'both'
                  ? 'bg-[#1D1D1F] text-white shadow-sm'
                  : 'text-[#1D1D1F]/80 hover:text-[#1D1D1F] hover:bg-black/[0.03]'
              }`}
            >
              {isPersian ? 'مقایسه هر دو مسیر' : 'Compare Both'}
            </button>
            <button
              onClick={() => setSelectedPathway('ib')}
              className={`px-5 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                selectedPathway === 'ib'
                  ? 'bg-[#1D1D1F] text-white shadow-sm'
                  : 'text-[#1D1D1F]/80 hover:text-[#1D1D1F] hover:bg-black/[0.03]'
              }`}
            >
              IB Diploma
            </button>
            <button
              onClick={() => setSelectedPathway('alevel')}
              className={`px-5 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                selectedPathway === 'alevel'
                  ? 'bg-[#1D1D1F] text-white shadow-sm'
                  : 'text-[#1D1D1F]/80 hover:text-[#1D1D1F] hover:bg-black/[0.03]'
              }`}
            >
              A-Levels
            </button>
          </div>
        </div>

        {/* Dual Pathway Side-by-Side Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          
          {/* IB Diploma Card */}
          {(selectedPathway === 'both' || selectedPathway === 'ib') && (
            <div className="rounded-2xl p-6 sm:p-8 bg-gradient-to-br from-slate-50 to-white border-2 border-slate-200 hover:border-[#C5A85C] transition-all shadow-md hover:shadow-xl relative flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-[#C5A85C]">
                      {isPersian ? 'چندرشته‌ای و بین‌المللی' : 'Broad & Interdisciplinary'}
                    </span>
                    <h3 className="text-2xl font-bold font-serif-heading text-[#0F2537] mt-0.5">
                      IB Diploma Programme
                    </h3>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-[#0F2537] text-[#C5A85C] flex items-center justify-center font-bold text-sm">
                    IB
                  </div>
                </div>

                {/* Score highlight */}
                <div className="my-6 p-4 rounded-xl bg-[#0F2537] text-white flex items-center justify-between">
                  <div>
                    <div className="text-2xl sm:text-3xl font-extrabold text-[#C5A85C] font-serif-heading">
                      39.1 / 45
                    </div>
                    <div className="text-xs text-slate-300">
                      {isPersian ? 'میانگین نمره دانش‌آموزان تانگلین' : 'Tanglin Average Score'}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-slate-300">
                      30.2
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {isPersian ? 'میانگین جهانی' : 'World Average'}
                    </div>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {isPersian
                    ? 'دیپلم بین‌المللی IB برای دانش‌آموزانی که به یادگیری چندوجهی علاقه دارند؛ شامل ۶ درس اصلی (زبان، علوم، ریاضی، هنر و علوم انسانی) به اضافه رساله پژوهشی مستقل (Extended Essay)، تئوری شناخت (TOK) و فعالیت‌های اجتماعی (CAS).'
                    : 'The IB Diploma is designed for students seeking broad intellectual breadth across languages, humanities, sciences, and mathematics, enriched by the Extended Essay, Theory of Knowledge (TOK), and Creativity, Activity, Service (CAS).'}
                </p>

                <div className="mt-6 space-y-2.5">
                  <div className="text-xs font-bold uppercase text-[#0F2537]">
                    {isPersian ? 'مزایای کلیدی مسیر IB:' : 'Key Advantages:'}
                  </div>
                  {[
                    isPersian ? 'بیش از ۵۲٪ دانش‌آموزان نمره بالای ۴۰ کسب می‌کنند (۳٪ برتر جهان)' : 'Over 52% score 40+ points (placing in global top 3%)',
                    isPersian ? 'پرورش مهارت‌های عمیق پژوهشی و مقاله‌نویسی دانشگاهی' : 'Rigorous independent university-level research preparation',
                    isPersian ? 'پذیرش در بهترین دانشگاه‌های آمریکا، بریتانیا، اروپا و آسیا' : 'Favoured by Ivy League, European, and top global institutions'
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs sm:text-sm text-slate-700">
                      <CheckCircle className="w-4 h-4 text-[#C5A85C] shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between">
                <span>{isPersian ? 'مدت دوره: ۲ سال تحصیلی' : 'Duration: 2 Academic Years'}</span>
                <span className="font-bold text-[#0F2537]">Years 12 & 13</span>
              </div>
            </div>
          )}

          {/* A-Levels Card */}
          {(selectedPathway === 'both' || selectedPathway === 'alevel') && (
            <div className="rounded-2xl p-6 sm:p-8 bg-gradient-to-br from-slate-50 to-white border-2 border-slate-200 hover:border-[#C5A85C] transition-all shadow-md hover:shadow-xl relative flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-[#C5A85C]">
                      {isPersian ? 'تخصص عمیق در رشته‌های هدف' : 'Deep Subject Specialisation'}
                    </span>
                    <h3 className="text-2xl font-bold font-serif-heading text-[#0F2537] mt-0.5">
                      GCE A-Levels
                    </h3>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-[#0F2537] text-[#C5A85C] flex items-center justify-center font-bold text-sm">
                    A*
                  </div>
                </div>

                {/* Score highlight */}
                <div className="my-6 p-4 rounded-xl bg-[#0F2537] text-white flex items-center justify-between">
                  <div>
                    <div className="text-2xl sm:text-3xl font-extrabold text-[#C5A85C] font-serif-heading">
                      58% A* / A
                    </div>
                    <div className="text-xs text-slate-300">
                      {isPersian ? 'نمرات عالی در آزمون‌های نهایی' : 'Entries Awarded Top Grades'}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-slate-300">
                      100% Pass
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {isPersian ? 'نرخ قبولی کل داوطلبان' : 'Pass Rate (24 subjects)'}
                    </div>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {isPersian
                    ? 'دوره A-Level استاندارد طلایی آموزش بریتانیاست؛ دانش‌آموزان ۳ الی ۴ درس تخصصی را انتخاب کرده و تا بالاترین حد علمی مورد نیاز رشته‌های پزشکی، مهندسی، حقوق و علوم پایه مطالعه می‌نمایند.'
                    : 'A-Levels are the traditional gold-standard British qualification allowing students to focus intensely on 3 to 4 subjects of greatest interest, perfectly suited for competitive STEM, Medicine, and Law courses.'}
                </p>

                <div className="mt-6 space-y-2.5">
                  <div className="text-xs font-bold uppercase text-[#0F2537]">
                    {isPersian ? 'مزایای کلیدی مسیر A-Level:' : 'Key Advantages:'}
                  </div>
                  {[
                    isPersian ? 'تمرکز کامل و تخصص علمی بدون نیاز به خواندن دروس ناهمخوان' : 'Specialised deep mastery tailored directly to university majors',
                    isPersian ? 'امکان ارائه پروژه پژوهشی ممتد EPQ معادل نیم‌واحد A-Level' : 'Option to undertake the Extended Project Qualification (EPQ)',
                    isPersian ? 'مسیر ایده‌آل و سنتی برای پذیرش در آکسفورد، کمبریج و دانشگاه‌های لندن' : 'Exceptional track record for Oxford, Cambridge, and UK Russell Group'
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs sm:text-sm text-slate-700">
                      <CheckCircle className="w-4 h-4 text-[#C5A85C] shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between">
                <span>{isPersian ? 'ارائه ۲۴ موضوع درسی مجزا' : '24 Subject Options Available'}</span>
                <span className="font-bold text-[#0F2537]">Years 12 & 13</span>
              </div>
            </div>
          )}

        </div>

        {/* Global University Matriculation Strip */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-900 text-white border border-[#C5A85C]/30 shadow-xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-6">
            <div>
              <div className="flex items-center gap-2 text-[#C5A85C] text-xs font-bold uppercase tracking-wider">
                <Globe2 className="w-4 h-4" />
                <span>{isPersian ? 'مقاصد جهانی فارغ‌التحصیلان تانگلین' : 'Global University Matriculation'}</span>
              </div>
              <h4 className="text-xl sm:text-2xl font-bold font-serif-heading text-white mt-1">
                {isPersian ? 'ورود به برجسته‌ترین دانشگاه‌های جهان' : 'Destinations of Tanglin Graduates'}
              </h4>
            </div>
            <div className="text-xs text-slate-400 max-w-sm text-center md:text-right">
              {isPersian
                ? '۹۸٪ از دانش‌آموزان به انتخاب‌های اول یا دوم خود در بریتانیا، ایالات متحده، کانادا و استرالیا دست می‌یابند.'
                : '98% of Tanglin students secure their first or second choice university globally.'}
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {universities.map((uni, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-center"
              >
                <span className="text-lg">{uni.flag}</span>
                <div className="text-xs font-bold text-white mt-1 truncate">
                  {uni.name}
                </div>
                <div className="text-[10px] text-[#C5A85C]">
                  {uni.country}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
