import React, { useState } from 'react';
import { 
  X, 
  Compass, 
  MapPin, 
  Layers, 
  Eye, 
  ZoomIn, 
  ZoomOut, 
  Volume2, 
  VolumeX,
  ChevronRight,
  Maximize2,
  Sparkles
} from 'lucide-react';
import { Language } from '../types';

interface VirtualTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const VirtualTourModal: React.FC<VirtualTourModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  if (!isOpen) return null;

  const isPersian = lang === 'fa';
  const [activeNode, setActiveNode] = useState(0);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [soundEnabled, setSoundEnabled] = useState(false);

  const nodes = [
    {
      id: 'centenary-pool',
      titleEn: '11-Storey Centenary Building & 50m Olympic Pool',
      titleFa: 'ساختمان ۱۱ طبقه صدمین سالگرد و استخر ۵۰ متری المپیک',
      areaEn: 'Sports & Athletic Precinct',
      areaFa: 'مجموعه ورزش‌های آبی و قهرمانی',
      image: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1600&q=85',
      descEn: 'FINA-standard covered 50m pool with timing touchpads, integrated 15m climbing gym, and high-performance training suite.',
      descFa: 'استخر سرپوشیده ۵۰ متری المپیک طبق مشخصات فدراسیون جهانی شنا (FINA) همراه با دیواره ۱۵ متری صخره‌نوردی.'
    },
    {
      id: 'theatre',
      titleEn: 'The Griffith 400-Seat Proscenium Theatre',
      titleFa: 'تالار تئاتر ۴۰۰ نفره گریفیث',
      areaEn: 'Arts & Music Complex',
      areaFa: 'مجتمع هنرهای نمایشی و موسیقی',
      image: 'https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?auto=format&fit=crop&w=1600&q=85',
      descEn: 'Full professional auditorium hosting Shakespeare festivals, musical orchestras, and guest keynote assemblies.',
      descFa: 'سالن چندطبقه مجهز به سیستم‌های صوتی و نوری پیشرفته برای اجرای کنسرت‌های ارکستر، نمایش‌ها و سخنرانی‌های بین‌المللی.'
    },
    {
      id: 'science-labs',
      titleEn: 'Nixon Advanced Science & Robotics Lab',
      titleFa: 'آزمایشگاه‌های پیشرفته علوم و رباتیک نیکسون',
      areaEn: 'Senior School & STEM',
      areaFa: 'دبیرستان و علوم پیشرفته',
      image: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=1600&q=85',
      descEn: '20 university-grade science suites with laser cutting, 3D printers, spectrophotometers, and VEX arena.',
      descFa: 'بیست ایستگاه آزمایشگاهی دانشگاهی همراه با پرینترهای سه‌بعدی، ابزارهای دقیق آنالیز و پیست مسابقات رباتیک.'
    },
    {
      id: 'sixth-form',
      titleEn: 'Collegiate Sixth Form Centre & Seminar Rooms',
      titleFa: 'مرکز دانشگاهی سیکث فرم و سالن‌های سمینار',
      areaEn: 'Sixth Form (Years 12 & 13)',
      areaFa: 'پیش‌دانشگاهی (پایه‌های ۱۲ و ۱۳)',
      image: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1600&q=85',
      descEn: 'Independent study halls, private university counseling suites, and collaborative debate spaces.',
      descFa: 'سالن‌های مطالعه اختصاصی، دفاتر مشاوره پذیرش دانشگاه‌های هاروارد و آکسفورد، و فضاهای سمینار.'
    },
    {
      id: 'playing-fields',
      titleEn: 'Berrick All-Weather Sports Grounds',
      titleFa: 'زمین‌های ورزشی چمن مصنوعی بریک',
      areaEn: 'Outdoor Athletics',
      areaFa: 'تربیت بدنی و ورزش در فضای باز',
      image: 'https://images.unsplash.com/photo-1526232761682-d26e03ac148e?auto=format&fit=crop&w=1600&q=85',
      descEn: 'Full-size FIFA-certified synthetic football and rugby pitch, floodlit tennis courts, and athletics running track.',
      descFa: 'زمین چمن مصنوعی استاندارد بین‌المللی فیفا برای فوتبال و راگبی، همراه با ۴ زمین تنیس دارای نورافکن.'
    }
  ];

  const current = nodes[activeNode];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-6xl h-[92vh] sm:h-[85vh] bg-[#0F2537] rounded-2xl overflow-hidden shadow-2xl border border-white/20 flex flex-col">
        
        {/* Top Header Bar */}
        <div className="p-4 bg-[#08131F] border-b border-white/10 flex items-center justify-between z-20">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#C5A85C]/20 text-[#C5A85C]">
              <Compass className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <div className="text-xs font-bold text-[#C5A85C] uppercase tracking-wider">
                {isPersian ? 'تور مجازی ۳۶۰ درجه پردیس تانگلین' : 'Tanglin 360° Interactive Campus Explorer'}
              </div>
              <h3 className="text-base sm:text-lg font-bold font-serif-heading text-white">
                {isPersian ? current.titleFa : current.titleEn}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Sound Ambient toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors text-xs flex items-center gap-1"
              title={soundEnabled ? 'Disable campus sound' : 'Enable campus sound'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-[#C5A85C]" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
            </button>

            {/* Close Button */}
            <button
              id="virtual-tour-close-btn"
              onClick={onClose}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
              aria-label="Close Tour"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Viewport Canvas */}
        <div className="relative flex-1 bg-black overflow-hidden select-none">
          <img
            src={current.image}
            alt={current.titleEn}
            className="w-full h-full object-cover transition-transform duration-500 ease-out"
            style={{ transform: `scale(${zoomLevel})` }}
          />

          {/* Virtual Tour Overlay Graphics & Compass */}
          <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/15 text-white text-xs flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-[#C5A85C]" />
            <span>{isPersian ? current.areaFa : current.areaEn}</span>
          </div>

          {/* Zoom Controls */}
          <div className="absolute bottom-20 sm:bottom-6 right-4 flex flex-col gap-1.5 bg-black/60 backdrop-blur-md p-1.5 rounded-lg border border-white/15 text-white">
            <button
              onClick={() => setZoomLevel(prev => Math.min(prev + 0.25, 1.75))}
              className="p-2 hover:bg-white/20 rounded transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => setZoomLevel(prev => Math.max(prev - 0.25, 1))}
              className="p-2 hover:bg-white/20 rounded transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
          </div>

          {/* Information Banner */}
          <div className="absolute bottom-4 left-4 right-4 sm:right-24 bg-gradient-to-r from-[#0F2537]/90 to-[#162E4A]/80 backdrop-blur-md p-4 rounded-xl border border-white/15 text-white">
            <div className="text-xs text-[#C5A85C] font-bold uppercase tracking-wider">
              {isPersian ? 'توضیحات فضا' : 'Location Overview'}
            </div>
            <p className="text-xs sm:text-sm text-slate-200 mt-1 line-clamp-2 sm:line-clamp-none">
              {isPersian ? current.descFa : current.descEn}
            </p>
          </div>
        </div>

        {/* Bottom Node Navigation Strip */}
        <div className="p-3 bg-[#08131F] border-t border-white/10 flex items-center gap-2 overflow-x-auto scrollbar-none z-20">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider shrink-0 px-2">
            {isPersian ? 'نقاط دید پردیس:' : 'Tour Nodes:'}
          </span>
          {nodes.map((node, idx) => (
            <button
              key={node.id}
              onClick={() => {
                setActiveNode(idx);
                setZoomLevel(1);
              }}
              className={`shrink-0 px-3 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 border ${
                activeNode === idx
                  ? 'bg-[#C5A85C] text-[#0F2537] border-[#C5A85C] font-bold shadow'
                  : 'bg-white/5 text-slate-300 hover:bg-white/10 border-white/10'
              }`}
            >
              <span>{idx + 1}.</span>
              <span className="truncate max-w-[140px] sm:max-w-[200px]">
                {isPersian ? node.titleFa : node.titleEn}
              </span>
            </button>
          ))}
        </div>

      </div>
    </div>
  );
};
