import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronDown, 
  ChevronUp, 
  Sparkles, 
  Compass, 
  Target, 
  Users, 
  CheckCircle2, 
  Globe2, 
  HeartHandshake, 
  ShieldCheck, 
  Palette, 
  Smile,
  BookOpen
} from 'lucide-react';
import { kheradValuesData, kheradMissionVision, KheradValueItem } from '../data/kheradValuesData';
import { useLanguage } from '../context/LanguageContext';

interface KheradValuesSectionProps {
  initialOpenValueId?: string;
  showMissionVisionBanner?: boolean;
}

export const KheradValuesSection: React.FC<KheradValuesSectionProps> = ({
  initialOpenValueId,
  showMissionVisionBanner = true
}) => {
  const { lang, setLang, isPersian } = useLanguage();
  const [expandedValueId, setExpandedValueId] = useState<string | null>(initialOpenValueId || 'self-awareness-feedback');
  const [selectedAudienceMap, setSelectedAudienceMap] = useState<Record<string, 'parents' | 'students' | 'staff'>>({
    'self-awareness-feedback': 'parents',
    'inquiry-clear-thinking': 'students',
    'purposeful-effort-real-result': 'students',
    'society-nature-responsibility': 'students',
    'collaboration-teamwork': 'parents',
    'honesty-transparency': 'staff',
    'holistic-growth': 'students',
    'kindness-respect': 'students',
  });

  const toggleExpand = (id: string) => {
    setExpandedValueId((prev) => (prev === id ? null : id));
  };

  const setAudience = (valueId: string, aud: 'parents' | 'students' | 'staff') => {
    setSelectedAudienceMap((prev) => ({
      ...prev,
      [valueId]: aud,
    }));
  };

  const getIconForIndex = (index: number) => {
    switch (index) {
      case 1: return <Sparkles className="w-4 h-4 text-[#0b82c6]" />;
      case 2: return <Compass className="w-4 h-4 text-[#0b82c6]" />;
      case 3: return <Target className="w-4 h-4 text-[#0b82c6]" />;
      case 4: return <Globe2 className="w-4 h-4 text-[#0b82c6]" />;
      case 5: return <Users className="w-4 h-4 text-[#0b82c6]" />;
      case 6: return <ShieldCheck className="w-4 h-4 text-[#0b82c6]" />;
      case 7: return <Palette className="w-4 h-4 text-[#0b82c6]" />;
      case 8: return <Smile className="w-4 h-4 text-[#0b82c6]" />;
      default: return <BookOpen className="w-4 h-4 text-[#0b82c6]" />;
    }
  };

  return (
    <section 
      id="kherad-values"
      className="w-full bg-[#FAFBFD] py-16 sm:py-24 px-4 sm:px-6 lg:px-8 border-b border-slate-200 select-none text-slate-800"
      dir={isPersian ? 'rtl' : 'ltr'}
    >
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Top Breadcrumb & Language Switcher */}
        <div className="flex items-center justify-between flex-wrap gap-4 pb-2 border-b border-slate-200/80">
          <nav className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            <span>{isPersian ? 'خانه' : 'Home'}</span>
            <span className="text-slate-400">›</span>
            <span>{isPersian ? 'درباره خرد' : 'About Kherad'}</span>
            <span className="text-slate-400">›</span>
            <span className="text-[#0b82c6] font-bold">
              {isPersian ? kheradMissionVision.breadcrumbFa : kheradMissionVision.breadcrumbEn}
            </span>
          </nav>

          <div className="inline-flex items-center p-0.5 bg-slate-200/70 rounded-full text-[11px] font-semibold">
            <button
              onClick={() => setLang('fa')}
              className={`px-3 py-1 rounded-full transition-all cursor-pointer ${
                isPersian ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              فارسی
            </button>
            <button
              onClick={() => setLang('en')}
              className={`px-3 py-1 rounded-full transition-all cursor-pointer ${
                !isPersian ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              English
            </button>
          </div>
        </div>

        {/* Mission & Vision Explanatory Strip */}
        {showMissionVisionBanner && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-slate-200 grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0b82c6]/10 text-[#0b82c6] text-xs font-bold">
                <HeartHandshake className="w-3.5 h-3.5" />
                <span>{isPersian ? 'مأموریت منظومه خرد' : 'Kherad Mission'}</span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold font-serif-heading text-slate-900 leading-snug">
                {isPersian ? 'پرورش انسان‌هایی آگاه، خودراهبر و اثرگذار' : 'Empowering Learners for Purposeful Impact'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-light">
                {isPersian ? kheradMissionVision.missionFa : kheradMissionVision.missionEn}
              </p>
            </div>

            <div className="space-y-3 lg:border-r lg:border-slate-100 lg:pr-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
                <Globe2 className="w-3.5 h-3.5" />
                <span>{isPersian ? 'چشم‌انداز منظومه خرد' : 'Kherad Vision'}</span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold font-serif-heading text-slate-900 leading-snug">
                {isPersian ? 'الگوی الهام‌بخش آموزش اخلاقی و توسعه پایدار' : 'An Inspiring Regional Model for Holistic Education'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-light">
                {isPersian ? kheradMissionVision.visionFa : kheradMissionVision.visionEn}
              </p>
            </div>
          </div>
        )}

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold tracking-widest text-slate-500 uppercase block">
            {isPersian ? 'ارزش‌های بنیادین و اصول رفتاری' : 'Core Values & Behavioral Codes'}
          </span>
          <h2 className="text-2xl sm:text-4xl font-bold font-serif-heading text-slate-900 tracking-tight">
            {isPersian ? kheradMissionVision.titleFa : kheradMissionVision.titleEn}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 leading-relaxed max-w-2xl mx-auto font-light">
            {isPersian ? kheradMissionVision.subtitleFa : kheradMissionVision.subtitleEn}
          </p>
        </div>

        {/* 8 Values Grid (4 Columns x 2 Rows on Desktop) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
          {kheradValuesData.map((item) => {
            const isExpanded = expandedValueId === item.id;
            const currentAudience = selectedAudienceMap[item.id] || 'parents';
            const activeExample = item.examples.find((ex) => ex.audience === currentAudience) || item.examples[0];

            return (
              <motion.div
                key={item.id}
                layout
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className={`bg-white rounded-2xl border transition-all flex flex-col justify-between overflow-hidden ${
                  isExpanded 
                    ? 'shadow-md border-[#0b82c6]/40 ring-1 ring-[#0b82c6]/20' 
                    : 'shadow-xs border-slate-200 hover:border-slate-300 hover:shadow-sm'
                }`}
              >
                {/* Top Section */}
                <div className="p-5 sm:p-6 space-y-4">
                  {/* Badge & Value Number Pill */}
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-[11px] font-bold">
                      {getIconForIndex(item.indexNumber)}
                      <span>{isPersian ? item.badgeFa : item.badgeEn}</span>
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      #{item.indexNumber}
                    </span>
                  </div>

                  {/* Value Title */}
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 font-serif-heading leading-snug">
                    {isPersian ? item.titleFa : item.titleEn}
                  </h3>

                  {/* Quote / Statement */}
                  <blockquote className="text-xs sm:text-[13px] text-slate-600 leading-relaxed font-light border-r-2 border-slate-300 pr-3 italic bg-slate-50/50 p-2.5 rounded-lg">
                    «{isPersian ? item.quoteFa : item.quoteEn}»
                  </blockquote>
                </div>

                {/* Bottom Interactive Expandable Area */}
                <div className="px-5 sm:px-6 pb-5 pt-2 border-t border-slate-100 bg-[#FCFCFD]">
                  <button
                    onClick={() => toggleExpand(item.id)}
                    className="w-full flex items-center justify-between text-xs font-semibold text-[#0b82c6] hover:text-[#08669c] transition-colors py-1 cursor-pointer"
                  >
                    <span>{isExpanded ? (isPersian ? 'بستن توضیحات' : 'Close details') : (isPersian ? 'بیشتر بخوانید' : 'Read more')}</span>
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden pt-3 space-y-3"
                      >
                        {/* Core Concept Manifestation */}
                        <div className="p-3 bg-white rounded-xl border border-slate-200/80 text-xs text-slate-700 leading-relaxed">
                          <span className="font-semibold text-slate-900 block mb-1">
                            {isPersian ? 'راهکار و رفتار عملی:' : 'Practical Behavior:'}
                          </span>
                          <p className="font-light">
                            {isPersian ? item.expandedConceptFa : item.expandedConceptEn}
                          </p>
                        </div>

                        {/* Audience Filter Pills */}
                        <div className="space-y-2">
                          <span className="text-[11px] font-medium text-slate-500 block">
                            {isPersian ? 'مصداق تجلی ارزش در رفتار:' : 'Manifestation across roles:'}
                          </span>
                          <div className="flex flex-wrap gap-1 p-1 bg-slate-100 rounded-lg">
                            {item.examples.map((ex) => (
                              <button
                                key={ex.audience}
                                onClick={() => setAudience(item.id, ex.audience)}
                                className={`text-[11px] px-2 py-1 rounded-md transition-all cursor-pointer ${
                                  currentAudience === ex.audience
                                    ? 'bg-white text-slate-900 font-bold shadow-2xs'
                                    : 'text-slate-600 hover:text-slate-900'
                                }`}
                              >
                                {isPersian ? ex.labelFa : ex.labelEn}
                              </button>
                            ))}
                          </div>

                          {/* Concrete Manifestation Box */}
                          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-700 leading-relaxed font-light">
                            <span className="font-bold text-[#0b82c6] block mb-0.5">
                              {isPersian ? `مصداق در رابطه با ${activeExample.labelFa}:` : `In practice with ${activeExample.labelEn}:`}
                            </span>
                            {isPersian ? activeExample.exampleFa : activeExample.exampleEn}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Footnote quote on environmental and social responsibility */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
              <Globe2 className="w-4 h-4 text-[#0b82c6]" />
              <span>{isPersian ? 'ارزش شماره ۴: مسئولیت در قبال جامعه و طبیعت' : 'Value 4: Responsibility to Society & Nature'}</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 font-light">
              {isPersian 
                ? 'پروژه مدرسه سبز در مجتمع آموزشی خرد، تفکیک پسماند، بهینه‌سازی مصرف انرژی و سواد دیجیتال اخلاقی برآمده از این ارزش بنیادین خرد هستند.'
                : 'Our Green School Velenjak initiative, waste separation, and ethical digital literacy are direct expressions of this core value.'}
            </p>
          </div>
          <a
            href="#about-tanglin-section"
            className="text-xs font-semibold text-[#0b82c6] hover:text-[#08669c] underline underline-offset-4 whitespace-nowrap"
          >
            {isPersian ? 'مشاهده سند توسعه پایدار خرد' : 'View Sustainability Blueprint'}
          </a>
        </div>

      </div>
    </section>
  );
};
