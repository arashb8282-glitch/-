import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView, animate } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface CountUpNumberProps {
  end: number;
  suffix?: string;
  prefix?: string;
  duration?: number;
  isPersian?: boolean;
}

const CountUpNumber: React.FC<CountUpNumberProps> = ({
  end,
  suffix = '',
  prefix = '',
  duration = 2.2,
  isPersian = false,
}) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-40px' });

  useEffect(() => {
    if (!isInView) return;

    const controls = animate(0, end, {
      duration,
      ease: [0.16, 1, 0.3, 1], // Smooth deceleration curve
      onUpdate: (latest) => {
        setCount(Math.round(latest));
      },
    });

    return () => controls.stop();
  }, [isInView, end, duration]);

  const formattedCount = count.toLocaleString(isPersian ? 'fa-IR' : 'en-US');

  return (
    <span ref={ref} className="tabular-nums">
      {prefix}{formattedCount}{suffix}
    </span>
  );
};

export const KheradStatsInfographic: React.FC = () => {
  const { isPersian } = useLanguage();

  // Concise 6 key metrics arranged in 3 columns x 2 rows matching the reference image
  const stats = [
    // Row 1
    {
      id: 'campus-area',
      value: 12000,
      suffix: '+',
      label: isPersian ? 'مساحت مجتمع آموزشی خرد (مترمربع)' : 'SQUARE METERS CAMPUS',
    },
    {
      id: 'alumni',
      value: 3000,
      suffix: '+',
      label: isPersian ? 'دانش‌آموختگان خرد' : 'STUDENTS EDUCATED',
    },
    {
      id: 'acceptance',
      value: 98,
      suffix: isPersian ? '٪' : '%',
      label: isPersian ? 'قبولی در دانشگاه‌های برتر' : 'UNIVERSITY ACCEPTANCE',
    },
    // Row 2
    {
      id: 'library-volumes',
      value: 26000,
      suffix: '+',
      label: isPersian ? 'منابع و کتب کتابخانه‌ای' : 'LIBRARY VOLUMES',
    },
    {
      id: 'educators',
      value: 300,
      suffix: '+',
      label: isPersian ? 'اساتید و مربیان متخصص' : 'EXPERT EDUCATORS',
    },
    {
      id: 'current-students',
      value: 1200,
      suffix: '+',
      label: isPersian ? 'دانش‌آموزان در حال تحصیل' : 'CURRENT STUDENTS',
    },
  ];

  return (
    <section 
      id="kherad-stats-infographic"
      className="w-full bg-[#1c1f26] text-white py-11 sm:py-13 md:py-15 border-y border-white/[0.08] select-none overflow-hidden" 
      dir={isPersian ? 'rtl' : 'ltr'}
    >
      <div className="max-w-4xl mx-auto px-6 sm:px-8">
        {/* 3 columns x 2 rows layout with 10% increased vertical gap between rows */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-y-9 sm:gap-y-10 md:gap-y-11 gap-x-6 sm:gap-x-10 md:gap-x-12">
          {stats.map((stat, idx) => (
            <motion.div
              key={stat.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-30px' }}
              transition={{ duration: 0.6, delay: (idx % 3) * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col items-center justify-center text-center cursor-default py-1"
            >
              {/* Blue color matching customer support icon (#0b82c6) Serif Number, standard tracking, with count-up animation */}
              <div className="text-3xl sm:text-[38px] md:text-[42px] lg:text-[44px] font-serif font-light text-[#0b82c6] tracking-normal leading-none">
                <CountUpNumber 
                  end={stat.value} 
                  suffix={stat.suffix} 
                  isPersian={isPersian}
                />
              </div>

              {/* Clean label underneath without any hover boxes */}
              <span className={`text-slate-200/90 font-medium mt-2 sm:mt-2.5 leading-snug ${
                isPersian 
                  ? 'text-[13.5px] sm:text-[14px] tracking-normal' 
                  : 'text-[11.5px] sm:text-[12.5px] uppercase tracking-[0.14em]'
              }`}>
                {stat.label}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
