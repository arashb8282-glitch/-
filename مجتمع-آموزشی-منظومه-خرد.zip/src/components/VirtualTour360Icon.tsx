import React from 'react';

interface VirtualTour360IconProps {
  className?: string;
}

/**
 * 360° Virtual Tour Icon matching exact vector geometry from uploaded image.
 * Features:
 * - "360°" typography centered with uniform stroke weight
 * - Elliptical rotation orbit path underneath
 * - Outlined triangular arrowhead pointing clockwise (rightward)
 */
export const VirtualTour360Icon: React.FC<VirtualTour360IconProps> = ({
  className = 'w-6 h-6 sm:w-7 sm:h-7'
}) => {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      {/* 360° Typography */}
      {/* Digit '3' */}
      <path
        d="M32 37.5 C 33 34.5 35.5 32.5 39 32.5 C 43.5 32.5 46.5 35.5 46.5 39.5 C 46.5 43 43.5 45.2 40 45.2 C 44 45.2 47.5 47.5 47.5 52 C 47.5 56.5 43.5 59.5 39 59.5 C 34.5 59.5 31.8 56.5 31 53"
        stroke="currentColor"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Digit '6' */}
      <path
        d="M58 33.5 L 49.8 46.8 C 51.5 45.2 53.6 44.5 56 44.5 C 60.5 44.5 64 47.8 64 52.2 C 64 56.5 60.5 59.5 56 59.5 C 51 59.5 47.5 55.5 47.5 49.5 C 47.5 42 51.5 33.5 57.5 32.5"
        stroke="currentColor"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Digit '0' */}
      <path
        d="M72 32.5 C 67 32.5 64.5 36.5 64.5 46 C 64.5 55.5 67 59.5 72 59.5 C 77 59.5 79.5 55.5 79.5 46 C 79.5 36.5 77 32.5 72 32.5 Z"
        stroke="currentColor"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Degree Symbol '°' */}
      <circle
        cx="83"
        cy="33.5"
        r="3.5"
        stroke="currentColor"
        strokeWidth="3.2"
      />

      {/* Elliptical Orbit Loop with break at bottom */}
      <path
        d="M 52.5 65.5 C 74 65.5 89 61.5 89 57 C 89 52 71.5 48 50 48 C 28.5 48 11 52 11 57 C 11 61.5 25.5 65.5 39 65.5"
        stroke="currentColor"
        strokeWidth="4"
        strokeLinecap="round"
      />

      {/* Outlined Triangle Arrowhead pointing clockwise (rightward) */}
      <path
        d="M 39 59.5 L 48.5 65.5 L 39 71.5 Z"
        stroke="currentColor"
        strokeWidth="4"
        strokeLinejoin="round"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
};
