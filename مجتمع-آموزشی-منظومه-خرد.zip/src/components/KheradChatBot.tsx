import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, 
  ChevronDown, 
  X, 
  Minus, 
  Maximize2, 
  Minimize2, 
  Send, 
  Sparkles,
  ExternalLink,
  Bot,
  User,
  RotateCcw,
  Headset
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface Message {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  actions?: {
    label: string;
    action: () => void;
  }[];
}

interface KheradChatBotProps {
  onOpenApply?: () => void;
  onOpenTour?: () => void;
  onSelectCategory?: (categoryId: string, subItemId?: string) => void;
  isMainMenuOpen?: boolean;
}

export const ChatAvatarImage: React.FC<{ className?: string; alt?: string }> = ({ 
  className = "w-full h-full object-cover", 
  alt = "پشتیبانی آنلاین مجتمع آموزشی خرد" 
}) => {
  return (
    <div className={`w-full h-full flex items-center justify-center bg-[#0b82c6] text-white ${className}`}>
      <Headset className="w-1/2 h-1/2 stroke-[1.8]" />
    </div>
  );
};

export const KheradChatBot: React.FC<KheradChatBotProps> = ({
  onOpenApply,
  onOpenTour,
  onSelectCategory,
  isMainMenuOpen = false
}) => {
  const { isPersian } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isCalloutDismissed, setIsCalloutDismissed] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const initialBotMessage: Message = {
    id: 'welcome-1',
    sender: 'bot',
    text: isPersian 
      ? 'سلام، به مجتمع آموزشی خرد خوش آمدید! من راهنمای آموزشی خرد هستم. آماده‌ام تا به پرسش‌های شما درباره‌ی پذیرش، پایه‌های تحصیلی، رویکرد آموزشی و امکانات مجتمع آموزشی خرد پاسخ دهم.'
      : 'Welcome to Kherad Educational Complex! I am your guide for admissions, curriculum, academic stages, and school facilities.',
    timestamp: isPersian ? 'امروز' : 'Today',
    actions: [
      {
        label: isPersian ? 'پیش‌ثبت‌نام آنلاین' : 'Online Admissions',
        action: () => onOpenApply?.()
      },
      {
        label: isPersian ? 'گشت مجازی مجتمع آموزشی خرد' : 'Virtual School Tour',
        action: () => onOpenTour?.()
      }
    ]
  };

  const [messages, setMessages] = useState<Message[]>([initialBotMessage]);

  useEffect(() => {
    setMessages([initialBotMessage]);
  }, [isPersian]);

  const quickQuestions = [
    'شرایط و زمان پیش‌ثبت‌نام چیست؟',
    'پایه‌های تحصیلی و دوره‌ها',
    'امکانات مجتمع آموزشی خرد و نشانی ولنجک',
    'رویکرد آموزشی و پژوهشی خرد'
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen && !isMinimized) {
      scrollToBottom();
    }
  }, [messages, isOpen, isMinimized, isTyping]);

  const handleOpen = () => {
    setIsOpen(true);
    setIsMinimized(false);
  };

  const handleToggle = () => {
    if (isOpen) {
      setIsOpen(false);
    } else {
      handleOpen();
    }
  };

  const getKnowledgeResponse = (userQuery: string): { text: string; actions?: { label: string; action: () => void }[] } => {
    const q = userQuery.toLowerCase().trim();

    if (q.includes('ثبت‌نام') || q.includes('پذیرش') || q.includes('ورود') || q.includes('ازمون') || q.includes('آزمون') || q.includes('مصاحبه')) {
      return {
        text: 'فرآیند پیش‌ثبت‌نام برای سال تحصیلی جدید به‌صورت آنلاین از طریق سامانه پذیرش مجتمع آموزشی خرد انجام می‌شود. مراحل شامل تکمیل فرم مشخصات دانش‌آموز و اولیا، بارگذاری کارنامه و سوابق، و در صورت تایید اولیه دعوت به جلسه گفتگوی تعاملی یا سنجش تشخیصی است.',
        actions: [
          {
            label: 'تکمیل فرم پیش‌ثبت‌نام آنلاین',
            action: () => onOpenApply?.()
          }
        ]
      };
    }

    if (q.includes('پایه') || q.includes('دوره') || q.includes('دبستان') || q.includes('دبیرستان') || q.includes('متوسطه') || q.includes('هنرستان') || q.includes('پیش‌دبستان') || q.includes('مدرسه')) {
      return {
        text: 'مجتمع آموزشی خرد شامل تمامی دوره‌های تحصیلی دخترانه است:\n• دوره پیش‌دبستانی و دبستان\n• دوره متوسطه اول\n• دوره متوسطه دوم (رشته‌های ریاضی، تجربی و علوم انسانی)\n• هنرستان خرد (رشته‌های هنر، معماری و گرافیک)',
        actions: [
          {
            label: 'مشاهده دوره‌های تحصیلی',
            action: () => onSelectCategory?.('schools', 'elementary')
          }
        ]
      };
    }

    if (q.includes('پردیس') || q.includes('امکانات') || q.includes('تور') || q.includes('استخر') || q.includes('آزمایشگاه') || q.includes('کتابخانه')) {
      return {
        text: 'مجتمع آموزشی خرد در منطقه ولنجک تهران با مساحت بیش از ۱۲٬۰۰۰ مترمربع در ۷ طبقه، مجهز به آزمایشگاه‌های پیشرفته نانو، فیزیک و زیست، کتابخانه‌ی جامع، سالن اجتماعات و تئاتر، استخر اختصاصی، زمین‌های ورزشی سرپوشیده و استودیوهای هنر و معماری است.',
        actions: [
          {
            label: 'ورود به تور مجازی مجتمع آموزشی خرد',
            action: () => onOpenTour?.()
          }
        ]
      };
    }

    if (q.includes('آدرس') || q.includes('نشانی') || q.includes('تلفن') || q.includes('تماس') || q.includes('کجاست') || q.includes('ولنجک')) {
      return {
        text: '📍 نشانی مرکزی: تهران، ولنجک، بلوار دانشجو، بالاتر از میدان یاسمن، مجتمع آموزشی خرد\n\n☎️ شماره‌های تماس:\n• روابط عمومی و تلفنخانه: ۰۲۱-۲۲۱۷۰۰۰۰\n• دفتر پذیرش دانش‌آموز: ۰۲۱-۲۲۱۷۰۰۰۱\n• ایمیل سازمانی: info@kheradedu.ir',
        actions: [
          {
            label: 'مشاهده اطلاعات تماس و موقعیت',
            action: () => onSelectCategory?.('contact', 'contact-us')
          }
        ]
      };
    }

    if (q.includes('شهریه') || q.includes('هزینه') || q.includes('بورسیه') || q.includes('مالی')) {
      return {
        text: 'شهریه مجتمع آموزشی خرد مطابق مصوبات سالانه وزارت آموزش و پرورش و بر اساس جدول خدمات آموزشی فوق‌برنامه، کارگاه‌های تخصصی، وعده‌های غذایی گرم و اردوهای پژوهشی تعیین می‌گردد. همچنین برای داوطلبان برتر علمی و هنری، امکان بهره‌مندی از بورسیه بنیاد پایدار خرد وجود دارد.',
        actions: [
          {
            label: 'اطلاعات بیشتر درباره پذیرش',
            action: () => onOpenApply?.()
          }
        ]
      };
    }

    if (q.includes('رویکرد') || q.includes('پژوهش') || q.includes('فرهنگ') || q.includes('تاریخچه') || q.includes('تاسیس')) {
      return {
        text: 'مجتمع آموزشی خرد در سال ۱۳۷۹ با چشم‌انداز تربیت انسان‌هایی خردورز، نقاد، متعهد و کارآفرین پایه‌گذاری شد. تمرکز این موسسه بر یادگیری پروژه‌محور، پرورش تفکر انتقادی، اخلاق‌مداری و پیوند میان هنر، ادبیات و علوم تجربی است.',
        actions: [
          {
            label: 'درباره موسس و تاریخچه خرد',
            action: () => onSelectCategory?.('about', 'about-kherad')
          }
        ]
      };
    }

    return {
      text: `سپاس از پرسش شما درباره‌ی «${userQuery}». برای اطلاعات تکمیلی می‌توانید از منوی سایت یا بخش‌های پذیرش آنلاین و تور مجتمع آموزشی خرد بازدید نمایید، یا مستقیماً با کارشناسان پذیرش با شماره ۰۲۱-۲۲۱۷۰۰۰۱ تماس حاصل فرمایید.`,
      actions: [
        {
          label: 'فرم پیش‌ثبت‌نام',
          action: () => onOpenApply?.()
        },
        {
          label: 'تور مجازی مجتمع آموزشی خرد',
          action: () => onOpenTour?.()
        }
      ]
    };
  };

  const handleSendMessage = (textToSend?: string) => {
    const messageText = (textToSend || inputValue).trim();
    if (!messageText) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: messageText,
      timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    // Simulate smart, prompt educational assistant reply
    setTimeout(() => {
      const resp = getKnowledgeResponse(messageText);
      const botMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: resp.text,
        timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
        actions: resp.actions
      };
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 650);
  };

  const handleResetChat = () => {
    setMessages([initialBotMessage]);
  };

  return (
    <>
      {/* Floating Interactive Dialogue Box Launcher */}
      <div 
        id="kherad-chatbot-launcher"
        className={`fixed bottom-5 right-5 sm:bottom-7 sm:right-7 select-none transition-all duration-300 z-40 ${
          isMainMenuOpen || isDismissed
            ? 'opacity-0 pointer-events-none -z-10 scale-75' 
            : 'opacity-100 pointer-events-auto scale-100'
        }`}
        dir="rtl"
      >
        {/* Support Specialist Dialogue Box Card - Sole Interactive Launcher */}
        <AnimatePresence>
          {!isOpen && !isCalloutDismissed && (
            <motion.div
              initial={{ opacity: 0, y: 14, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.92 }}
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="relative w-[285px] sm:w-[310px] bg-white rounded-2xl p-3 sm:p-3.5 shadow-[0_10px_35px_rgba(0,0,0,0.12)] hover:shadow-[0_14px_45px_rgba(0,0,0,0.16)] border border-slate-100 text-slate-800 cursor-pointer group transition-all select-none"
              onClick={handleToggle}
              role="button"
              tabIndex={0}
              aria-label="گفت‌وگوی آنلاین - چطور میتونم کمکتون کنم؟"
            >
              {/* Dismiss 'X' Button on Dialogue Box */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsCalloutDismissed(true);
                  setIsDismissed(true);
                }}
                className="absolute top-2.5 left-2.5 w-5 h-5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-400 hover:text-slate-700 flex items-center justify-center transition-colors cursor-pointer z-10"
                title="بستن پیام"
                aria-label="بستن پیام"
              >
                <X className="w-3 h-3 stroke-[2.2]" />
              </button>

              {/* Dialogue Box Content */}
              <div className="flex items-center gap-3 pl-4">
                {/* Circular Customer Service Avatar */}
                <div className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-gradient-to-tr from-[#0b82c6] to-[#0284c7] text-white flex items-center justify-center shrink-0 shadow-sm transition-transform group-hover:scale-105">
                  <Headset className="w-6 h-6 stroke-[1.7]" />
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white ring-1 ring-emerald-500/20" />
                </div>

                {/* Text Content */}
                <div className="flex flex-col text-right flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-[13px] sm:text-[13.5px] font-bold text-slate-900 group-hover:text-[#0b82c6] transition-colors leading-tight truncate">
                      {isPersian ? 'گفت‌وگوی آنلاین' : 'Online Support'}
                    </span>
                  </div>

                  {/* Requested phrase: چطور میتونم کمکتون کنم؟ */}
                  <div className="mt-1 text-[12px] sm:text-[12.5px] text-slate-600 leading-snug">
                    <span className="font-medium text-slate-700">
                      {isPersian ? 'چطور میتونم کمکتون کنم؟' : 'How can I help you?'}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Discrete restore chip when chat is dismissed */}
      {isDismissed && !isMainMenuOpen && (
        <motion.button
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          onClick={() => {
            setIsDismissed(false);
            setIsCalloutDismissed(false);
          }}
          className="fixed bottom-4 right-4 z-40 bg-white/95 hover:bg-white text-slate-700 hover:text-[#0b82c6] text-[11px] font-medium py-1.5 px-3 rounded-full shadow-md border border-slate-200/90 flex items-center gap-1.5 transition-all cursor-pointer select-none"
          title="بازگردانی چت آنلاین"
          dir="rtl"
        >
          <MessageSquare className="w-3.5 h-3.5 text-[#0b82c6]" />
          <span>پشتیبانی آنلاین</span>
        </motion.button>
      )}

      {/* Floating Chatbot Window - Design directly inspired by screenshot 2, styled to Kherad aesthetic */}
      <AnimatePresence>
        {isOpen && !isMinimized && !isMainMenuOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 20 }}
            transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
            id="kherad-chatbot-window"
            className={`fixed bottom-5 sm:bottom-7 right-4 sm:right-7 z-40 flex flex-col bg-white rounded-2xl shadow-[0_15px_50px_rgba(15,37,64,0.22)] border border-slate-200 overflow-hidden font-persian select-none transition-all duration-300 ${
              isMaximized
                ? 'w-[calc(100vw-2rem)] sm:w-[540px] md:w-[600px] h-[82vh] max-h-[760px]'
                : 'w-[calc(100vw-2rem)] sm:w-[380px] md:w-[410px] h-[520px] sm:h-[560px] max-h-[78vh]'
            }`}
            dir={isPersian ? 'rtl' : 'ltr'}
          >
            {/* Header: Dark Kherad Navy Blue with avatar, title, and control icons */}
            <div className="bg-[#112544] text-white px-4 py-3.5 flex items-center justify-between shrink-0 shadow-xs">
              <div className="flex items-center gap-2.5">
                <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-full overflow-hidden border-2 border-white/30 shrink-0 shadow-xs bg-[#3B82F6]">
                  <ChatAvatarImage className="w-full h-full object-cover" />
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-[#112544]" />
                </div>
                <div className={isPersian ? 'text-right' : 'text-left'}>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-[14px] sm:text-[15px] font-bold tracking-tight text-white">
                      {isPersian ? 'کارشناس پاسخگویی آنلاین' : 'Online Support Specialist'}
                    </h3>
                  </div>
                  <p className="text-[11px] text-white/70 font-normal">
                    {isPersian ? 'در خدمت شما هستیم! • سامانه پشتیبانی' : 'We are here to assist! • Support System'}
                  </p>
                </div>
              </div>

              {/* Left Side (in RTL): Action buttons (Maximize, Minimize, Close) matching screenshot */}
              <div className="flex items-center gap-1 text-white/75" dir="ltr">
                <button
                  onClick={handleResetChat}
                  className="p-1.5 hover:bg-white/10 rounded-md transition-colors cursor-pointer text-white/60 hover:text-white"
                  title="شروع مجدد گفتگو"
                  aria-label="شروع مجدد گفتگو"
                >
                  <RotateCcw className="w-3.5 h-3.5 stroke-[2]" />
                </button>
                <button
                  onClick={() => setIsMaximized(!isMaximized)}
                  className="p-1.5 hover:bg-white/10 rounded-md transition-colors cursor-pointer text-white/75 hover:text-white"
                  title={isMaximized ? 'کوچک‌نمایی' : 'بزرگ‌نمایی'}
                  aria-label="تغییر اندازه"
                >
                  {isMaximized ? (
                    <Minimize2 className="w-4 h-4 stroke-[2]" />
                  ) : (
                    <Maximize2 className="w-4 h-4 stroke-[2]" />
                  )}
                </button>
                <button
                  onClick={() => setIsMinimized(true)}
                  className="p-1.5 hover:bg-white/10 rounded-md transition-colors cursor-pointer text-white/75 hover:text-white"
                  title="کمینه‌سازی"
                  aria-label="کمینه‌سازی"
                >
                  <Minus className="w-4 h-4 stroke-[2.2]" />
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 hover:bg-white/10 rounded-md transition-colors cursor-pointer text-white/75 hover:text-white"
                  title="بستن"
                  aria-label="بستن پنجره"
                >
                  <X className="w-4 h-4 stroke-[2.2]" />
                </button>
              </div>
            </div>

            {/* Chat Body: Messages history - Refined, luxurious, clean aesthetic */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 bg-[#FAFBFD]">
              {/* Apple-style Gray Capsule Status Stamp */}
              <div className="text-center py-1">
                <span className="text-[11px] text-[#48484A] bg-[#EBEDF0] px-4 py-1.5 rounded-full font-medium tracking-wide border border-black/[0.04]">
                  پاسخگوی شبانه‌روزی مجتمع آموزشی خرد
                </span>
              </div>

              {/* Messages */}
              {messages.map((msg) => {
                const isBot = msg.sender === 'bot';
                return (
                  <div key={msg.id} className="space-y-1">
                    {/* Bot Name Label */}
                    {isBot && (
                      <div className="flex items-center gap-1.5 pr-9 text-[11px] font-medium text-slate-400">
                        <span>کارشناس پاسخگویی آنلاین</span>
                        <span className="text-[10px] text-slate-300 font-light">
                          {msg.timestamp}
                        </span>
                      </div>
                    )}

                    <div
                      className={`flex items-start gap-2.5 ${
                        isBot ? 'justify-start' : 'justify-end'
                      }`}
                    >
                      {/* Bot Avatar */}
                      {isBot && (
                        <div className="w-7 h-7 rounded-full overflow-hidden shrink-0 mt-0.5 border border-[#2A6AB2]/20 shadow-xs bg-[#3B82F6]">
                          <ChatAvatarImage className="w-full h-full object-cover" />
                        </div>
                      )}

                      {/* Message Bubble */}
                      <div
                        className={`rounded-2xl px-4 py-3 text-[13px] leading-[1.75] whitespace-pre-line ${
                          isBot
                            ? 'flex-1 bg-white text-slate-800 border border-black/[0.06] shadow-[0_2px_12px_rgba(0,0,0,0.02)] rounded-tr-xs'
                            : 'max-w-[85%] bg-[#2A6AB2] text-white shadow-[0_2px_8px_rgba(42,106,178,0.22)] rounded-tl-xs text-right font-light'
                        }`}
                      >
                        {msg.text}

                        {/* Embedded Action Buttons if present - Fully rounded capsule pills matching reference */}
                        {msg.actions && msg.actions.length > 0 && (
                          <div className="mt-3 pt-2.5 border-t border-slate-100/90 flex flex-wrap gap-2">
                            {msg.actions.map((act, i) => (
                              <button
                                key={i}
                                onClick={() => {
                                  act.action();
                                  setIsOpen(false);
                                }}
                                className="inline-flex items-center gap-1.5 text-xs bg-[#2A6AB2] hover:bg-[#1E5594] text-white font-medium px-4 py-1.5 rounded-full transition-all duration-200 cursor-pointer shadow-xs hover:scale-[1.02] active:scale-[0.98]"
                              >
                                <span>{act.label}</span>
                                <ExternalLink className="w-3 h-3 stroke-[2]" />
                              </button>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* User Avatar */}
                      {!isBot && (
                        <div className="w-7 h-7 rounded-full bg-[#183962] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                          <User className="w-3.5 h-3.5 stroke-[1.8]" />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* Typing indicator */}
              {isTyping && (
                <div className="flex items-start gap-2.5 justify-start">
                  <div className="w-7 h-7 rounded-full bg-[#2A6AB2]/10 text-[#2A6AB2] flex items-center justify-center shrink-0 mt-0.5 border border-[#2A6AB2]/15">
                    <Bot className="w-3.5 h-3.5 stroke-[1.8]" />
                  </div>
                  <div className="bg-white border border-black/[0.06] rounded-2xl rounded-tr-xs px-3.5 py-2.5 shadow-2xs flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#2A6AB2] rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <span className="w-1.5 h-1.5 bg-[#2A6AB2] rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <span className="w-1.5 h-1.5 bg-[#2A6AB2] rounded-full animate-bounce" />
                  </div>
                </div>
              )}

              {/* Quick suggestions when chat is at beginning - Preserved completely with cleaner card design */}
              {messages.length <= 2 && (
                <div className="pt-2">
                  <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-400 mb-2">
                    <Sparkles className="w-3 h-3 text-[#2A6AB2]" />
                    <span>پرسش‌های پرتکرار اولیا:</span>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    {quickQuestions.map((q, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSendMessage(q)}
                        className="text-right text-[12px] bg-white hover:bg-[#F3F7FC] text-slate-700 hover:text-[#2A6AB2] px-4 py-2.5 rounded-full border border-black/[0.08] hover:border-[#2A6AB2]/40 transition-all duration-200 cursor-pointer shadow-[0_1px_4px_rgba(0,0,0,0.02)] font-normal flex items-center justify-between group"
                      >
                        <span>{q}</span>
                        <span className="text-slate-300 group-hover:text-[#2A6AB2] text-[13px] transition-transform duration-200 group-hover:-translate-x-0.5">‹</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Bar: Input field + Send Button - Sleeker, simpler and more luxurious */}
            <div className="p-3 sm:p-3.5 bg-white border-t border-black/[0.05] shrink-0">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendMessage();
                }}
                className="flex items-center gap-2"
                dir={isPersian ? 'rtl' : 'ltr'}
              >
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={isPersian ? 'پیام یا پرسش خود را بنویسید...' : 'Type your question or message...'}
                    className="w-full bg-[#F5F7FA] focus:bg-white text-slate-800 placeholder-slate-400 text-xs sm:text-[13px] px-4 py-2.5 rounded-full border border-transparent focus:border-[#2A6AB2]/30 focus:ring-2 focus:ring-[#2A6AB2]/5 focus:outline-none transition-all duration-200 font-persian"
                  />
                </div>
                <button
                  type="submit"
                  disabled={!inputValue.trim()}
                  className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer shrink-0 ${
                    inputValue.trim()
                      ? 'bg-[#112544] hover:bg-[#0C1E38] text-white shadow-[0_2px_8px_rgba(17,37,68,0.3)] hover:scale-105 active:scale-95'
                      : 'bg-[#F5F7FA] text-slate-300 cursor-not-allowed'
                  }`}
                  aria-label={isPersian ? 'ارسال پیام' : 'Send message'}
                  title={isPersian ? 'ارسال پیام' : 'Send message'}
                >
                  <Send className={`w-4 h-4 stroke-[2] ${isPersian ? '-rotate-90 sm:-rotate-90' : 'rotate-90 sm:rotate-90'}`} />
                </button>
              </form>
            </div>

            {/* Footer Bar: Powered by / Privacy matching screenshot 2 */}
            <div className="bg-[#F8FAFC] py-1.5 px-3 border-t border-slate-100 text-center text-[10.5px] text-slate-600 flex items-center justify-center gap-2">
              <span>{isPersian ? 'سامانه پاسخگویی منظومه‌ی خرد' : 'Kherad Information Service'}</span>
              <span className="text-slate-400">|</span>
              <span className="hover:text-slate-800 cursor-pointer">{isPersian ? 'حفظ حریم خصوصی' : 'Privacy Policy'}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
