import React from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface KheradSchoolsSectionProps {
  onSelectSchool: (schoolId: string) => void;
}

export const KheradSchoolsSection: React.FC<KheradSchoolsSectionProps> = ({ onSelectSchool }) => {
  const { t, isPersian } = useLanguage();

  const schoolMeta: Record<string, { photo: string; logo: string; color: string }> = {
    'preschool': {
      photo: '/assets/kherad-brand/photos/30.webp',
      logo: '/assets/kherad-brand/logos/84.svg',
      color: '#aeca26'
    },
    'primary': {
      photo: '/assets/kherad-brand/photos/8.webp',
      logo: '/assets/kherad-brand/logos/82.svg',
      color: '#eb5f89'
    },
    'middle-school': {
      photo: '/assets/kherad-brand/photos/18.webp',
      logo: '/assets/kherad-brand/logos/79.svg',
      color: '#00a87a'
    },
    'high-school': {
      photo: '/assets/kherad-brand/photos/4.webp',
      logo: '/assets/kherad-brand/logos/78.svg',
      color: '#faba00'
    },
    'vocational-school': {
      photo: '/assets/kherad-brand/photos/14.webp',
      logo: '/assets/kherad-brand/logos/81.svg',
      color: '#0db4c3'
    },
  };

  const ArrowIcon = isPersian ? ArrowLeft : ArrowRight;

  return (
    <section className="w-full bg-[#F5F5F7] py-16 md:py-24 px-4 sm:px-8 border-b border-black/[0.05] font-persian overflow-hidden" dir={isPersian ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div 
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-3xl mx-auto mb-14"
        >
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif-heading font-bold text-slate-900 tracking-tight">
            {t.schools.title}
          </h2>
          <p className="mt-3 text-slate-500 text-xs sm:text-sm leading-relaxed font-light">
            {t.schools.subtitle}
          </p>
        </motion.div>

        {/* Schools Cards Grid with Repository Authentic Photos - Sharp architectural corners */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {t.schools.items.map((school, index) => {
            const meta = schoolMeta[school.id] || {
              photo: '/assets/kherad-brand/photos/24.webp',
              logo: '/assets/kherad-brand/logos/82.svg',
              color: '#057dc1'
            };
            return (
              <motion.div
                key={school.id}
                initial={{ opacity: 0, y: 32 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.75, delay: (index % 3) * 0.1, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{ y: -4, transition: { duration: 0.25, ease: 'easeOut' } }}
                className="bg-white rounded-none overflow-hidden shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_16px_40px_rgba(0,0,0,0.07)] transition-shadow flex flex-col border border-black/[0.06] group"
              >
                {/* Authentic Repository Photo */}
                <div className="p-3 bg-[#F5F5F7]/70 border-b border-black/[0.04]">
                  <div className="relative overflow-hidden aspect-[16/10] rounded-none bg-slate-200">
                    <img
                      src={meta.photo}
                      alt={school.title}
                      className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500 rounded-none"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent pointer-events-none" />
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <h3 className="text-lg sm:text-xl font-bold text-slate-900 group-hover:text-[#057dc1] transition-colors leading-tight font-serif-heading">
                      {school.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-light">
                      {school.desc}
                    </p>
                  </div>

                  <div className="pt-2">
                    <motion.button
                      whileTap={{ scale: 0.98 }}
                      onClick={() => onSelectSchool(school.id)}
                      className="w-full inline-flex items-center justify-center gap-2 bg-[#282C34] hover:bg-[#1c1f26] text-white border border-transparent text-xs sm:text-sm font-semibold py-2.5 px-4 rounded-none transition-all duration-200 shadow-2xs hover:shadow-md cursor-pointer group"
                    >
                      <span className="text-white">{school.btnText}</span>
                      <ArrowIcon className={`w-4 h-4 stroke-[1.5] text-white transition-transform ${isPersian ? 'group-hover:-translate-x-1' : 'group-hover:translate-x-1'}`} />
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
