import React from 'react';
import { Music, Palette, Leaf, Dumbbell, BookOpen, Heart, ArrowLeft, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface KheradInstitutionsSectionProps {
  onSelectHub: (hubId: string) => void;
}

export const KheradInstitutionsSection: React.FC<KheradInstitutionsSectionProps> = ({ onSelectHub }) => {
  const { t, isPersian } = useLanguage();

  const hubPhotos: Record<string, string> = {
    'culture': '/assets/photos/history.jpg',
    'art': '/assets/photos/junior-school.jpg',
    'paydar': '/assets/photos/inspections-awards.jpg',
    'sports': '/assets/photos/hero-centenary.jpg',
    'publish': '/assets/photos/academic-results.jpg',
    'charity': '/assets/photos/governance.jpg',
  };

  const getHubIcon = (id: string) => {
    switch (id) {
      case 'culture':
        return <BookOpen className="w-4.5 h-4.5 stroke-[1.4] text-[#2A96FF]" />;
      case 'art':
        return <Music className="w-4.5 h-4.5 stroke-[1.4] text-[#2A96FF]" />;
      case 'paydar':
        return <Leaf className="w-4.5 h-4.5 stroke-[1.4] text-emerald-500" />;
      case 'sports':
        return <Dumbbell className="w-4.5 h-4.5 stroke-[1.4] text-[#2A96FF]" />;
      case 'publish':
        return <Palette className="w-4.5 h-4.5 stroke-[1.4] text-purple-500" />;
      case 'charity':
      default:
        return <Heart className="w-4.5 h-4.5 stroke-[1.4] text-rose-500" />;
    }
  };

  const ArrowIcon = isPersian ? ArrowLeft : ArrowRight;

  return (
    <section className="w-full bg-white py-16 md:py-24 px-4 sm:px-8 border-b border-black/[0.05] font-persian overflow-hidden" dir={isPersian ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-3xl mx-auto mb-14"
        >
          <div className="inline-flex items-center gap-2 bg-[#F5F5F7] text-slate-700 text-xs font-semibold px-4 py-1.5 rounded-none border border-black/[0.06] shadow-2xs mb-3">
            <span className="w-1.5 h-1.5 rounded-none bg-[#2A96FF]" />
            <span>{t.hubs.badge}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif-heading font-bold text-slate-900 tracking-tight">
            {t.hubs.title}
          </h2>
          <p className="mt-3 text-slate-500 text-xs sm:text-sm leading-relaxed font-light">
            {t.hubs.subtitle}
          </p>
        </motion.div>

        {/* Grid with Repository Authentic Photos - Sharp architectural corners */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {t.hubs.items.map((hub, index) => {
            const photoUrl = hubPhotos[hub.id] || '/assets/photos/history.jpg';
            return (
              <motion.div
                key={hub.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.75, delay: (index % 3) * 0.1, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{ y: -4, transition: { duration: 0.25, ease: 'easeOut' } }}
                className="bg-[#F5F5F7] rounded-none p-5 border border-black/[0.06] shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_16px_40px_rgba(0,0,0,0.07)] transition-shadow flex flex-col justify-between group cursor-pointer"
                onClick={() => onSelectHub(hub.id)}
              >
                <div className="space-y-3.5">
                  {/* Photo Container */}
                  <div className="relative overflow-hidden aspect-[16/9] rounded-none bg-slate-200">
                    <img
                      src={photoUrl}
                      alt={hub.title}
                      className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500 rounded-none"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent pointer-events-none" />
                    <span className={`absolute top-2.5 ${isPersian ? 'right-2.5' : 'left-2.5'} bg-white/90 backdrop-blur-xs text-slate-800 text-[10px] font-semibold px-2.5 py-1 rounded-none shadow-2xs`}>
                      {hub.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-2.5 pt-1">
                    <div className="p-2 rounded-none bg-white shadow-2xs border border-black/[0.05] group-hover:border-[#2A96FF]/30 transition-colors">
                      {getHubIcon(hub.id)}
                    </div>
                    <h3 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-[#2A96FF] transition-colors font-serif-heading">
                      {hub.title}
                    </h3>
                  </div>

                  <p className="text-xs text-slate-500 leading-relaxed font-light">
                    {hub.summary}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-black/[0.05]">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectHub(hub.id);
                    }}
                    className="w-full flex items-center justify-between text-xs font-semibold text-slate-700 group-hover:text-[#2A96FF] transition-colors cursor-pointer"
                  >
                    <span>{t.hubs.cta}</span>
                    <ArrowIcon className={`w-4 h-4 stroke-[1.5] ${isPersian ? 'group-hover:-translate-x-1' : 'group-hover:translate-x-1'} transition-transform`} />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
