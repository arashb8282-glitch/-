import React, { useState } from 'react';
import { X, Send, CheckCircle2, MessageSquare, Phone, Mail, User } from 'lucide-react';
import { Language } from '../types';

interface EnquiryModalProps {
  isOpen: boolean;
  lang: Language;
  onClose: () => void;
}

export const EnquiryModal: React.FC<EnquiryModalProps> = ({ isOpen, lang, onClose }) => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    parentName: '',
    email: '',
    phone: '',
    childName: '',
    childDob: '',
    targetYear: '2025/2026',
    schoolStage: 'infant',
    notes: ''
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl overflow-hidden my-6 border border-gray-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#001744] text-white px-6 py-4 flex items-center justify-between border-b border-[#002169]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-[#CE0E2D]">
              <MessageSquare className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-serif-heading text-white">
                {lang === 'fa' ? 'فرم استعلام و مشاوره پذیرش تانگلین' : 'Tanglin Admissions Enquiry'}
              </h2>
              <p className="text-xs text-slate-300">
                {lang === 'fa' ? 'پاسخگویی تیم پذیرش ظرف ۲۴ ساعت کاری' : 'Admissions team response within 24 business hours'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8">
          {submitted ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 bg-[#e6f9ed] text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-bold text-[#002169]">
                {lang === 'fa' ? 'درخواست شما با موفقیت ثبت گردید' : 'Enquiry Received Successfully'}
              </h3>
              <p className="text-gray-600 text-sm max-w-md mx-auto">
                {lang === 'fa'
                  ? `با سپاس از شما ${formData.parentName || 'گرامی'}. همکاران ما در دپارتمان پذیرش تانگلین به زودی از طریق ایمیل ${formData.email || ''} با شما تماس خواهند گرفت.`
                  : `Thank you, ${formData.parentName || 'valued parent'}. A member of the Tanglin Admissions team will contact you shortly via ${formData.email || 'your email'}.`}
              </p>
              <div className="pt-4">
                <button
                  onClick={() => {
                    setSubmitted(false);
                    onClose();
                  }}
                  className="bg-[#002169] text-white text-xs font-bold px-6 py-2.5 rounded hover:bg-[#001744] transition-colors"
                >
                  {lang === 'fa' ? 'بستن' : 'Done'}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-left">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    {lang === 'fa' ? 'نام و نام‌خانوادگی والد' : 'Parent / Guardian Name *'}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                    <input
                      required
                      type="text"
                      value={formData.parentName}
                      onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                      placeholder={lang === 'fa' ? 'مثال: سارا محمدی' : 'e.g., Sarah Jenkins'}
                      className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-full text-xs focus:ring-2 focus:ring-[#002169] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    {lang === 'fa' ? 'آدرس ایمیل' : 'Email Address *'}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                    <input
                      required
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="parent@example.com"
                      className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-full text-xs focus:ring-2 focus:ring-[#002169] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    {lang === 'fa' ? 'شماره تماس با پیش‌شماره' : 'Contact Phone Number *'}
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                    <input
                      required
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+65 9123 4567"
                      className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-full text-xs focus:ring-2 focus:ring-[#002169] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    {lang === 'fa' ? 'مقطع تحصیلی مورد نظر' : 'School Stage of Interest'}
                  </label>
                  <select
                    value={formData.schoolStage}
                    onChange={(e) => setFormData({ ...formData, schoolStage: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-full text-xs focus:ring-2 focus:ring-[#002169] focus:outline-none bg-white cursor-pointer"
                  >
                    <option value="infant">Infant School (Age 3–7, Nursery - Y2)</option>
                    <option value="junior">Junior School (Age 7–11, Y3 - Y6)</option>
                    <option value="middle">Middle School (Age 11–14, Y7 - Y9)</option>
                    <option value="upper">Upper School (Age 14–16, Y10 - Y11)</option>
                    <option value="sixth-form">Sixth Form (Age 16–18, A Level / IB)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  {lang === 'fa' ? 'پیام یا سوالات شما' : 'Questions or Comments'}
                </label>
                <textarea
                  rows={3}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder={lang === 'fa' ? 'توضیحاتی درباره سوابق تحصیلی یا تاریخ ورود مد نظر خود بنویسید...' : 'Please let us know your child’s educational background or any questions...'}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-xs focus:ring-2 focus:ring-[#002169] focus:outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-900"
                >
                  {lang === 'fa' ? 'انصراف' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 bg-[#CE0E2D] hover:bg-[#b00b25] text-white text-xs font-bold px-6 py-2.5 rounded transition-colors shadow-md"
                >
                  <span>{lang === 'fa' ? 'ارسال استعلام' : 'Submit Enquiry'}</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
