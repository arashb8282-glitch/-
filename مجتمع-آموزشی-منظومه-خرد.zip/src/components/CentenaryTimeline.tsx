import React, { useState } from 'react';
import { timelineMilestones } from '../data/tanglinData';
import { Language, TimelineMilestone } from '../types';
import { Sparkles, Calendar, ArrowRight, Award } from 'lucide-react';

interface CentenaryTimelineProps {
  lang: Language;
}

export const CentenaryTimeline: React.FC<CentenaryTimelineProps> = ({ lang }) => {
  const isPersian = lang === 'fa';
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeMilestone, setActiveMilestone] = useState<TimelineMilestone>(timelineMilestones[0]);

  const categories = ['All', 'Foundation', 'Growth', 'Academic', 'Centenary'];

  const filteredMilestones = selectedCategory === 'All'
    ? timelineMilestones
    : timelineMilestones.filter(m => m.category === selectedCategory);

  return (
    <section id="centenary" className="py-20 bg-[#0B1B2B] text-white relative overflow-hidden">
      {/* Background Decorative Crest Watermark */}
      <div className="absolute -right-20 top-20 w-96 h-96 rounded-full bg-[#C5A85C]/5 filter blur-3xl pointer-events-none" />
      <div className="absolute -left-20 bottom-20 w-96 h-96 rounded-full bg-[#162E4A]/40 filter blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#C5A85C]/15 border border-[#C5A85C]/40 text-[#E5C97A] text-xs font-bold uppercase tracking-widest mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#C5A85C]" />
            <span>1925 – 2025</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-serif-heading text-white">
            {isPersian ? 'یک قرن اصالت و افتخار در سنگاپور' : '100 Years: Our Centenary Heritage'}
          </h2>
          <div className="w-16 h-1 bg-[#C5A85C] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-300 text-sm sm:text-base">
            {isPersian
              ? 'سفر تاریخی تانگلین از تاسیس با ۵ دانش‌آموز در سال ۱۹۲۵ تا تبدیل شدن به معتبرترین مدرسه بریتانیایی جنوب شرق آسیا'
              : 'From our modest beginnings in 1925 with five pupils to Southeast Asia’s foremost British international institution.'}
          </p>

          {/* Filter Pills */}
          <div className="flex flex-wrap justify-center gap-2 mt-8">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
                  selectedCategory === cat
                    ? 'bg-[#C5A85C] text-[#0F2537] shadow-md font-bold'
                    : 'bg-white/10 text-slate-300 hover:bg-white/20 hover:text-white'
                }`}
              >
                {cat === 'All' ? (isPersian ? 'همه مقاطع' : 'All Eras') : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Interactive Feature Hero Card */}
        <div className="mb-14 rounded-2xl overflow-hidden bg-gradient-to-r from-[#0F2537] to-[#162E4A] border border-[#C5A85C]/30 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-3xl sm:text-4xl font-extrabold text-[#C5A85C] font-serif-heading">
                    {activeMilestone.year}
                  </span>
                  <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-[#C5A85C]/20 text-[#E5C97A] border border-[#C5A85C]/30">
                    {activeMilestone.category}
                  </span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold font-serif-heading text-white">
                  {isPersian ? activeMilestone.titleFa : activeMilestone.titleEn}
                </h3>
                <p className="mt-4 text-slate-300 text-sm sm:text-base leading-relaxed">
                  {isPersian ? activeMilestone.descriptionFa : activeMilestone.descriptionEn}
                </p>
              </div>

              <div className="mt-8 pt-6 border-t border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <Award className="w-4 h-4 text-[#C5A85C]" />
                  <span>{isPersian ? 'بخشی از تاریخ زنده تانگلین' : 'Tanglin Heritage Archive'}</span>
                </div>
                <span className="text-xs text-[#C5A85C] font-bold">
                  {isPersian ? 'برای دیدن سال‌های دیگر کلیک کنید' : 'Select a milestone below'}
                </span>
              </div>
            </div>

            <div className="lg:col-span-5 relative min-h-[260px] lg:min-h-full">
              <img
                src={activeMilestone.image}
                alt={activeMilestone.titleEn}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-l from-transparent via-[#0F2537]/30 to-[#0F2537]" />
            </div>
          </div>
        </div>

        {/* Milestones Horizontal Grid Selector */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {filteredMilestones.map((m) => {
            const isSelected = activeMilestone.year === m.year;
            return (
              <button
                key={m.year}
                onClick={() => setActiveMilestone(m)}
                className={`text-left p-4 rounded-xl transition-all relative overflow-hidden border ${
                  isSelected
                    ? 'bg-[#C5A85C] text-[#0F2537] border-[#C5A85C] shadow-lg scale-102'
                    : 'bg-white/5 hover:bg-white/10 text-white border-white/10 hover:border-[#C5A85C]/40'
                }`}
              >
                <div className="text-xl font-bold font-serif-heading">
                  {m.year}
                </div>
                <div className={`text-xs font-semibold mt-1 line-clamp-2 ${isSelected ? 'text-[#0F2537]' : 'text-slate-200'}`}>
                  {isPersian ? m.titleFa : m.titleEn}
                </div>
                <div className={`text-[10px] mt-2 font-medium uppercase tracking-wider ${isSelected ? 'text-[#0F2537]/80' : 'text-[#C5A85C]'}`}>
                  {m.category}
                </div>
              </button>
            );
          })}
        </div>

      </div>
    </section>
  );
};
