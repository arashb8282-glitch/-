import React, { useState, useEffect } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { ThemeProvider } from './context/ThemeContext';
import { KheradHeader } from './components/KheradHeader';
import { KheradSquareMenuButton } from './components/KheradSquareMenuButton';
import { RightDrawerMenu } from './components/RightDrawerMenu';
import { KheradHeroBanner } from './components/KheradHeroBanner';
import { KheradAboutPanel } from './components/KheradAboutPanel';
import { KheradHonorPanel } from './components/KheradHonorPanel';
import { KheradPillarsGrid } from './components/KheradPillarsGrid';
import { KheradStatsInfographic } from './components/KheradStatsInfographic';
import { KheradSchoolsSection } from './components/KheradSchoolsSection';
import { KheradFAQSection } from './components/KheradFAQSection';
import { KheradLocationSection } from './components/KheradLocationSection';
import { KheradFooter } from './components/KheradFooter';

import { KheradSubPageModal } from './components/KheradSubPageModal';
import { KheradAdmissionsModal } from './components/KheradAdmissionsModal';
import { KheradCampusModal } from './components/KheradCampusModal';
import { KheradSearchModal } from './components/KheradSearchModal';
import { KheradChatBot } from './components/KheradChatBot';
import { KheradScrollToTop } from './components/KheradScrollToTop';

function KheradAppContent() {
  const { dir, isPersian } = useLanguage();

  // Navigation & Drawer State
  const [isRightDrawerOpen, setIsRightDrawerOpen] = useState(false);
  
  // Interactive Modals State
  const [activeCategoryModal, setActiveCategoryModal] = useState<string | null>(null);
  const [activeSubItemId, setActiveSubItemId] = useState<string | null>(null);
  const [isAdmissionsModalOpen, setIsAdmissionsModalOpen] = useState(false);
  const [isCampusModalOpen, setIsCampusModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [searchInitialQuery, setSearchInitialQuery] = useState('');

  // Synchronize document title with active language
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.title = isPersian 
        ? 'مجتمع آموزشی منظومه خرد | آموزش و پرورش پیشرو و توسعه پایدار'
        : 'Kherad Educational Complex | Progressive Education & Sustainability';
    }
  }, [isPersian]);

  // Handler for selecting categories or sub-items across header, drawer, and cards
  const handleSelectCategory = (categoryId: string, subItemId?: string) => {
    // Check if it's admissions
    if (categoryId === 'admissions' || (categoryId === 'admissions-student' && subItemId === 'adm-apply')) {
      setIsAdmissionsModalOpen(true);
      return;
    }
    // Check if it's virtual campus tour
    if (subItemId === 'virtual-tour' || categoryId === 'campus') {
      setIsCampusModalOpen(true);
      return;
    }

    setActiveCategoryModal(categoryId);
    setActiveSubItemId(subItemId || null);
  };

  const handleOpenSearchWithQuery = (query: string) => {
    setSearchInitialQuery(query);
    setIsSearchModalOpen(true);
  };

  const scrollToNav = () => {
    const el = document.getElementById('kherad-nav');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className={`min-h-screen bg-[#F8F9FA] text-[#131313] ${isPersian ? 'font-persian' : 'font-helvetica'} transition-colors duration-300`} dir={dir}>
      <div id="top" />

      {/* Top-Right Square Menu Button */}
      <KheradSquareMenuButton
        onClick={() => setIsRightDrawerOpen(true)}
        isOpen={isRightDrawerOpen}
      />

      {/* 1. Full-Page Architectural Hero Banner */}
      <KheradHeroBanner
        onScrollDown={scrollToNav}
        onOpenMenu={() => setIsRightDrawerOpen(true)}
        onOpenSearch={() => {
          setSearchInitialQuery('');
          setIsSearchModalOpen(true);
        }}
        onLogoClick={() => handleSelectCategory('about', 'about-kherad')}
        onSelectSystem={(systemId) => handleSelectCategory('systems', systemId)}
      />

      {/* 2. Floating Quick Actions on Screen Edge with 360 tour icon and language switcher */}
      <div id="kherad-nav">
        <KheradHeader
          onOpenRightDrawer={() => setIsRightDrawerOpen(true)}
          onOpenSearch={() => {
            setSearchInitialQuery('');
            setIsSearchModalOpen(true);
          }}
          onOpenApply={() => setIsAdmissionsModalOpen(true)}
          onOpenTour={() => setIsCampusModalOpen(true)}
          onSelectCategory={handleSelectCategory}
        />
      </div>

      {/* 3. Slide-out Mega Menu from the Right Edge */}
      <RightDrawerMenu
        isOpen={isRightDrawerOpen}
        onClose={() => setIsRightDrawerOpen(false)}
        onSelectItem={handleSelectCategory}
        onSearch={handleOpenSearchWithQuery}
      />

      <main>
        {/* 4. Deep Navy About Panel */}
        <KheradAboutPanel
          onOpenDetails={(subId) => {
            handleSelectCategory('about', subId);
          }}
          onOpenAdmissions={() => setIsAdmissionsModalOpen(true)}
          onOpenCampus={() => setIsCampusModalOpen(true)}
        />

        {/* 6. 6 Pillars Grid: Mission, History, Results, Culture & Art, Campus, Management */}
        <KheradPillarsGrid
          onSelectPillar={(pillarId) => {
            if (pillarId === 'mission-vision' || pillarId === 'mission') {
              handleSelectCategory('about', 'mission');
              return;
            }
            if (pillarId === 'campus') {
              setIsCampusModalOpen(true);
            } else if (pillarId === 'culture-art') {
              handleSelectCategory('institute-activities');
            } else {
              handleSelectCategory('about', pillarId);
            }
          }}
        />

        {/* 7. 8-Stat Infographic: Key Statistics of Kherad */}
        <KheradStatsInfographic />

        {/* 8. Educational Stages Section: Preschool, Primary, Middle, High, Vocational School */}
        <KheradSchoolsSection
          onSelectSchool={(schoolId) => handleSelectCategory(schoolId)}
        />

        {/* 8.5. Frequently Asked Questions (FAQ) Accordion: Programs, Admissions, Philosophy & Campus */}
        <KheradFAQSection
          onOpenAdmissions={() => setIsAdmissionsModalOpen(true)}
        />

        {/* 9. Velenjak Campus Interactive Map, Contact Details & Directions */}
        <KheradLocationSection
          onOpenTour={() => setIsCampusModalOpen(true)}
          onOpenAdmissions={() => setIsAdmissionsModalOpen(true)}
        />
      </main>

      {/* 10. Official Footer with contact info, Velenjak address, telephone lines, and full sitemap links */}
      <KheradFooter
        onOpenApply={() => setIsAdmissionsModalOpen(true)}
        onOpenTour={() => setIsCampusModalOpen(true)}
        onSelectCategory={(catId) => handleSelectCategory(catId)}
      />

      {/* Interactive Modals */}
      <KheradSubPageModal
        categoryId={activeCategoryModal}
        subItemId={activeSubItemId}
        onClose={() => {
          setActiveCategoryModal(null);
          setActiveSubItemId(null);
        }}
        onOpenApply={() => setIsAdmissionsModalOpen(true)}
      />

      <KheradAdmissionsModal
        isOpen={isAdmissionsModalOpen}
        onClose={() => setIsAdmissionsModalOpen(false)}
      />

      <KheradCampusModal
        isOpen={isCampusModalOpen}
        onClose={() => setIsCampusModalOpen(false)}
      />

      <KheradSearchModal
        isOpen={isSearchModalOpen}
        initialQuery={searchInitialQuery}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectResult={handleSelectCategory}
      />

      {/* Floating Kherad Educational & Admissions Chatbot in Bottom Right */}
      <KheradChatBot
        onOpenApply={() => setIsAdmissionsModalOpen(true)}
        onOpenTour={() => setIsCampusModalOpen(true)}
        onSelectCategory={handleSelectCategory}
        isMainMenuOpen={isRightDrawerOpen}
      />

      {/* Floating Scroll to Top button appearing past hero banner */}
      <KheradScrollToTop />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <KheradAppContent />
      </LanguageProvider>
    </ThemeProvider>
  );
}
